--
-- PostgreSQL database dump
--

\restrict 5UyW2BWlmAzWQ7R0dRj2sAcZnjdn2w0eolwTeP3RIpnQsofVh0MgKiA6W6oitNf

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER pgrst_drop_watch;
DROP EVENT TRIGGER pgrst_ddl_watch;
DROP EVENT TRIGGER issue_pg_net_access;
DROP EVENT TRIGGER issue_pg_graphql_access;
DROP EVENT TRIGGER issue_pg_cron_access;
DROP EVENT TRIGGER issue_graphql_placeholder;
DROP PUBLICATION supabase_realtime_messages_publication;
DROP PUBLICATION supabase_realtime;
DROP POLICY service_role_select_reviews ON review_ai.reviews;
DROP POLICY service_role_select_contents ON review_ai.review_contents;
DROP POLICY service_role_insert_reviews ON review_ai.reviews;
DROP POLICY service_role_insert_contents ON review_ai.review_contents;
DROP POLICY "Users can view own user record" ON public.users;
DROP POLICY "Users can update own user record" ON public.users;
DROP POLICY "Users can update own profile" ON public.tourists;
DROP POLICY "Tourists can view own profile" ON public.tourists;
DROP POLICY "Tourists can update own profile" ON public.tourists;
DROP POLICY "Business can view own profile" ON public.businesses;
DROP POLICY "Business can update own profile" ON public.businesses;
ALTER TABLE ONLY travel.place_tags DROP CONSTRAINT place_tags_tag_id_fkey;
ALTER TABLE ONLY travel.place_tags DROP CONSTRAINT place_tags_place_id_fkey;
ALTER TABLE ONLY travel.place_services DROP CONSTRAINT place_services_service_id_fkey;
ALTER TABLE ONLY travel.place_services DROP CONSTRAINT place_services_place_id_fkey;
ALTER TABLE ONLY travel.itinerary_members DROP CONSTRAINT itinerary_members_itinerary_id_fkey;
ALTER TABLE ONLY travel.itinerary_details DROP CONSTRAINT itinerary_details_place_id_fkey;
ALTER TABLE ONLY travel.itinerary_details DROP CONSTRAINT itinerary_details_itinerary_id_fkey;
ALTER TABLE ONLY travel.types DROP CONSTRAINT fk_types_category;
ALTER TABLE ONLY travel.places DROP CONSTRAINT fk_places_vendor;
ALTER TABLE ONLY travel.places DROP CONSTRAINT fk_places_type;
ALTER TABLE ONLY travel.places DROP CONSTRAINT fk_places_city;
ALTER TABLE ONLY travel.itinerary_members DROP CONSTRAINT fk_member_tourist;
ALTER TABLE ONLY travel.itineraries DROP CONSTRAINT fk_itinerary_creator;
ALTER TABLE ONLY travel.favorite_places DROP CONSTRAINT fk_favorite_tourist;
ALTER TABLE ONLY travel.favorite_itineraries DROP CONSTRAINT fk_fav_itinerary_tourist;
ALTER TABLE ONLY travel.activity_logs DROP CONSTRAINT fk_activity_tourist;
ALTER TABLE ONLY travel.favorite_places DROP CONSTRAINT favorite_places_place_id_fkey;
ALTER TABLE ONLY travel.favorite_itineraries DROP CONSTRAINT favorite_itineraries_itinerary_id_fkey;
ALTER TABLE ONLY travel.activity_logs DROP CONSTRAINT activity_logs_place_id_fkey;
ALTER TABLE ONLY tracking.transport_within_city DROP CONSTRAINT transport_within_city_transport_mode_id_fkey;
ALTER TABLE ONLY tracking.transport_within_city DROP CONSTRAINT transport_within_city_itinerary_detail_id_fkey;
ALTER TABLE ONLY tracking.transport_to_destination DROP CONSTRAINT transport_to_destination_transport_mode_id_fkey;
ALTER TABLE ONLY tracking.transport_pricing_rules DROP CONSTRAINT transport_pricing_rules_transport_mode_id_fkey;
ALTER TABLE ONLY tracking.geofence_visits DROP CONSTRAINT geofence_visits_itinerary_detail_id_fkey;
ALTER TABLE ONLY tracking.geofence_visits DROP CONSTRAINT geofence_visits_geofence_id_fkey;
ALTER TABLE ONLY tracking.transport_to_destination DROP CONSTRAINT fk_transport_itinerary;
ALTER TABLE ONLY storage.vector_indexes DROP CONSTRAINT vector_indexes_bucket_id_fkey;
ALTER TABLE ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey;
ALTER TABLE ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey;
ALTER TABLE ONLY storage.s3_multipart_uploads DROP CONSTRAINT s3_multipart_uploads_bucket_id_fkey;
ALTER TABLE ONLY storage.objects DROP CONSTRAINT "objects_bucketId_fkey";
ALTER TABLE ONLY review_ai.reviews DROP CONSTRAINT reviews_place_id_fkey;
ALTER TABLE ONLY review_ai.reviews DROP CONSTRAINT reviews_itinerary_id_fkey;
ALTER TABLE ONLY review_ai.review_contents DROP CONSTRAINT review_contents_review_id_fkey;
ALTER TABLE ONLY review_ai.review_conflicts DROP CONSTRAINT review_conflicts_old_content_id_fkey;
ALTER TABLE ONLY review_ai.review_conflicts DROP CONSTRAINT review_conflicts_new_content_id_fkey;
ALTER TABLE ONLY review_ai.itinerary_reviews DROP CONSTRAINT itinerary_reviews_itinerary_id_fkey;
ALTER TABLE ONLY review_ai.reviews DROP CONSTRAINT fk_review_tourist;
ALTER TABLE ONLY review_ai.itinerary_reviews DROP CONSTRAINT fk_itinerary_review_tourist;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_id_fkey;
ALTER TABLE ONLY public.tourists DROP CONSTRAINT tourists_id_fkey;
ALTER TABLE ONLY public.users_notifications DROP CONSTRAINT fk_users_notifications_user;
ALTER TABLE ONLY public.users_notifications DROP CONSTRAINT fk_users_notifications_notification;
ALTER TABLE ONLY public.businesses DROP CONSTRAINT businesses_id_fkey;
ALTER TABLE ONLY order_sys.orders DROP CONSTRAINT orders_itinerary_detail_id_fkey;
ALTER TABLE ONLY order_sys.order_items DROP CONSTRAINT order_items_order_id_fkey;
ALTER TABLE ONLY order_sys.order_items DROP CONSTRAINT order_items_food_item_id_fkey;
ALTER TABLE ONLY order_sys.food_items DROP CONSTRAINT food_items_place_id_fkey;
ALTER TABLE ONLY order_sys.orders DROP CONSTRAINT fk_order_tourist;
ALTER TABLE ONLY core.user_notifications DROP CONSTRAINT user_notifications_user_id_fkey;
ALTER TABLE ONLY core.user_notifications DROP CONSTRAINT user_notifications_notification_id_fkey;
ALTER TABLE ONLY auth.webauthn_credentials DROP CONSTRAINT webauthn_credentials_user_id_fkey;
ALTER TABLE ONLY auth.webauthn_challenges DROP CONSTRAINT webauthn_challenges_user_id_fkey;
ALTER TABLE ONLY auth.sso_domains DROP CONSTRAINT sso_domains_sso_provider_id_fkey;
ALTER TABLE ONLY auth.sessions DROP CONSTRAINT sessions_user_id_fkey;
ALTER TABLE ONLY auth.sessions DROP CONSTRAINT sessions_oauth_client_id_fkey;
ALTER TABLE ONLY auth.saml_relay_states DROP CONSTRAINT saml_relay_states_sso_provider_id_fkey;
ALTER TABLE ONLY auth.saml_relay_states DROP CONSTRAINT saml_relay_states_flow_state_id_fkey;
ALTER TABLE ONLY auth.saml_providers DROP CONSTRAINT saml_providers_sso_provider_id_fkey;
ALTER TABLE ONLY auth.refresh_tokens DROP CONSTRAINT refresh_tokens_session_id_fkey;
ALTER TABLE ONLY auth.one_time_tokens DROP CONSTRAINT one_time_tokens_user_id_fkey;
ALTER TABLE ONLY auth.oauth_consents DROP CONSTRAINT oauth_consents_user_id_fkey;
ALTER TABLE ONLY auth.oauth_consents DROP CONSTRAINT oauth_consents_client_id_fkey;
ALTER TABLE ONLY auth.oauth_authorizations DROP CONSTRAINT oauth_authorizations_user_id_fkey;
ALTER TABLE ONLY auth.oauth_authorizations DROP CONSTRAINT oauth_authorizations_client_id_fkey;
ALTER TABLE ONLY auth.mfa_factors DROP CONSTRAINT mfa_factors_user_id_fkey;
ALTER TABLE ONLY auth.mfa_challenges DROP CONSTRAINT mfa_challenges_auth_factor_id_fkey;
ALTER TABLE ONLY auth.mfa_amr_claims DROP CONSTRAINT mfa_amr_claims_session_id_fkey;
ALTER TABLE ONLY auth.identities DROP CONSTRAINT identities_user_id_fkey;
DROP TRIGGER update_objects_updated_at ON storage.objects;
DROP TRIGGER protect_objects_delete ON storage.objects;
DROP TRIGGER protect_buckets_delete ON storage.buckets;
DROP TRIGGER enforce_bucket_name_length_trigger ON storage.buckets;
DROP TRIGGER tr_check_filters ON realtime.subscription;
DROP TRIGGER on_auth_user_created ON auth.users;
DROP INDEX storage.vector_indexes_name_bucket_id_idx;
DROP INDEX storage.name_prefix_search;
DROP INDEX storage.idx_objects_bucket_id_name_lower;
DROP INDEX storage.idx_objects_bucket_id_name;
DROP INDEX storage.idx_multipart_uploads_list;
DROP INDEX storage.buckets_analytics_unique_name_idx;
DROP INDEX storage.bucketid_objname;
DROP INDEX storage.bname;
DROP INDEX review_ai.idx_reviews_status;
DROP INDEX review_ai.idx_reviews_created_at;
DROP INDEX realtime.subscription_subscription_id_entity_filters_action_filter_key;
DROP INDEX realtime.messages_inserted_at_topic_index;
DROP INDEX realtime.ix_realtime_subscription_entity;
DROP INDEX public.unique_active_phone;
DROP INDEX auth.webauthn_credentials_user_id_idx;
DROP INDEX auth.webauthn_credentials_credential_id_key;
DROP INDEX auth.webauthn_challenges_user_id_idx;
DROP INDEX auth.webauthn_challenges_expires_at_idx;
DROP INDEX auth.users_is_anonymous_idx;
DROP INDEX auth.users_instance_id_idx;
DROP INDEX auth.users_instance_id_email_idx;
DROP INDEX auth.users_email_partial_key;
DROP INDEX auth.user_id_created_at_idx;
DROP INDEX auth.unique_phone_factor_per_user;
DROP INDEX auth.sso_providers_resource_id_pattern_idx;
DROP INDEX auth.sso_providers_resource_id_idx;
DROP INDEX auth.sso_domains_sso_provider_id_idx;
DROP INDEX auth.sso_domains_domain_idx;
DROP INDEX auth.sessions_user_id_idx;
DROP INDEX auth.sessions_oauth_client_id_idx;
DROP INDEX auth.sessions_not_after_idx;
DROP INDEX auth.saml_relay_states_sso_provider_id_idx;
DROP INDEX auth.saml_relay_states_for_email_idx;
DROP INDEX auth.saml_relay_states_created_at_idx;
DROP INDEX auth.saml_providers_sso_provider_id_idx;
DROP INDEX auth.refresh_tokens_updated_at_idx;
DROP INDEX auth.refresh_tokens_session_id_revoked_idx;
DROP INDEX auth.refresh_tokens_parent_idx;
DROP INDEX auth.refresh_tokens_instance_id_user_id_idx;
DROP INDEX auth.refresh_tokens_instance_id_idx;
DROP INDEX auth.recovery_token_idx;
DROP INDEX auth.reauthentication_token_idx;
DROP INDEX auth.one_time_tokens_user_id_token_type_key;
DROP INDEX auth.one_time_tokens_token_hash_hash_idx;
DROP INDEX auth.one_time_tokens_relates_to_hash_idx;
DROP INDEX auth.oauth_consents_user_order_idx;
DROP INDEX auth.oauth_consents_active_user_client_idx;
DROP INDEX auth.oauth_consents_active_client_idx;
DROP INDEX auth.oauth_clients_deleted_at_idx;
DROP INDEX auth.oauth_auth_pending_exp_idx;
DROP INDEX auth.mfa_factors_user_id_idx;
DROP INDEX auth.mfa_factors_user_friendly_name_unique;
DROP INDEX auth.mfa_challenge_created_at_idx;
DROP INDEX auth.idx_user_id_auth_method;
DROP INDEX auth.idx_oauth_client_states_created_at;
DROP INDEX auth.idx_auth_code;
DROP INDEX auth.identities_user_id_idx;
DROP INDEX auth.identities_email_idx;
DROP INDEX auth.flow_state_created_at_idx;
DROP INDEX auth.factor_id_created_at_idx;
DROP INDEX auth.email_change_token_new_idx;
DROP INDEX auth.email_change_token_current_idx;
DROP INDEX auth.custom_oauth_providers_provider_type_idx;
DROP INDEX auth.custom_oauth_providers_identifier_idx;
DROP INDEX auth.custom_oauth_providers_enabled_idx;
DROP INDEX auth.custom_oauth_providers_created_at_idx;
DROP INDEX auth.confirmation_token_idx;
DROP INDEX auth.audit_logs_instance_id_idx;
ALTER TABLE ONLY travel.places DROP CONSTRAINT uq_places_source;
ALTER TABLE ONLY travel.types DROP CONSTRAINT types_pkey;
ALTER TABLE ONLY travel.tags DROP CONSTRAINT tags_pkey;
ALTER TABLE ONLY travel.services DROP CONSTRAINT services_pkey;
ALTER TABLE ONLY travel.places DROP CONSTRAINT places_pkey;
ALTER TABLE ONLY travel.place_tags DROP CONSTRAINT place_tags_pkey;
ALTER TABLE ONLY travel.place_services DROP CONSTRAINT place_services_pkey;
ALTER TABLE ONLY travel.itinerary_members DROP CONSTRAINT itinerary_members_pkey;
ALTER TABLE ONLY travel.itinerary_details DROP CONSTRAINT itinerary_details_pkey;
ALTER TABLE ONLY travel.itineraries DROP CONSTRAINT itineraries_pkey;
ALTER TABLE ONLY travel.favorite_places DROP CONSTRAINT favorite_places_pkey;
ALTER TABLE ONLY travel.favorite_itineraries DROP CONSTRAINT favorite_itineraries_pkey;
ALTER TABLE ONLY travel.cities DROP CONSTRAINT cities_pkey;
ALTER TABLE ONLY travel.categories DROP CONSTRAINT categories_pkey;
ALTER TABLE ONLY travel.activity_logs DROP CONSTRAINT activity_logs_pkey;
ALTER TABLE ONLY tracking.transport_within_city DROP CONSTRAINT transport_within_city_pkey;
ALTER TABLE ONLY tracking.transport_to_destination DROP CONSTRAINT transport_to_destination_pkey;
ALTER TABLE ONLY tracking.transport_pricing_rules DROP CONSTRAINT transport_pricing_rules_pkey;
ALTER TABLE ONLY tracking.transport_modes DROP CONSTRAINT transport_modes_pkey;
ALTER TABLE ONLY tracking.geofences DROP CONSTRAINT geofences_pkey;
ALTER TABLE ONLY tracking.geofence_visits DROP CONSTRAINT geofence_visits_pkey;
ALTER TABLE ONLY storage.vector_indexes DROP CONSTRAINT vector_indexes_pkey;
ALTER TABLE ONLY storage.s3_multipart_uploads DROP CONSTRAINT s3_multipart_uploads_pkey;
ALTER TABLE ONLY storage.s3_multipart_uploads_parts DROP CONSTRAINT s3_multipart_uploads_parts_pkey;
ALTER TABLE ONLY storage.objects DROP CONSTRAINT objects_pkey;
ALTER TABLE ONLY storage.migrations DROP CONSTRAINT migrations_pkey;
ALTER TABLE ONLY storage.migrations DROP CONSTRAINT migrations_name_key;
ALTER TABLE ONLY storage.buckets_vectors DROP CONSTRAINT buckets_vectors_pkey;
ALTER TABLE ONLY storage.buckets DROP CONSTRAINT buckets_pkey;
ALTER TABLE ONLY storage.buckets_analytics DROP CONSTRAINT buckets_analytics_pkey;
ALTER TABLE ONLY review_ai.reviews DROP CONSTRAINT reviews_pkey;
ALTER TABLE ONLY review_ai.review_contents DROP CONSTRAINT review_contents_pkey;
ALTER TABLE ONLY review_ai.review_conflicts DROP CONSTRAINT review_conflicts_pkey;
ALTER TABLE ONLY review_ai.itinerary_reviews DROP CONSTRAINT itinerary_reviews_pkey;
ALTER TABLE ONLY realtime.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY realtime.subscription DROP CONSTRAINT pk_subscription;
ALTER TABLE ONLY realtime.messages_2026_05_07 DROP CONSTRAINT messages_2026_05_07_pkey;
ALTER TABLE ONLY realtime.messages_2026_05_06 DROP CONSTRAINT messages_2026_05_06_pkey;
ALTER TABLE ONLY realtime.messages_2026_05_05 DROP CONSTRAINT messages_2026_05_05_pkey;
ALTER TABLE ONLY realtime.messages_2026_05_04 DROP CONSTRAINT messages_2026_05_04_pkey;
ALTER TABLE ONLY realtime.messages_2026_05_03 DROP CONSTRAINT messages_2026_05_03_pkey;
ALTER TABLE ONLY realtime.messages DROP CONSTRAINT messages_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users_notifications DROP CONSTRAINT users_notifications_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.tourists DROP CONSTRAINT tourists_pkey;
ALTER TABLE ONLY public.notifications DROP CONSTRAINT notifications_pkey;
ALTER TABLE ONLY public.businesses DROP CONSTRAINT businesses_pkey;
ALTER TABLE ONLY order_sys.food_items DROP CONSTRAINT uq_foody_dish_id;
ALTER TABLE ONLY order_sys.orders DROP CONSTRAINT orders_pkey;
ALTER TABLE ONLY order_sys.order_items DROP CONSTRAINT order_items_pkey;
ALTER TABLE ONLY order_sys.food_items DROP CONSTRAINT food_items_pkey;
ALTER TABLE ONLY core.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY core.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY core.user_notifications DROP CONSTRAINT user_notifications_pkey;
ALTER TABLE ONLY core.notifications DROP CONSTRAINT notifications_pkey;
ALTER TABLE ONLY auth.webauthn_credentials DROP CONSTRAINT webauthn_credentials_pkey;
ALTER TABLE ONLY auth.webauthn_challenges DROP CONSTRAINT webauthn_challenges_pkey;
ALTER TABLE ONLY auth.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY auth.users DROP CONSTRAINT users_phone_key;
ALTER TABLE ONLY auth.sso_providers DROP CONSTRAINT sso_providers_pkey;
ALTER TABLE ONLY auth.sso_domains DROP CONSTRAINT sso_domains_pkey;
ALTER TABLE ONLY auth.sessions DROP CONSTRAINT sessions_pkey;
ALTER TABLE ONLY auth.schema_migrations DROP CONSTRAINT schema_migrations_pkey;
ALTER TABLE ONLY auth.saml_relay_states DROP CONSTRAINT saml_relay_states_pkey;
ALTER TABLE ONLY auth.saml_providers DROP CONSTRAINT saml_providers_pkey;
ALTER TABLE ONLY auth.saml_providers DROP CONSTRAINT saml_providers_entity_id_key;
ALTER TABLE ONLY auth.refresh_tokens DROP CONSTRAINT refresh_tokens_token_unique;
ALTER TABLE ONLY auth.refresh_tokens DROP CONSTRAINT refresh_tokens_pkey;
ALTER TABLE ONLY auth.one_time_tokens DROP CONSTRAINT one_time_tokens_pkey;
ALTER TABLE ONLY auth.oauth_consents DROP CONSTRAINT oauth_consents_user_client_unique;
ALTER TABLE ONLY auth.oauth_consents DROP CONSTRAINT oauth_consents_pkey;
ALTER TABLE ONLY auth.oauth_clients DROP CONSTRAINT oauth_clients_pkey;
ALTER TABLE ONLY auth.oauth_client_states DROP CONSTRAINT oauth_client_states_pkey;
ALTER TABLE ONLY auth.oauth_authorizations DROP CONSTRAINT oauth_authorizations_pkey;
ALTER TABLE ONLY auth.oauth_authorizations DROP CONSTRAINT oauth_authorizations_authorization_id_key;
ALTER TABLE ONLY auth.oauth_authorizations DROP CONSTRAINT oauth_authorizations_authorization_code_key;
ALTER TABLE ONLY auth.mfa_factors DROP CONSTRAINT mfa_factors_pkey;
ALTER TABLE ONLY auth.mfa_factors DROP CONSTRAINT mfa_factors_last_challenged_at_key;
ALTER TABLE ONLY auth.mfa_challenges DROP CONSTRAINT mfa_challenges_pkey;
ALTER TABLE ONLY auth.mfa_amr_claims DROP CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey;
ALTER TABLE ONLY auth.instances DROP CONSTRAINT instances_pkey;
ALTER TABLE ONLY auth.identities DROP CONSTRAINT identities_provider_id_provider_unique;
ALTER TABLE ONLY auth.identities DROP CONSTRAINT identities_pkey;
ALTER TABLE ONLY auth.flow_state DROP CONSTRAINT flow_state_pkey;
ALTER TABLE ONLY auth.custom_oauth_providers DROP CONSTRAINT custom_oauth_providers_pkey;
ALTER TABLE ONLY auth.custom_oauth_providers DROP CONSTRAINT custom_oauth_providers_identifier_key;
ALTER TABLE ONLY auth.audit_log_entries DROP CONSTRAINT audit_log_entries_pkey;
ALTER TABLE ONLY auth.mfa_amr_claims DROP CONSTRAINT amr_id_pk;
ALTER TABLE auth.refresh_tokens ALTER COLUMN id DROP DEFAULT;
DROP TABLE travel.types;
DROP TABLE travel.tags;
DROP TABLE travel.services;
DROP TABLE travel.places;
DROP TABLE travel.place_tags;
DROP TABLE travel.place_services;
DROP TABLE travel.itinerary_members;
DROP TABLE travel.itinerary_details;
DROP TABLE travel.itineraries;
DROP TABLE travel.favorite_places;
DROP TABLE travel.favorite_itineraries;
DROP TABLE travel.cities;
DROP TABLE travel.categories;
DROP TABLE travel.activity_logs;
DROP TABLE tracking.transport_within_city;
DROP TABLE tracking.transport_to_destination;
DROP TABLE tracking.transport_pricing_rules;
DROP TABLE tracking.transport_modes;
DROP TABLE tracking.geofences;
DROP TABLE tracking.geofence_visits;
DROP TABLE storage.vector_indexes;
DROP TABLE storage.s3_multipart_uploads_parts;
DROP TABLE storage.s3_multipart_uploads;
DROP TABLE storage.objects;
DROP TABLE storage.migrations;
DROP TABLE storage.buckets_vectors;
DROP TABLE storage.buckets_analytics;
DROP TABLE storage.buckets;
DROP TABLE review_ai.reviews;
DROP TABLE review_ai.review_contents;
DROP TABLE review_ai.review_conflicts;
DROP TABLE review_ai.itinerary_reviews;
DROP TABLE realtime.subscription;
DROP TABLE realtime.schema_migrations;
DROP TABLE realtime.messages_2026_05_07;
DROP TABLE realtime.messages_2026_05_06;
DROP TABLE realtime.messages_2026_05_05;
DROP TABLE realtime.messages_2026_05_04;
DROP TABLE realtime.messages_2026_05_03;
DROP TABLE realtime.messages;
DROP TABLE public.v_cat_id;
DROP TABLE public.users_notifications;
DROP TABLE public.users;
DROP TABLE public.tourists;
DROP TABLE public.notifications;
DROP TABLE public.businesses;
DROP TABLE order_sys.orders;
DROP TABLE order_sys.order_items;
DROP TABLE order_sys.food_items;
DROP TABLE core.users;
DROP TABLE core.user_notifications;
DROP TABLE core.notifications;
DROP TABLE auth.webauthn_credentials;
DROP TABLE auth.webauthn_challenges;
DROP TABLE auth.users;
DROP TABLE auth.sso_providers;
DROP TABLE auth.sso_domains;
DROP TABLE auth.sessions;
DROP TABLE auth.schema_migrations;
DROP TABLE auth.saml_relay_states;
DROP TABLE auth.saml_providers;
DROP SEQUENCE auth.refresh_tokens_id_seq;
DROP TABLE auth.refresh_tokens;
DROP TABLE auth.one_time_tokens;
DROP TABLE auth.oauth_consents;
DROP TABLE auth.oauth_clients;
DROP TABLE auth.oauth_client_states;
DROP TABLE auth.oauth_authorizations;
DROP TABLE auth.mfa_factors;
DROP TABLE auth.mfa_challenges;
DROP TABLE auth.mfa_amr_claims;
DROP TABLE auth.instances;
DROP TABLE auth.identities;
DROP TABLE auth.flow_state;
DROP TABLE auth.custom_oauth_providers;
DROP TABLE auth.audit_log_entries;
DROP FUNCTION travel.search_places_advanced(p_query text);
DROP FUNCTION travel.search_autocomplete(p_query text);
DROP FUNCTION travel.get_places_by_vendor(p_vendor_id uuid);
DROP FUNCTION travel.get_places_by_filter(p_city text, p_category text);
DROP FUNCTION travel.get_place_services_and_menu(p_place_id uuid);
DROP FUNCTION travel.get_place_detail(p_place_id uuid);
DROP FUNCTION travel.get_my_itineraries(p_user_id uuid);
DROP FUNCTION travel.get_business_dashboard(p_vendor_id uuid);
DROP FUNCTION travel.create_place_full(p_name text, p_address text, p_city text, p_lat numeric, p_lng numeric, p_categories text[], p_services text[], p_menu jsonb);
DROP FUNCTION travel.create_full_place_v2(p_name text, p_address text, p_city text, p_lat numeric, p_lng numeric, p_vendor_id uuid, p_categories text[], p_services jsonb, p_menu jsonb, p_images text[], p_open_time text, p_close_time text, p_description text);
DROP FUNCTION travel.create_full_place(p_name text, p_address text, p_city text, p_lat numeric, p_lng numeric, p_vendor_id uuid, p_categories text[], p_services jsonb, p_menu jsonb, p_images text[], p_open_time text, p_close_time text, p_description text);
DROP FUNCTION storage.update_updated_at_column();
DROP FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer, levels integer, start_after text, sort_order text, sort_column text, sort_column_after text);
DROP FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text);
DROP FUNCTION storage.search(prefix text, bucketname text, limits integer, levels integer, offsets integer, search text, sortcolumn text, sortorder text);
DROP FUNCTION storage.protect_delete();
DROP FUNCTION storage.operation();
DROP FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer, start_after text, next_token text, sort_order text);
DROP FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer, next_key_token text, next_upload_token text);
DROP FUNCTION storage.get_size_by_bucket();
DROP FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text);
DROP FUNCTION storage.foldername(name text);
DROP FUNCTION storage.filename(name text);
DROP FUNCTION storage.extension(name text);
DROP FUNCTION storage.enforce_bucket_name_length();
DROP FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb);
DROP FUNCTION storage.allow_only_operation(expected_operation text);
DROP FUNCTION storage.allow_any_operation(expected_operations text[]);
DROP FUNCTION realtime.topic();
DROP FUNCTION realtime.to_regrole(role_name text);
DROP FUNCTION realtime.subscription_check_filters();
DROP FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean);
DROP FUNCTION realtime.quote_wal2json(entity regclass);
DROP FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer);
DROP FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]);
DROP FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text);
DROP FUNCTION realtime."cast"(val text, type_ regtype);
DROP FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]);
DROP FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text);
DROP FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer);
DROP FUNCTION public.update_user_avatar(p_user_id uuid, p_avatar_url text);
DROP FUNCTION public.update_user_active_status(p_user_id uuid, p_is_active bit);
DROP FUNCTION public.update_tourist_profile(user_id_param uuid, new_full_name text, new_gender text, new_phone_number text, new_email text, new_preferences text[], new_avatar_url text);
DROP FUNCTION public.update_business_profile(user_id_param uuid, new_full_name text, new_phone_number text, new_identity_card text, new_dob text, new_address text, new_avatar_url text);
DROP FUNCTION public.soft_delete_users(p_user_ids uuid[]);
DROP FUNCTION public.handle_new_user_registration();
DROP FUNCTION public.handle_new_tourist_registration();
DROP FUNCTION public.get_users_list(page_number integer, page_size integer, search_text text, filter_role text, filter_is_active bit, filter_is_deleted bit);
DROP FUNCTION public.get_user_statistics();
DROP FUNCTION public.get_user_detail_by_admin(p_user_id uuid);
DROP FUNCTION public.get_tourist_profile(user_id_param uuid);
DROP FUNCTION public.get_orders(p_place_id uuid, p_status text, p_restaurant text, p_page integer, p_limit integer);
DROP FUNCTION public.get_business_profile(user_id_param uuid);
DROP FUNCTION pgbouncer.get_auth(p_usename text);
DROP FUNCTION order_sys.get_orders_by_place(p_vendor_id uuid);
DROP FUNCTION order_sys.get_order_detail(p_order_id uuid);
DROP FUNCTION order_sys.get_food_performance(p_vendor_id uuid);
DROP FUNCTION graphql_public.graphql("operationName" text, query text, variables jsonb, extensions jsonb);
DROP FUNCTION extensions.set_graphql_placeholder();
DROP FUNCTION extensions.pgrst_drop_watch();
DROP FUNCTION extensions.pgrst_ddl_watch();
DROP FUNCTION extensions.grant_pg_net_access();
DROP FUNCTION extensions.grant_pg_graphql_access();
DROP FUNCTION extensions.grant_pg_cron_access();
DROP FUNCTION auth.uid();
DROP FUNCTION auth.role();
DROP FUNCTION auth.jwt();
DROP FUNCTION auth.email();
DROP TYPE travel.itinerary_status_enum;
DROP TYPE tracking.visit_status_enum;
DROP TYPE storage.buckettype;
DROP TYPE review_ai.topic_enum;
DROP TYPE review_ai.time_label_enum;
DROP TYPE review_ai.review_type_enum;
DROP TYPE review_ai.review_status_enum;
DROP TYPE review_ai.processing_status_enum;
DROP TYPE realtime.wal_rls;
DROP TYPE realtime.wal_column;
DROP TYPE realtime.user_defined_filter;
DROP TYPE realtime.equality_op;
DROP TYPE realtime.action;
DROP TYPE order_sys.order_status_enum;
DROP TYPE core.user_role_enum;
DROP TYPE auth.one_time_token_type;
DROP TYPE auth.oauth_response_type;
DROP TYPE auth.oauth_registration_type;
DROP TYPE auth.oauth_client_type;
DROP TYPE auth.oauth_authorization_status;
DROP TYPE auth.factor_type;
DROP TYPE auth.factor_status;
DROP TYPE auth.code_challenge_method;
DROP TYPE auth.aal_level;
DROP EXTENSION vector;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION unaccent;
DROP EXTENSION supabase_vault;
DROP EXTENSION postgis;
DROP EXTENSION pgcrypto;
DROP EXTENSION pg_trgm;
DROP EXTENSION pg_stat_statements;
DROP SCHEMA vault;
DROP SCHEMA travel;
DROP SCHEMA tracking;
DROP SCHEMA storage;
DROP SCHEMA review_ai;
DROP SCHEMA realtime;
DROP SCHEMA pgbouncer;
DROP SCHEMA order_sys;
DROP SCHEMA graphql_public;
DROP SCHEMA graphql;
DROP SCHEMA extensions;
DROP SCHEMA core;
DROP SCHEMA auth;
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: core; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA core;


--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- Name: order_sys; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA order_sys;


--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- Name: review_ai; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA review_ai;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: tracking; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA tracking;


--
-- Name: travel; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA travel;


--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA extensions;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA extensions;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: user_role_enum; Type: TYPE; Schema: core; Owner: -
--

CREATE TYPE core.user_role_enum AS ENUM (
    'admin',
    'tourist',
    'vendor'
);


--
-- Name: order_status_enum; Type: TYPE; Schema: order_sys; Owner: -
--

CREATE TYPE order_sys.order_status_enum AS ENUM (
    'pending',
    'processing',
    'completed',
    'cancelled'
);


--
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- Name: processing_status_enum; Type: TYPE; Schema: review_ai; Owner: -
--

CREATE TYPE review_ai.processing_status_enum AS ENUM (
    'pending',
    'processed'
);


--
-- Name: review_status_enum; Type: TYPE; Schema: review_ai; Owner: -
--

CREATE TYPE review_ai.review_status_enum AS ENUM (
    'pending',
    'approved',
    'violation'
);


--
-- Name: review_type_enum; Type: TYPE; Schema: review_ai; Owner: -
--

CREATE TYPE review_ai.review_type_enum AS ENUM (
    'with_content',
    'without_content'
);


--
-- Name: time_label_enum; Type: TYPE; Schema: review_ai; Owner: -
--

CREATE TYPE review_ai.time_label_enum AS ENUM (
    'short_term',
    'long_term',
    'unknown'
);


--
-- Name: topic_enum; Type: TYPE; Schema: review_ai; Owner: -
--

CREATE TYPE review_ai.topic_enum AS ENUM (
    'traffic',
    'weather',
    'crowded',
    'infrastructure',
    'price',
    'service',
    'other'
);


--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


--
-- Name: visit_status_enum; Type: TYPE; Schema: tracking; Owner: -
--

CREATE TYPE tracking.visit_status_enum AS ENUM (
    'visited',
    'skipped',
    'not_visited'
);


--
-- Name: itinerary_status_enum; Type: TYPE; Schema: travel; Owner: -
--

CREATE TYPE travel.itinerary_status_enum AS ENUM (
    'ongoing',
    'completed',
    'pending',
    'uncompleted'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


--
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: graphql(text, text, jsonb, jsonb); Type: FUNCTION; Schema: graphql_public; Owner: -
--

CREATE FUNCTION graphql_public.graphql("operationName" text DEFAULT NULL::text, query text DEFAULT NULL::text, variables jsonb DEFAULT NULL::jsonb, extensions jsonb DEFAULT NULL::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;


--
-- Name: get_food_performance(uuid); Type: FUNCTION; Schema: order_sys; Owner: -
--

CREATE FUNCTION order_sys.get_food_performance(p_vendor_id uuid) RETURNS TABLE(food_id uuid, food_name text, place_name text, price numeric, order_count bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        fi.id,
        fi.name::TEXT,
        p.name::TEXT,
        fi.price,
        COALESCE(COUNT(oi.id), 0)::BIGINT
    FROM order_sys.food_items fi
    JOIN travel.places p ON p.id = fi.place_id
    LEFT JOIN order_sys.order_items oi ON oi.food_item_id = fi.id
    WHERE p.vendor_id = p_vendor_id
    GROUP BY fi.id, fi.name, p.name, fi.price
    ORDER BY COALESCE(COUNT(oi.id), 0) DESC;
END;
$$;


--
-- Name: get_order_detail(uuid); Type: FUNCTION; Schema: order_sys; Owner: -
--

CREATE FUNCTION order_sys.get_order_detail(p_order_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE result JSON;
BEGIN

SELECT json_build_object(
    'order_id', o.id,
    'customer_name', u.full_name,
    'phone', u.phone_number,
    'email', u.email,
    'status', o.status,
    'notes', o.notes,
    'total_amount', o.total_amount,
    'ordered_time', o.ordered_at,

    'foods',
    (
        SELECT json_agg(
            json_build_object(
                'food_name', f.name,
                'quantity', oi.quantity,
                'price', oi.unit_price
            )
        )
        FROM order_sys.order_items oi
        JOIN order_sys.food_items f
        ON f.id = oi.food_item_id
        WHERE oi.order_id = o.id
    )

)
INTO result
FROM order_sys.orders o
JOIN users u
ON u.id = o.tourist_id
WHERE o.id = p_order_id;

RETURN result;

END;
$$;


--
-- Name: get_orders_by_place(uuid); Type: FUNCTION; Schema: order_sys; Owner: -
--

CREATE FUNCTION order_sys.get_orders_by_place(p_vendor_id uuid) RETURNS TABLE(order_id uuid, ordered_time timestamp without time zone, customer_name text, foods text, total_amount numeric, status text, place_name text)
    LANGUAGE plpgsql
    AS $$
BEGIN

RETURN QUERY
SELECT
    o.id,
    o.ordered_at,
    u.full_name::TEXT,

    COALESCE(STRING_AGG(f.name, ', '), '')::TEXT,

    o.total_amount,
    o.status::TEXT,
    p.name::TEXT

FROM order_sys.orders o

JOIN users u
    ON u.id = o.tourist_id

LEFT JOIN order_sys.order_items oi
    ON oi.order_id = o.id

LEFT JOIN order_sys.food_items f
    ON f.id = oi.food_item_id

LEFT JOIN travel.itinerary_details idt
    ON idt.id = o.itinerary_detail_id

LEFT JOIN travel.places p
    ON p.id = idt.place_id

-- ✅ FIX: lọc theo vendor_id
WHERE p.vendor_id = p_vendor_id

GROUP BY 
    o.id,
    o.ordered_at,
    u.full_name,
    o.total_amount,
    o.status,
    p.name

ORDER BY o.ordered_at DESC;

END;
$$;


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


--
-- Name: get_business_profile(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_business_profile(user_id_param uuid) RETURNS TABLE(full_name text, email text, phone_number text, identity_card text, date_of_birth date, address text, avatar_url text, is_approved boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$BEGIN
    RETURN QUERY
    SELECT 
        u.full_name, 
        u.email, 
        u.phone_number, 
        b.identity_card, 
        u.date_of_birth, -- Chuyển sang lấy từ bảng users
        b.address, 
        u.avatar_url,
        b.is_approved, 
        u.created_at
    FROM public.users u
    JOIN public.businesses b ON u.id = b.id
    WHERE u.id = user_id_param;
END;$$;


--
-- Name: get_orders(uuid, text, text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_orders(p_place_id uuid, p_status text DEFAULT 'all'::text, p_restaurant text DEFAULT 'all'::text, p_page integer DEFAULT 1, p_limit integer DEFAULT 10) RETURNS TABLE(order_id uuid, place_name text, customer_name text, status text, ordered_time timestamp without time zone, total_amount numeric, total_count bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY
  SELECT 
    o.order_id,
    o.place_name,
    o.customer_name,
    o.status,
    o.ordered_time,
    o.total_amount,
    COUNT(*) OVER() AS total_count
  FROM orders o
  WHERE o.place_id = p_place_id
    AND (p_status = 'all' OR o.status = p_status)
    AND (p_restaurant = 'all' OR o.place_name = p_restaurant)
  ORDER BY o.ordered_time DESC
  LIMIT p_limit
  OFFSET (p_page - 1) * p_limit;
END;
$$;


--
-- Name: get_tourist_profile(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_tourist_profile(user_id_param uuid) RETURNS TABLE(full_name text, gender text, phone_number text, email text, travel_preferences text[], avatar_url text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$BEGIN
    RETURN QUERY
    SELECT 
        u.full_name, 
        t.gender, 
        u.phone_number, 
        u.email, 
        t.travel_preferences, 
        u.avatar_url,
        u.created_at
    FROM public.users u
    JOIN public.tourists t ON u.id = t.id
    WHERE u.id = user_id_param;
END;$$;


--
-- Name: get_user_detail_by_admin(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_detail_by_admin(p_user_id uuid) RETURNS TABLE(id uuid, role text, email text, full_name text, phone_number text, date_of_birth date, avatar_url text, is_active bit, is_deleted bit, created_at timestamp with time zone, address text)
    LANGUAGE plpgsql
    AS $$BEGIN
    RETURN QUERY
    SELECT 
        u.id,
        u.role,
        u.email,
        u.full_name,
        u.phone_number,
        u.date_of_birth,
        u.avatar_url,
        u.is_active,
        u.is_deleted,
        u.created_at,
        -- COALESCE sẽ lấy giá trị đầu tiên KHÔNG NULL.
        -- Nếu là BUSINESS, nó lấy b.address. Nếu là TOURIST, nó lấy t.address. Nếu là ADMIN thì trả về NULL.
        COALESCE(b.address) AS address
    FROM public.users u
    -- Nối với bảng businesses (chỉ nối nếu role là BUSINESS)
    LEFT JOIN public.businesses b ON u.id = b.id AND u.role = 'BUSINESS'
    -- Nối với bảng tourists (chỉ nối nếu role là TOURIST)
    LEFT JOIN public.tourists t ON u.id = t.id AND u.role = 'TOURIST'
    WHERE u.id = p_user_id;
END;$$;


--
-- Name: get_user_statistics(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_statistics() RETURNS TABLE(total_users bigint, new_this_month bigint, total_admins bigint)
    LANGUAGE plpgsql
    AS $$BEGIN
    RETURN QUERY
    SELECT 
        -- 1. Đếm tổng user (chỉ đếm những user chưa bị xóa mềm)
        COUNT(*) AS total_users,
        
        -- 2. Đếm user mới trong tháng hiện tại
        COUNT(*) FILTER (
            WHERE date_trunc('month', created_at) = date_trunc('month', CURRENT_DATE)
        ) AS new_this_month,
        
        -- 3. Đếm số lượng Admin
        COUNT(*) FILTER (
            WHERE role = 'ADMIN'
        ) AS total_admins
        
    FROM public.users
    WHERE is_deleted = '0'; -- Bỏ qua các user đã bị xóa
END;$$;


--
-- Name: get_users_list(integer, integer, text, text, bit, bit); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_users_list(page_number integer DEFAULT 1, page_size integer DEFAULT 10, search_text text DEFAULT NULL::text, filter_role text DEFAULT NULL::text, filter_is_active bit DEFAULT NULL::"bit", filter_is_deleted bit DEFAULT NULL::"bit") RETURNS TABLE(total_count bigint, id uuid, role text, email text, full_name text, is_active bit, is_deleted bit, created_at timestamp with time zone, avatar_url text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    calc_offset INT;
BEGIN
    -- Tính toán vị trí bắt đầu (Offset)
    calc_offset := (page_number - 1) * page_size;

    RETURN QUERY
    SELECT 
        COUNT(*) OVER() AS total_count,
        u.id,
        u.role,
        u.email,
        u.full_name,
        u.is_active,
        u.is_deleted,
        u.created_at,
        u.avatar_url
    FROM public.users u
    WHERE 
        -- Lọc theo Search (Tìm tương đối ILIKE trên Tên và Email)
        (search_text IS NULL OR u.full_name ILIKE '%' || search_text || '%' OR u.email ILIKE '%' || search_text || '%')
        
        -- Lọc theo Role
        AND (filter_role IS NULL OR u.role = filter_role)
        
        -- Lọc theo Trạng thái hoạt động
        AND (filter_is_active IS NULL OR u.is_active = filter_is_active)
        
        -- Lọc theo Trạng thái xóa mềm
        AND (filter_is_deleted IS NULL OR u.is_deleted = filter_is_deleted)
        
    ORDER BY u.created_at DESC
    LIMIT page_size
    OFFSET calc_offset;
END;
$$;


--
-- Name: handle_new_tourist_registration(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_tourist_registration() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  -- Kiểm tra xem user mới này có role là TOURIST không (ta sẽ truyền từ code NestJS xuống)
  IF (new.raw_user_meta_data->>'role') = 'TOURIST' THEN
    -- Móc dữ liệu từ metadata và chèn vào bảng tourists
    INSERT INTO public.tourists (id, email, full_name, gender, phone_number)
    VALUES (
      new.id, 
      new.email,
      new.raw_user_meta_data->>'full_name', -- Lưu ý: Key json phải map với NestJS
      new.raw_user_meta_data->>'gender',
      new.raw_user_meta_data->>'phone_number'
    );
  END IF;
  RETURN new;
END;
$$;


--
-- Name: handle_new_user_registration(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user_registration() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    user_role TEXT;
    user_status BIT; -- Khai báo thêm biến trạng thái
BEGIN
    -- 1. Lấy role từ metadata
    user_role := COALESCE(new.raw_user_meta_data->>'role', 'TOURIST');
    
    -- 2. Lấy trạng thái từ metadata (Nếu gửi lên 'LOCKED' thì gán '0', còn lại mặc định '1')
    IF new.raw_user_meta_data->>'status' = 'LOCKED' THEN
        user_status := B'0';
    ELSE
        user_status := B'1';
    END IF;

    -- 3. LUÔN LUÔN tạo 1 record ở bảng cha (public.users) trước
    INSERT INTO public.users (id, role, email, full_name, phone_number, avatar_url, is_active)
    VALUES (
        new.id, 
        user_role, 
        new.email,
        COALESCE(new.raw_user_meta_data->>'full_name', 'Unknown User'),
        new.raw_user_meta_data->>'phone_number',
        new.raw_user_meta_data->>'avatar_url',
        user_status -- Chèn thêm trạng thái vào đây
    );

    -- 4. Dựa vào role, rẽ nhánh insert vào các bảng con tương ứng
    CASE user_role
        WHEN 'TOURIST' THEN
            INSERT INTO public.tourists (id, gender)
            VALUES (new.id, new.raw_user_meta_data->>'gender');
            
        WHEN 'BUSINESS' THEN
            INSERT INTO public.businesses (id, address)
            VALUES (new.id, new.raw_user_meta_data->>'address');

        WHEN 'ADMIN' THEN
            NULL; 
            
        ELSE
            RAISE NOTICE 'Role không hợp lệ: %', user_role;
    END CASE;
    
    RETURN new;
END;
$$;


--
-- Name: soft_delete_users(uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.soft_delete_users(p_user_ids uuid[]) RETURNS integer
    LANGUAGE plpgsql
    AS $$DECLARE
    v_deleted_count INT;
BEGIN
    UPDATE public.users
    SET 
        is_deleted = '1',
        is_active = '0'  -- Bổ sung: Vô hiệu hóa trạng thái hoạt động của user
    WHERE id = ANY(p_user_ids) 
      AND (is_deleted IS NULL OR is_deleted = '0'); -- Tránh update lại những user đã xóa rồi

    -- Lấy số lượng dòng đã bị ảnh hưởng (đã update thành công)
    GET DIAGNOSTICS v_deleted_count = ROW_COUNT;
    
    RETURN v_deleted_count;
END;$$;


--
-- Name: update_business_profile(uuid, text, text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_business_profile(user_id_param uuid, new_full_name text DEFAULT NULL::text, new_phone_number text DEFAULT NULL::text, new_identity_card text DEFAULT NULL::text, new_dob text DEFAULT NULL::text, new_address text DEFAULT NULL::text, new_avatar_url text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Cập nhật các trường chung ở bảng users
    UPDATE public.users
    SET 
        full_name = COALESCE(new_full_name, full_name),
        phone_number = COALESCE(new_phone_number, phone_number),
        date_of_birth = COALESCE(new_dob::DATE, date_of_birth),
        avatar_url = COALESCE(new_avatar_url, avatar_url)
    WHERE id = user_id_param;

    -- Cập nhật các trường riêng ở bảng businesses
    UPDATE public.businesses
    SET 
        identity_card = COALESCE(new_identity_card, identity_card),
        address = COALESCE(new_address, address)
    WHERE id = user_id_param;
END;
$$;


--
-- Name: update_tourist_profile(uuid, text, text, text, text, text[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_tourist_profile(user_id_param uuid, new_full_name text DEFAULT NULL::text, new_gender text DEFAULT NULL::text, new_phone_number text DEFAULT NULL::text, new_email text DEFAULT NULL::text, new_preferences text[] DEFAULT NULL::text[], new_avatar_url text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Cập nhật các trường chung ở bảng users
    UPDATE public.users
    SET 
        full_name = COALESCE(new_full_name, full_name),
        phone_number = COALESCE(new_phone_number, phone_number),
        -- Lưu ý: Nếu đổi email ở đây, nó chỉ đổi ở schema public. 
        -- Email để đăng nhập ở auth.users vẫn giữ nguyên trừ khi bạn gọi API đổi email của Supabase Auth.
        email = COALESCE(new_email, email), 
        avatar_url = COALESCE(new_avatar_url, avatar_url)
    WHERE id = user_id_param;

    -- Cập nhật các trường riêng ở bảng tourists
    UPDATE public.tourists
    SET 
        gender = COALESCE(new_gender, gender),
        travel_preferences = COALESCE(new_preferences, travel_preferences)
    WHERE id = user_id_param;
END;
$$;


--
-- Name: update_user_active_status(uuid, bit); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_user_active_status(p_user_id uuid, p_is_active bit) RETURNS boolean
    LANGUAGE plpgsql
    AS $$BEGIN
    UPDATE public.users
    SET is_active = p_is_active
    WHERE id = p_user_id;

    -- Kiểm tra xem có dòng nào thực sự được update không
    IF FOUND THEN
        RETURN TRUE;
    ELSE
        RAISE EXCEPTION 'Không tìm thấy người dùng để cập nhật trạng thái';
    END IF;
END;$$;


--
-- Name: update_user_avatar(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_user_avatar(p_user_id uuid, p_avatar_url text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE users 
  SET avatar_url = p_avatar_url
  WHERE id = p_user_id;
END;
$$;


--
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_
        -- Filter by action early - only get subscriptions interested in this action
        -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
        and (subs.action_filter = '*' or subs.action_filter = action::text);

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


--
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


--
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


--
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


--
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS TABLE(wal jsonb, is_rls_enabled boolean, subscription_ids uuid[], errors text[], slot_changes_count bigint)
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL AND ppt.tablename NOT LIKE '% %'),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  -- Count raw slot entries before apply_rls/subscription filter
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  -- Apply RLS and filter as before
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  -- Real rows with slot count attached
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  -- Sentinel row: always returned when no real rows exist so Elixir can
  -- always read slot_changes_count. Identified by wal IS NULL.
  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


--
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


--
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


--
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- Name: allow_any_operation(text[]); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_any_operation(expected_operations text[]) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


--
-- Name: allow_only_operation(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.allow_only_operation(expected_operation text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


--
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


--
-- Name: get_common_prefix(text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_common_prefix(p_key text, p_prefix text, p_delimiter text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(_bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.protect_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


--
-- Name: search_by_timestamp(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_by_timestamp(p_prefix text, p_bucket_id text, p_limit integer, p_level integer, p_start_after text, p_sort_order text, p_sort_column text, p_sort_column_after text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


--
-- Name: search_v2(text, text, integer, integer, text, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text, sort_order text DEFAULT 'asc'::text, sort_column text DEFAULT 'name'::text, sort_column_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


--
-- Name: create_full_place(text, text, text, numeric, numeric, uuid, text[], jsonb, jsonb, text[], text, text, text); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.create_full_place(p_name text, p_address text, p_city text, p_lat numeric, p_lng numeric, p_vendor_id uuid, p_categories text[], p_services jsonb DEFAULT '[]'::jsonb, p_menu jsonb DEFAULT '[]'::jsonb, p_images text[] DEFAULT '{}'::text[], p_open_time text DEFAULT '08:00'::text, p_close_time text DEFAULT '22:00'::text, p_description text DEFAULT ''::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'travel', 'order_sys'
    AS $$
DECLARE
    v_place_id   UUID;
    v_city_id    UUID;
    v_cat        TEXT;
    v_cat_id     UUID;
    v_service    JSONB;
    v_service_id UUID;
    v_item       JSONB;
BEGIN

SELECT id INTO v_city_id
FROM travel.cities
WHERE LOWER(TRIM(name)) = LOWER(TRIM(p_city))
LIMIT 1;

IF v_city_id IS NULL THEN
    RAISE EXCEPTION 'City not found: %', p_city;
END IF;

INSERT INTO travel.places(name, address, city_id, latitude, longitude, vendor_id, image_url,open_time, close_time,description, is_approved)
VALUES (p_name, p_address, v_city_id, p_lat, p_lng, p_vendor_id, p_images,p_open_time::time, p_close_time::time,p_description, null)
RETURNING id INTO v_place_id;

IF p_categories IS NOT NULL AND array_length(p_categories, 1) > 0 THEN
    FOREACH v_cat IN ARRAY p_categories LOOP
        SELECT id INTO v_cat_id
        FROM travel.categories
        WHERE LOWER(TRIM(name)) = LOWER(TRIM(v_cat))
        LIMIT 1;

        IF v_cat_id IS NOT NULL THEN
            INSERT INTO travel.place_categories(place_id, category_id)
            VALUES (v_place_id, v_cat_id)
            ON CONFLICT DO NOTHING;
        ELSE
            RAISE EXCEPTION 'Category not found: %', v_cat;
        END IF;
    END LOOP;
END IF;

IF p_services IS NOT NULL AND jsonb_array_length(p_services) > 0 THEN
    FOR v_service IN SELECT * FROM jsonb_array_elements(p_services) LOOP
        SELECT id INTO v_service_id
        FROM travel.services
        WHERE LOWER(TRIM(name)) = LOWER(TRIM(v_service->>'name'))
        LIMIT 1;

        IF v_service_id IS NULL THEN
            INSERT INTO travel.services(name, description)
            VALUES (v_service->>'name', v_service->>'description')
            RETURNING id INTO v_service_id;
        END IF;

        INSERT INTO travel.place_services(place_id, service_id)
        VALUES (v_place_id, v_service_id)
        ON CONFLICT DO NOTHING;
    END LOOP;
END IF;

IF p_menu IS NOT NULL AND jsonb_array_length(p_menu) > 0 THEN
    FOR v_item IN SELECT * FROM jsonb_array_elements(p_menu) LOOP
        INSERT INTO order_sys.food_items(name, description, price, place_id)
        VALUES (
            v_item->>'name',
            v_item->>'description',
            (v_item->>'price')::NUMERIC,
            v_place_id
        );
    END LOOP;
END IF;

RETURN v_place_id;
END;
$$;


--
-- Name: create_full_place_v2(text, text, text, numeric, numeric, uuid, text[], jsonb, jsonb, text[], text, text, text); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.create_full_place_v2(p_name text, p_address text, p_city text, p_lat numeric, p_lng numeric, p_vendor_id uuid, p_categories text[], p_services jsonb DEFAULT '[]'::jsonb, p_menu jsonb DEFAULT '[]'::jsonb, p_images text[] DEFAULT '{}'::text[], p_open_time text DEFAULT '08:00'::text, p_close_time text DEFAULT '22:00'::text, p_description text DEFAULT ''::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'travel', 'order_sys'
    AS $$
DECLARE
    v_place_id   UUID;
    v_city_id    UUID;
    v_cat        TEXT;
    v_cat_id     UUID;
    v_service    JSONB;
    v_service_id UUID;
    v_item       JSONB;
BEGIN

SELECT id INTO v_city_id
FROM travel.cities
WHERE LOWER(TRIM(name)) = LOWER(TRIM(p_city))
LIMIT 1;

IF v_city_id IS NULL THEN
    RAISE EXCEPTION 'City not found: %', p_city;
END IF;

INSERT INTO travel.places(name, address, city_id, latitude, longitude, vendor_id, image_url,open_time, close_time,description, is_approved)
VALUES (p_name, p_address, v_city_id, p_lat, p_lng, p_vendor_id, p_images,p_open_time::time, p_close_time::time,p_description, null)
RETURNING id INTO v_place_id;

IF p_categories IS NOT NULL AND array_length(p_categories, 1) > 0 THEN
    FOREACH v_cat IN ARRAY p_categories LOOP
        SELECT id INTO v_cat_id
        FROM travel.categories
        WHERE LOWER(TRIM(name)) = LOWER(TRIM(v_cat))
        LIMIT 1;

        IF v_cat_id IS NOT NULL THEN
            INSERT INTO travel.place_categories(place_id, category_id)
            VALUES (v_place_id, v_cat_id)
            ON CONFLICT DO NOTHING;
        ELSE
            RAISE EXCEPTION 'Category not found: %', v_cat;
        END IF;
    END LOOP;
END IF;

IF p_services IS NOT NULL AND jsonb_array_length(p_services) > 0 THEN
    FOR v_service IN SELECT * FROM jsonb_array_elements(p_services) LOOP
        SELECT id INTO v_service_id
        FROM travel.services
        WHERE LOWER(TRIM(name)) = LOWER(TRIM(v_service->>'name'))
        LIMIT 1;

        IF v_service_id IS NULL THEN
            INSERT INTO travel.services(name, description)
            VALUES (v_service->>'name', v_service->>'description')
            RETURNING id INTO v_service_id;
        END IF;

        INSERT INTO travel.place_services(place_id, service_id)
        VALUES (v_place_id, v_service_id)
        ON CONFLICT DO NOTHING;
    END LOOP;
END IF;

IF p_menu IS NOT NULL AND jsonb_array_length(p_menu) > 0 THEN
    FOR v_item IN SELECT * FROM jsonb_array_elements(p_menu) LOOP
        INSERT INTO order_sys.food_items(name, description, price, place_id)
        VALUES (
            v_item->>'name',
            v_item->>'description',
            (v_item->>'price')::NUMERIC,
            v_place_id
        );
    END LOOP;
END IF;

RETURN v_place_id;
END;
$$;


--
-- Name: create_place_full(text, text, text, numeric, numeric, text[], text[], jsonb); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.create_place_full(p_name text, p_address text, p_city text, p_lat numeric, p_lng numeric, p_categories text[], p_services text[] DEFAULT '{}'::text[], p_menu jsonb DEFAULT 'null'::jsonb) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
    v_place_id UUID;
    v_cat TEXT;
    v_cat_id UUID;
    v_service TEXT;
    v_service_id UUID;
BEGIN

INSERT INTO travel.places(
    name, address, city, latitude, longitude, vendor_id, is_approved
)
VALUES (
    p_name, p_address, p_city, p_lat, p_lng, auth.uid(), false
)
RETURNING id INTO v_place_id;

FOREACH v_cat IN ARRAY p_categories
LOOP
    SELECT id INTO v_cat_id
    FROM travel.categories
    WHERE LOWER(name) = LOWER(v_cat)
    LIMIT 1;

    IF v_cat_id IS NOT NULL THEN
        INSERT INTO travel.place_categories(place_id, category_id)
        VALUES (v_place_id, v_cat_id);
    END IF;
END LOOP;

FOREACH v_service IN ARRAY p_services
LOOP
    SELECT id INTO v_service_id
    FROM travel.services
    WHERE LOWER(name) = LOWER(v_service)
    LIMIT 1;

    IF v_service_id IS NOT NULL THEN
        INSERT INTO travel.place_services(place_id, service_id)
        VALUES (v_place_id, v_service_id);
    END IF;
END LOOP;

IF p_menu IS NOT NULL AND p_menu != 'null' THEN
    INSERT INTO travel.menus(place_id, items)
    VALUES (v_place_id, p_menu);
END IF;

RETURN v_place_id;

END;
$$;


--
-- Name: get_business_dashboard(uuid); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.get_business_dashboard(p_vendor_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE result JSON;
BEGIN

SELECT json_build_object(

    'total_places',
    (
        SELECT COUNT(*)
        FROM travel.places
        WHERE vendor_id = p_vendor_id
    ),

    'total_orders',
    (
        SELECT COUNT(*)
        FROM order_sys.orders o
        JOIN travel.itinerary_details d
        ON d.id = o.itinerary_detail_id
        JOIN travel.places p
        ON p.id = d.place_id
        WHERE p.vendor_id = p_vendor_id and o.status <> 'completed'
    ),

    'total_food_items',
    (
        SELECT COUNT(*)
        FROM order_sys.food_items f
        JOIN travel.places p
        ON p.id = f.place_id
        WHERE p.vendor_id = p_vendor_id
    ),

    'average_rating',
    (
        SELECT COALESCE(AVG(average_rating),0)
        FROM travel.places
        WHERE vendor_id = p_vendor_id
    )

)
INTO result;

RETURN result;

END;
$$;


--
-- Name: get_my_itineraries(uuid); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.get_my_itineraries(p_user_id uuid) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE result JSON;
BEGIN

SELECT json_build_object(

    'stats',
    json_build_object(
        'total', COUNT(*),
        'completed', COUNT(*) FILTER (WHERE status='completed'),
        'upcoming', COUNT(*) FILTER (WHERE status = 'ongoing'),
        'draft', COUNT(*) FILTER (WHERE status is null)
    ),

    'itineraries',
    (
        SELECT json_agg(
            json_build_object(
                'id', i.id,
                'description', i.description,
                'destination', i.destination,
                'start_date', i.start_date,
                'end_date', i.end_date,
                'status', i.status,
                'days', (i.end_date - i.start_date),
                'progress',
                    CASE
                        WHEN i.status='completed' THEN 100
                        WHEN CURRENT_DATE BETWEEN i.start_date AND i.end_date
                        THEN 50
                        ELSE 0
                    END
            )
        )
        FROM travel.itineraries i
        WHERE i.creator_id = p_user_id
    )

)
INTO result
FROM travel.itineraries
WHERE creator_id = p_user_id;

RETURN result;

END;
$$;


--
-- Name: get_place_detail(uuid); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.get_place_detail(p_place_id uuid) RETURNS TABLE(place_id uuid, place_name text, address text, city text, latitude numeric, longitude numeric, open_time time without time zone, close_time time without time zone, description text, status text, rating numeric, category text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        p.id,
        p.name::TEXT,
        p.address::TEXT,
        ci.name::TEXT,
        p.latitude,
        p.longitude,
        p.open_time,
        p.close_time,
        p.description::TEXT,
        CASE
            WHEN p.is_approved THEN 'Đã duyệt'
            ELSE 'Đang chờ'
        END::TEXT,
        p.average_rating,
        c.name::TEXT
    FROM travel.places p
    LEFT JOIN travel.place_categories pc
        ON pc.place_id = p.id
    LEFT JOIN travel.categories c
        ON c.id = pc.category_id
    JOIN travel.cities ci on ci.id = p.city_id
    WHERE p.id = p_place_id;
END;
$$;


--
-- Name: get_place_services_and_menu(uuid); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.get_place_services_and_menu(p_place_id uuid) RETURNS TABLE(service_name text, food_id uuid, food_name text, description text, price numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        s.name::TEXT,
        f.id,
        f.name::TEXT,
        f.description::TEXT,
        f.price
    FROM travel.places p
    LEFT JOIN travel.place_services ps
        ON ps.place_id = p.id
    LEFT JOIN travel.services s
        ON s.id = ps.service_id
    LEFT JOIN order_sys.food_items f
        ON f.place_id = p.id
    WHERE p.id = p_place_id;
END;
$$;


--
-- Name: get_places_by_filter(text, text); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.get_places_by_filter(p_city text, p_category text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
BEGIN

IF LOWER(p_category) = 'itinerary' THEN

    RETURN (
        SELECT jsonb_agg(it)
        FROM travel.itineraries it
        WHERE 
            (
                unaccent(it.destination) ILIKE '%' || unaccent(p_city) || '%'
                OR similarity(unaccent(it.destination), unaccent(p_city)) > 0.3
            )
            AND it.status = 'completed'
    );

ELSE

    RETURN (
        SELECT jsonb_agg(p)
        FROM travel.places p
        JOIN travel.place_categories pc ON pc.place_id = p.id
        JOIN travel.categories c ON c.id = pc.category_id
        JOIN travel.cities ci ON ci.id = p.city_id
        WHERE 
            (
                unaccent(ci.name) ILIKE '%' || unaccent(p_city) || '%'
                OR similarity(unaccent(ci.name), unaccent(p_city)) > 0.3
            )
        AND LOWER(c.name) = LOWER(p_category)
    );

END IF;

END;
$$;


--
-- Name: get_places_by_vendor(uuid); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.get_places_by_vendor(p_vendor_id uuid) RETURNS TABLE(place_id uuid, place_name text, address text, city text, category text, status text, rating numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.name::TEXT,
        p.address::TEXT,
        p.city::TEXT,
        c.name::TEXT,
        CASE 
            WHEN p.is_approved = true THEN 'Đã duyệt'
            ELSE 'Đang chờ'
        END::TEXT,
        p.average_rating
    FROM travel.places p
    LEFT JOIN travel.place_categories pc 
        ON pc.place_id = p.id
    LEFT JOIN travel.categories c 
        ON c.id = pc.category_id
    WHERE p.vendor_id = p_vendor_id
    ORDER BY p.registered_date DESC;
END;
$$;


--
-- Name: search_autocomplete(text); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.search_autocomplete(p_query text) RETURNS TABLE(id uuid, name text, type text, score double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN

RETURN QUERY

-- ===== CITY (ưu tiên cao nhất) =====
SELECT 
    c.id,
    c.name::TEXT,
    'city',
    
    -- prefix match boost
    (
        CASE 
            WHEN unaccent(c.name) ILIKE unaccent(p_query || '%') THEN 3
            ELSE 0
        END
        +
        similarity(unaccent(c.name), unaccent(p_query))
    ) AS score

FROM travel.places p
Join travel.cities c on c.id = p.city_id
GROUP BY c.id, c.name

HAVING 
    unaccent(c.name) ILIKE '%' || unaccent(p_query) || '%'
    OR similarity(unaccent(c.name), unaccent(p_query)) > 0.3

UNION

-- ===== PLACE =====
SELECT 
    p.id,
    p.name::TEXT,
    'place',

    (
        CASE 
            WHEN unaccent(p.name) ILIKE unaccent(p_query || '%') THEN 3
            ELSE 0
        END
        +
        similarity(unaccent(p.name), unaccent(p_query))
    ) AS score

FROM travel.places p
WHERE 
    unaccent(p.name) ILIKE '%' || unaccent(p_query) || '%'
    OR similarity(unaccent(p.name), unaccent(p_query)) > 0.3

ORDER BY score DESC
LIMIT 10;

END;
$$;


--
-- Name: search_places_advanced(text); Type: FUNCTION; Schema: travel; Owner: -
--

CREATE FUNCTION travel.search_places_advanced(p_query text) RETURNS TABLE(id uuid, name text, address text, city text, rating numeric, type text, score double precision)
    LANGUAGE plpgsql
    AS $$
BEGIN

RETURN QUERY

-- ===== PLACE =====
SELECT 
    p.id,
    p.name::TEXT,
    p.address::TEXT,
    p.city::TEXT,
    p.average_rating,
    'place',
    
    -- scoring
    (
        similarity(unaccent(p.name), unaccent(p_query)) * 2 +
        similarity(unaccent(p.city), unaccent(p_query)) +
        (p.average_rating / 5)
    ) AS score

FROM travel.places p
WHERE
    unaccent(p.name) ILIKE '%' || unaccent(p_query) || '%'
    OR similarity(unaccent(p.name), unaccent(p_query)) > 0.3
    OR unaccent(p.city) ILIKE '%' || unaccent(p_query) || '%'

UNION

-- ===== CITY =====
SELECT 
    NULL,
    p.city::TEXT,
    ''::TEXT,
    p.city::TEXT,
    0,
    'city',
    
    similarity(unaccent(p.city), unaccent(p_query)) + 1

FROM travel.places p
WHERE similarity(unaccent(p.city), unaccent(p_query)) > 0.3

GROUP BY p.city

ORDER BY score DESC
LIMIT 10;

END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: notifications; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.notifications (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    title character varying(255),
    content text,
    notification_type character varying(100),
    status character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: user_notifications; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.user_notifications (
    notification_id uuid NOT NULL,
    user_id uuid NOT NULL,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: users; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.users (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    full_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    gender character varying(20),
    role core.user_role_enum NOT NULL,
    phone character(10),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    preferences jsonb
);


--
-- Name: food_items; Type: TABLE; Schema: order_sys; Owner: -
--

CREATE TABLE order_sys.food_items (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(200),
    description text,
    price numeric(10,2),
    place_id uuid,
    image_url text[] DEFAULT '{}'::text[],
    category text,
    is_active boolean DEFAULT true,
    foody_dish_id text,
    foody_dish_type_id text
);


--
-- Name: order_items; Type: TABLE; Schema: order_sys; Owner: -
--

CREATE TABLE order_sys.order_items (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    quantity integer,
    unit_price numeric(10,2),
    total_price numeric(12,2),
    order_id uuid,
    food_item_id uuid
);


--
-- Name: orders; Type: TABLE; Schema: order_sys; Owner: -
--

CREATE TABLE order_sys.orders (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    ordered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    total_amount numeric(12,2),
    status order_sys.order_status_enum,
    notes text,
    tourist_id uuid,
    itinerary_detail_id uuid
);


--
-- Name: businesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.businesses (
    id uuid NOT NULL,
    identity_card text,
    address text,
    is_approved boolean DEFAULT false
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    title text NOT NULL,
    content text,
    type character varying(50),
    is_global boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);


--
-- Name: tourists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourists (
    id uuid NOT NULL,
    gender text,
    travel_preferences text[] DEFAULT '{}'::text[]
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    role text NOT NULL,
    email text NOT NULL,
    full_name text NOT NULL,
    phone_number text,
    date_of_birth date,
    avatar_url text,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    is_active bit(1) DEFAULT '1'::"bit",
    is_deleted bit(1) DEFAULT '0'::"bit",
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['TOURIST'::text, 'BUSINESS'::text, 'ADMIN'::text])))
);


--
-- Name: users_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users_notifications (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    notification_id uuid NOT NULL,
    is_read boolean DEFAULT false,
    read_at timestamp with time zone,
    sent_at timestamp with time zone DEFAULT timezone('utc'::text, now())
);


--
-- Name: v_cat_id; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.v_cat_id (
    id uuid
);


--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- Name: messages_2026_05_03; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_05_03 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: messages_2026_05_04; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_05_04 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: messages_2026_05_05; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_05_05 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: messages_2026_05_06; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_05_06 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: messages_2026_05_07; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages_2026_05_07 (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    action_filter text DEFAULT '*'::text,
    CONSTRAINT subscription_action_filter_check CHECK ((action_filter = ANY (ARRAY['*'::text, 'INSERT'::text, 'UPDATE'::text, 'DELETE'::text])))
);


--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: itinerary_reviews; Type: TABLE; Schema: review_ai; Owner: -
--

CREATE TABLE review_ai.itinerary_reviews (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    itinerary_id uuid,
    tourist_id uuid,
    rating integer,
    content text,
    url_image text[] DEFAULT '{}'::text[],
    tags text[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status text DEFAULT 'pending'::text NOT NULL,
    CONSTRAINT itinerary_reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: review_conflicts; Type: TABLE; Schema: review_ai; Owner: -
--

CREATE TABLE review_ai.review_conflicts (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    new_content_id uuid,
    old_content_id uuid,
    conflict_score double precision,
    conflict_topic review_ai.topic_enum,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: review_contents; Type: TABLE; Schema: review_ai; Owner: -
--

CREATE TABLE review_ai.review_contents (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    review_id uuid,
    content text,
    processing_status review_ai.processing_status_enum DEFAULT 'pending'::review_ai.processing_status_enum,
    time_label review_ai.time_label_enum,
    expiration_date timestamp without time zone,
    main_topic review_ai.topic_enum,
    topic_scores jsonb,
    sentiment_scores jsonb,
    embedding extensions.vector(768),
    error_info jsonb,
    has_conflict boolean DEFAULT false,
    is_temporary boolean DEFAULT false
);


--
-- Name: reviews; Type: TABLE; Schema: review_ai; Owner: -
--

CREATE TABLE review_ai.reviews (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tourist_id uuid,
    place_id uuid,
    rating integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    review_type review_ai.review_type_enum,
    status review_ai.review_status_enum DEFAULT 'pending'::review_ai.review_status_enum,
    itinerary_id uuid,
    provider character varying(100),
    url_image text[] DEFAULT '{}'::text[],
    tags text[],
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    name text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_vectors (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'VECTOR'::storage.buckettype NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb
);


--
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb,
    metadata jsonb
);


--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.vector_indexes (
    id text DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    bucket_id text NOT NULL,
    data_type text NOT NULL,
    dimension integer NOT NULL,
    distance_metric text NOT NULL,
    metadata_configuration jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: geofence_visits; Type: TABLE; Schema: tracking; Owner: -
--

CREATE TABLE tracking.geofence_visits (
    geofence_id uuid NOT NULL,
    itinerary_detail_id uuid NOT NULL,
    status tracking.visit_status_enum DEFAULT 'not_visited'::tracking.visit_status_enum,
    recorded_at timestamp without time zone
);


--
-- Name: geofences; Type: TABLE; Schema: tracking; Owner: -
--

CREATE TABLE tracking.geofences (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(100),
    polygon extensions.geometry(Polygon,4326),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true
);


--
-- Name: transport_modes; Type: TABLE; Schema: tracking; Owner: -
--

CREATE TABLE tracking.transport_modes (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(100),
    transport_type character varying(100)
);


--
-- Name: transport_pricing_rules; Type: TABLE; Schema: tracking; Owner: -
--

CREATE TABLE tracking.transport_pricing_rules (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    transport_mode_id uuid,
    distance_range character varying(100),
    price numeric(12,2)
);


--
-- Name: transport_to_destination; Type: TABLE; Schema: tracking; Owner: -
--

CREATE TABLE tracking.transport_to_destination (
    transport_mode_id uuid NOT NULL,
    total_cost numeric(12,2),
    itinerary_id uuid NOT NULL
);


--
-- Name: transport_within_city; Type: TABLE; Schema: tracking; Owner: -
--

CREATE TABLE tracking.transport_within_city (
    transport_mode_id uuid NOT NULL,
    itinerary_detail_id uuid NOT NULL,
    total_cost numeric(12,2)
);


--
-- Name: activity_logs; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.activity_logs (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    tourist_id uuid,
    action_type character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    place_id uuid
);


--
-- Name: categories; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.categories (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: cities; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.cities (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: favorite_itineraries; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.favorite_itineraries (
    tourist_id uuid NOT NULL,
    itinerary_id uuid NOT NULL,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: favorite_places; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.favorite_places (
    tourist_id uuid NOT NULL,
    place_id uuid NOT NULL,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: itineraries; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.itineraries (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    creator_id uuid,
    description character varying(255),
    start_date date,
    end_date date,
    estimated_cost numeric(12,2),
    status travel.itinerary_status_enum,
    departure_point character varying(255),
    destination character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    actual_cost numeric(12,2),
    is_public boolean DEFAULT false,
    adult_count integer DEFAULT 1,
    children_count integer DEFAULT 0
);


--
-- Name: itinerary_details; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.itinerary_details (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    itinerary_id uuid,
    place_id uuid,
    visit_date date,
    arrival_time time without time zone,
    departure_time time without time zone,
    notes text,
    estimated_cost numeric(12,2),
    transport_cost numeric(12,2),
    actual_cost numeric(12,2),
    cost_updated_at timestamp without time zone,
    is_locked boolean DEFAULT false,
    duration_minutes integer DEFAULT 60,
    sequence_order integer,
    user_notes text,
    locked_arrive_time time without time zone
);


--
-- Name: itinerary_members; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.itinerary_members (
    tourist_id uuid NOT NULL,
    itinerary_id uuid NOT NULL,
    added_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: place_services; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.place_services (
    place_id uuid NOT NULL,
    service_id uuid NOT NULL
);


--
-- Name: place_tags; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.place_tags (
    place_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


--
-- Name: places; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.places (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    longitude numeric(10,6),
    latitude numeric(10,6),
    address character varying(200),
    is_approved boolean DEFAULT false,
    average_rating numeric(3,2) DEFAULT 0,
    review_count integer DEFAULT 0,
    open_time time without time zone,
    close_time time without time zone,
    description text,
    is_active boolean DEFAULT true,
    registered_date date DEFAULT CURRENT_DATE,
    vendor_id uuid,
    image_url text[] DEFAULT '{}'::text[],
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    city_id uuid,
    source_id character varying,
    source character varying,
    type_id uuid,
    vibes text[]
);


--
-- Name: services; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.services (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name text,
    price numeric(10,2)
);


--
-- Name: tags; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.tags (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: types; Type: TABLE; Schema: travel; Owner: -
--

CREATE TABLE travel.types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    category_id uuid NOT NULL
);


--
-- Name: messages_2026_05_03; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_05_03 FOR VALUES FROM ('2026-05-03 00:00:00') TO ('2026-05-04 00:00:00');


--
-- Name: messages_2026_05_04; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_05_04 FOR VALUES FROM ('2026-05-04 00:00:00') TO ('2026-05-05 00:00:00');


--
-- Name: messages_2026_05_05; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_05_05 FOR VALUES FROM ('2026-05-05 00:00:00') TO ('2026-05-06 00:00:00');


--
-- Name: messages_2026_05_06; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_05_06 FOR VALUES FROM ('2026-05-06 00:00:00') TO ('2026-05-07 00:00:00');


--
-- Name: messages_2026_05_07; Type: TABLE ATTACH; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages ATTACH PARTITION realtime.messages_2026_05_07 FOR VALUES FROM ('2026-05-07 00:00:00') TO ('2026-05-08 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.custom_oauth_providers (id, provider_type, identifier, name, client_id, client_secret, acceptable_client_ids, scopes, pkce_enabled, attribute_mapping, authorization_params, enabled, email_optional, issuer, discovery_url, skip_nonce_check, cached_discovery, discovery_cached_at, authorization_url, token_url, userinfo_url, jwks_uri, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at, invite_token, referrer, oauth_client_state_id, linking_target_id, email_optional) FROM stdin;
f04f0af3-a219-4f52-88c1-ba18f6926cd6	\N	\N	\N	\N	google			2026-04-03 17:04:55.015531+00	2026-04-03 17:04:55.015531+00	oauth	\N	\N	http://localhost:5173/auth/callback	\N	\N	f
ceced55b-6e63-486d-b243-1c074c14cbaa	\N	\N	\N	\N	google			2026-04-03 17:13:35.710598+00	2026-04-03 17:13:35.710598+00	oauth	\N	\N	http://localhost:5173/auth/callback	\N	\N	f
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
10f4c984-9b5d-46dd-8d98-00573752f50a	10f4c984-9b5d-46dd-8d98-00573752f50a	{"sub": "10f4c984-9b5d-46dd-8d98-00573752f50a", "role": "BUSINESS", "email": "nvc@gmail.com", "full_name": "Nguyễn Văn C", "phone_number": "0912345670", "email_verified": false, "phone_verified": false}	email	2026-03-27 16:58:06.872484+00	2026-03-27 16:58:06.872541+00	2026-03-27 16:58:06.872541+00	d6b8c0e7-a7ce-4de3-bee5-55b3404ad59d
5f56692b-8daa-4852-bfe7-1032a07635ff	5f56692b-8daa-4852-bfe7-1032a07635ff	{"sub": "5f56692b-8daa-4852-bfe7-1032a07635ff", "role": "TOURIST", "email": "h@gmail.com", "gender": "MALE", "full_name": "Nguyễn Văn B", "phone_number": "0987654321", "email_verified": false, "phone_verified": false}	email	2026-03-28 08:05:30.654769+00	2026-03-28 08:05:30.65541+00	2026-03-28 08:05:30.65541+00	7b6e7ad5-5f74-45f0-9167-7a833e06519c
b7ea8833-6fff-4302-8d1b-4424676cb299	b7ea8833-6fff-4302-8d1b-4424676cb299	{"sub": "b7ea8833-6fff-4302-8d1b-4424676cb299", "role": "BUSINESS", "email": "nva@gmail.com", "full_name": "Nguyễn Văn A", "phone_number": "0912345678", "email_verified": false, "phone_verified": false}	email	2026-03-28 08:31:55.096363+00	2026-03-28 08:31:55.096417+00	2026-03-28 08:31:55.096417+00	03110e6b-943d-460a-8103-3f3e8ad0012a
c6ad1e17-f6f1-4229-8580-b00e595c3050	c6ad1e17-f6f1-4229-8580-b00e595c3050	{"sub": "c6ad1e17-f6f1-4229-8580-b00e595c3050", "role": "BUSINESS", "email": "khanhhanpham88+a1@gmail.com", "full_name": "Kim Seok Jin", "phone_number": "0123123123", "email_verified": false, "phone_verified": false}	email	2026-03-28 08:47:30.14178+00	2026-03-28 08:47:30.142401+00	2026-03-28 08:47:30.142401+00	4d953fce-8d43-4d9b-ba01-b701ca10c9bc
ca38c166-41e5-4f9d-b14a-caa71d08be01	ca38c166-41e5-4f9d-b14a-caa71d08be01	{"sub": "ca38c166-41e5-4f9d-b14a-caa71d08be01", "role": "ADMIN", "email": "admin@gmail.com", "full_name": "Trần Quản Trị", "avatar_url": "https://api.dicebear.com/7.x/avataaars/svg?seed=Admin", "phone_number": "0901234567", "email_verified": false, "phone_verified": false}	email	2026-03-28 09:21:47.252174+00	2026-03-28 09:21:47.252227+00	2026-03-28 09:21:47.252227+00	ec69c088-8648-467d-a9d1-45fd9026708b
20172a2f-f0a1-4449-be0a-75b7cd50f5a3	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	{"sub": "20172a2f-f0a1-4449-be0a-75b7cd50f5a3", "role": "TOURIST", "email": "tourist@gmail.com", "gender": "MALE", "full_name": "Nguyễn Văn B", "phone_number": "0987654321", "email_verified": false, "phone_verified": false}	email	2026-03-28 16:48:02.219204+00	2026-03-28 16:48:02.220456+00	2026-03-28 16:48:02.220456+00	1ded0f5d-c425-4b0f-b814-5a81d1ecf23a
9a54cb41-ee7d-417e-9563-9fb95a35c29c	9a54cb41-ee7d-417e-9563-9fb95a35c29c	{"sub": "9a54cb41-ee7d-417e-9563-9fb95a35c29c", "role": "TOURIST", "email": "delete@gmail.com", "gender": "MALE", "full_name": "Nguyễn Văn B", "phone_number": "0987654321", "email_verified": false, "phone_verified": false}	email	2026-03-30 14:21:19.778906+00	2026-03-30 14:21:19.779598+00	2026-03-30 14:21:19.779598+00	9c47d05f-0111-4fbc-9dc3-40167db16812
353b8afb-61a8-4233-96dd-480e99a0ff83	353b8afb-61a8-4233-96dd-480e99a0ff83	{"sub": "353b8afb-61a8-4233-96dd-480e99a0ff83", "email": "knjoon@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-03-30 17:34:26.040376+00	2026-03-30 17:34:26.040432+00	2026-03-30 17:34:26.040432+00	6c00dc2b-47f9-4309-bc37-245751e68324
f1723551-793e-40ee-9996-853d1cfc04cc	f1723551-793e-40ee-9996-853d1cfc04cc	{"sub": "f1723551-793e-40ee-9996-853d1cfc04cc", "email": "abbcc@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-01 14:21:35.000127+00	2026-04-01 14:21:35.000592+00	2026-04-01 14:21:35.000592+00	11126f8b-f769-45bb-9626-6ae8464a33c0
c7910199-028e-4d56-b029-aeb553d977d0	c7910199-028e-4d56-b029-aeb553d977d0	{"sub": "c7910199-028e-4d56-b029-aeb553d977d0", "email": "acd@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-01 14:23:11.203617+00	2026-04-01 14:23:11.204235+00	2026-04-01 14:23:11.204235+00	ee1287c2-8eaa-40dc-a132-5568b906c0d7
c48465fb-520d-445f-b8cc-e8f08c1b8a38	c48465fb-520d-445f-b8cc-e8f08c1b8a38	{"sub": "c48465fb-520d-445f-b8cc-e8f08c1b8a38", "email": "nve@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-01 14:23:32.980381+00	2026-04-01 14:23:32.980448+00	2026-04-01 14:23:32.980448+00	1e67ffc5-2fdc-45ec-aa7c-d616768e418d
93c230f3-cef1-46eb-8289-4bc66ec565ea	93c230f3-cef1-46eb-8289-4bc66ec565ea	{"sub": "93c230f3-cef1-46eb-8289-4bc66ec565ea", "email": "myoongi@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-01 16:33:00.226544+00	2026-04-01 16:33:00.226933+00	2026-04-01 16:33:00.226933+00	d5f74dc0-97a5-4b6d-92f8-0fc40d309c88
da3d14e6-04c0-49a0-b029-901ace58b562	da3d14e6-04c0-49a0-b029-901ace58b562	{"sub": "da3d14e6-04c0-49a0-b029-901ace58b562", "email": "tva@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-05 09:01:37.786745+00	2026-04-05 09:01:37.78928+00	2026-04-05 09:01:37.78928+00	1a52d0ca-5430-463a-a8bb-8b8407be2f05
d2b3704a-f14e-47ad-a8e4-8a7fa617f32a	d2b3704a-f14e-47ad-a8e4-8a7fa617f32a	{"sub": "d2b3704a-f14e-47ad-a8e4-8a7fa617f32a", "email": "tvd@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-05 09:20:54.413568+00	2026-04-05 09:20:54.414241+00	2026-04-05 09:20:54.414241+00	73c527fe-95c6-4a04-9183-4ab56c6f8861
0f32ae0f-8c18-4b34-8f38-47e40a4bf11a	0f32ae0f-8c18-4b34-8f38-47e40a4bf11a	{"sub": "0f32ae0f-8c18-4b34-8f38-47e40a4bf11a", "email": "tvh@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-04-05 09:28:15.85157+00	2026-04-05 09:28:15.852201+00	2026-04-05 09:28:15.852201+00	2c80ab94-4bfc-4c32-94f4-b6c177895eb0
101386552149340484598	b326f22a-02fc-4d99-bce9-6c933113a7a0	{"iss": "https://accounts.google.com", "sub": "101386552149340484598", "name": "Nguyễn Xuân Hạnh", "email": "hanhtyr@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIzzuu4QEflTYLsQlBhwXoJlaX2lQa1PR9_kX5LVlb7DP7tek0e=s96-c", "full_name": "Nguyễn Xuân Hạnh", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIzzuu4QEflTYLsQlBhwXoJlaX2lQa1PR9_kX5LVlb7DP7tek0e=s96-c", "provider_id": "101386552149340484598", "email_verified": true, "phone_verified": false}	google	2026-04-10 16:12:41.82107+00	2026-04-10 16:12:41.821124+00	2026-05-04 11:17:38.73678+00	003cc23c-1067-4ab3-8e6f-f60bb832341d
102365804487603265827	18640b2a-bb98-428b-b4a7-6a3ec8301794	{"iss": "https://accounts.google.com", "sub": "102365804487603265827", "name": "Khánh Hân Phạm", "email": "phamkhanhhan6@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIgq9DDJgtxSbjeSXhxFlsgjMIj4YKfPQyvsHtmaPH1rRtq9A=s96-c", "full_name": "Khánh Hân Phạm", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIgq9DDJgtxSbjeSXhxFlsgjMIj4YKfPQyvsHtmaPH1rRtq9A=s96-c", "provider_id": "102365804487603265827", "email_verified": true, "phone_verified": false}	google	2026-04-09 14:37:26.716619+00	2026-04-09 14:37:26.717247+00	2026-04-09 14:37:26.717247+00	98708191-f7f4-4be5-982a-e9261a6db28f
ecebd763-797d-4b9f-beff-63f5044776fc	ecebd763-797d-4b9f-beff-63f5044776fc	{"sub": "ecebd763-797d-4b9f-beff-63f5044776fc", "role": "TOURIST", "email": "hanhspring007@gmail.com", "gender": "MALE", "full_name": "Nguyễn Xuân Kiểm", "phone_number": "0973973266", "email_verified": false, "phone_verified": false}	email	2026-04-11 09:12:12.315562+00	2026-04-11 09:12:12.315613+00	2026-04-11 09:12:12.315613+00	ec8bb3fb-eba4-4205-8951-43c54c0444bb
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
e8a00a84-273b-483c-b0ff-83a9e3615c01	2026-03-28 08:31:55.122568+00	2026-03-28 08:31:55.122568+00	password	ddbabe22-565d-446a-a058-600289060895
105726ea-31d8-4cad-ac45-143cce6df58d	2026-03-28 08:33:56.274874+00	2026-03-28 08:33:56.274874+00	password	d640170d-5158-4bcb-ada1-0f3a3d7c28e6
2389047d-42c5-484b-afdf-485a584b99ed	2026-03-28 08:34:38.243453+00	2026-03-28 08:34:38.243453+00	password	021fba5b-38e3-4e92-b6b1-56eb9a65ff4b
20f2ddcf-73a6-46d8-886b-73e5c6d7e84b	2026-04-03 17:04:37.312854+00	2026-04-03 17:04:37.312854+00	password	5e887ede-c220-4e83-8066-824ed1978863
69d65f9e-c13e-45c7-bad4-c3060de1924e	2026-03-28 09:21:47.304545+00	2026-03-28 09:21:47.304545+00	password	ff80c9df-2ae9-4f29-a4a3-5d806eeb3156
5d072393-1c6a-4a2d-a590-9132554e1471	2026-04-03 17:12:04.727097+00	2026-04-03 17:12:04.727097+00	password	6f7d65b9-dc01-44c8-978b-a8c34025844c
b3dfc00b-a88f-4255-908c-1d5db383852e	2026-04-03 17:12:19.153829+00	2026-04-03 17:12:19.153829+00	password	4e22ed9f-c7d7-432a-9c2e-1e47b06db785
e353cb40-9817-40a3-8128-9f5baa3140e5	2026-04-03 20:47:05.827535+00	2026-04-03 20:47:05.827535+00	password	bad31edb-832d-4982-bd21-c8539be4851c
d41d46f9-f562-42ab-8079-ef938e36defa	2026-04-03 21:50:14.399332+00	2026-04-03 21:50:14.399332+00	password	60c3e1dd-26bd-4968-9eac-800110a2be20
832a7ffd-b1c0-42a9-9efc-7178db1a8f09	2026-04-03 22:05:30.874083+00	2026-04-03 22:05:30.874083+00	password	36a09cac-9717-4e9b-a986-82f63c8affc4
c021202a-ecea-40c3-887c-473c4b4ec0bf	2026-03-28 10:49:53.527644+00	2026-03-28 10:49:53.527644+00	password	d0a108d7-4739-44ef-842d-710d90fd7eda
3d329806-9118-42b4-9c8f-ef0e302f0cc8	2026-03-28 11:28:14.323787+00	2026-03-28 11:28:14.323787+00	password	ff879869-77e4-437f-af5b-9668f7294501
382934bf-9061-4b64-a014-9e9aa79c72d9	2026-03-28 13:22:47.989085+00	2026-03-28 13:22:47.989085+00	password	1586f8c3-9ebd-461e-9140-52b0655b97da
05dd48ae-bdc0-44c6-820f-e83d2fe6ca22	2026-03-28 13:34:52.120327+00	2026-03-28 13:34:52.120327+00	password	2b8c0769-87e5-492c-9f25-0ce406e825b1
a5800bb6-a6c4-4c6e-ac71-721e31ce5ec5	2026-03-28 15:50:14.375796+00	2026-03-28 15:50:14.375796+00	password	27d04fc9-d189-4479-8029-75076aed297a
1d69f845-b46e-44ae-9612-c79c6e172ed4	2026-03-28 15:54:53.5309+00	2026-03-28 15:54:53.5309+00	password	b1d9cbd3-edc6-48c8-89c4-d4745a0f2097
abf8dff8-a1d4-4e4a-a5db-0ff8b92ad244	2026-03-28 16:48:02.26447+00	2026-03-28 16:48:02.26447+00	password	a3aadd34-1f2a-4cda-b147-830ffb3fd1b6
1f1b6f71-bb3f-4fb0-985f-57148503ae26	2026-03-28 17:06:01.934878+00	2026-03-28 17:06:01.934878+00	password	e6ea2c11-e226-4d4a-a214-58a7de3a5b41
cea9febb-5890-4f81-a6e8-718a8292501d	2026-03-28 17:07:58.334301+00	2026-03-28 17:07:58.334301+00	password	c3af66e3-1c0e-40c6-b659-1652bf642c7c
5f283801-6258-4685-a036-a138031ba1ac	2026-03-28 17:10:35.789482+00	2026-03-28 17:10:35.789482+00	password	6259f4d9-7a77-4f02-abbf-fd9c5e756bec
e44291d0-c38c-4971-901d-a3e213900a36	2026-03-28 17:13:15.420212+00	2026-03-28 17:13:15.420212+00	password	8c3473a9-24e7-4e77-a186-57f65ffa055b
b71c06e8-0eba-4aab-bdde-19c57b0a0adc	2026-03-28 17:17:20.89247+00	2026-03-28 17:17:20.89247+00	password	b380e775-e083-4292-bf1f-4dcccc97c20f
b973abc9-79ac-49d8-b5d3-eab9b6e439f6	2026-03-28 17:37:23.7636+00	2026-03-28 17:37:23.7636+00	password	66c03c86-d7ee-4fbb-8ec9-b53ebf649637
9974e216-5cb6-4c74-8cbd-cad4cdcce380	2026-03-28 17:38:30.395426+00	2026-03-28 17:38:30.395426+00	password	8a906861-44fa-4f54-9a80-ccf903a171fe
daddfdd9-0ac8-4af0-93c3-ac7b638c7c30	2026-03-28 18:16:28.130803+00	2026-03-28 18:16:28.130803+00	password	12aaf630-c17d-4f58-9553-90ee5be9d9fa
fd1ea4aa-e0d9-4fee-932c-83032fa4290d	2026-03-30 03:18:41.70784+00	2026-03-30 03:18:41.70784+00	password	e1b3e178-e456-443e-aa74-5fec2325ad08
f5e3e664-975d-4b0a-b33a-5ab39ac418f8	2026-03-30 04:29:59.933274+00	2026-03-30 04:29:59.933274+00	password	c99837c4-19af-4ddf-9d1c-a679a22b4bac
2784f74c-b2dd-494a-8db7-e5865052f0e3	2026-03-30 04:44:36.493247+00	2026-03-30 04:44:36.493247+00	password	98664f32-e6b0-4764-a577-cb0c2b2ae3fe
3e559c7e-1091-4689-b4a1-e1dc37bf377d	2026-03-30 13:42:52.903119+00	2026-03-30 13:42:52.903119+00	password	74e8b9a3-e4c3-44db-a287-8d8f91136cbf
3d4f2bff-d3a0-4036-8fa7-3c02c9cf5d9d	2026-03-30 14:21:19.875604+00	2026-03-30 14:21:19.875604+00	password	3f95931c-252c-4cca-9bee-cbf5231b4df2
188e2d63-486d-4fa4-9f6f-c08d676e7a07	2026-03-30 16:33:43.761426+00	2026-03-30 16:33:43.761426+00	password	31b05ddb-d0e9-41d6-8a7b-3a8765707b10
75d31b9c-c80d-44dd-9a03-4e2288d73f77	2026-03-30 17:34:13.461819+00	2026-03-30 17:34:13.461819+00	password	c14a2215-39fb-4c6c-b1c8-dad3a5f68a14
9e6f6203-a900-4c39-9ace-3b2464c6f912	2026-03-30 17:46:39.101895+00	2026-03-30 17:46:39.101895+00	password	bfed1e8a-ff0c-4e45-af4b-1c35b23df420
cc103ed1-c431-45b8-9778-e86609069bbb	2026-03-30 17:50:29.435915+00	2026-03-30 17:50:29.435915+00	password	b88940f9-4363-4718-93d6-201f48ff883c
17262a5c-d9da-4f53-bb82-d90c3064e6dd	2026-03-30 18:03:17.245015+00	2026-03-30 18:03:17.245015+00	password	4cd7106f-6c5d-47a6-87bf-fca9b60ed6b2
17857740-6c3a-47e4-922a-64eed22f2f5e	2026-03-30 18:21:03.806953+00	2026-03-30 18:21:03.806953+00	password	11d6c0c5-6758-436b-b8d7-112ed99edc0a
7bd622c1-32a1-4c81-bd09-85b64b99060a	2026-03-30 21:58:57.466955+00	2026-03-30 21:58:57.466955+00	password	5baa4f14-deca-4314-998b-5d47cd07fbb4
31bf9fe8-e7a0-48dc-879f-8fc3f35e414c	2026-03-27 16:58:06.975987+00	2026-03-27 16:58:06.975987+00	password	b0874dba-1487-4020-a076-f49710f2bf71
83ec774a-ba4c-4408-bb58-b85fa25cd59a	2026-03-27 16:58:46.001528+00	2026-03-27 16:58:46.001528+00	password	bb02cf55-2dcb-40f4-806b-15006adfbdbe
18deef48-5bff-46cb-a7da-8f0004979157	2026-03-27 17:24:53.429894+00	2026-03-27 17:24:53.429894+00	password	0b090fa1-9753-4f76-908d-e37cb41e421c
5c9b733c-38d0-4a8d-b6b8-be693b23fef9	2026-03-30 23:02:53.040743+00	2026-03-30 23:02:53.040743+00	password	f2c692ce-2cf0-4aaf-b596-42853a63b82d
6a15d8e8-aaea-4a29-8d03-749bbdfe9ad1	2026-03-28 08:05:30.740395+00	2026-03-28 08:05:30.740395+00	password	090ed04c-00f3-4987-b7f2-18ee732b117d
c19c862e-45f3-4ff6-b760-6ad50934eb53	2026-03-28 08:05:49.591281+00	2026-03-28 08:05:49.591281+00	password	ae62158d-0e05-49b7-b040-ae28492df644
3a784b14-6d9e-4cb7-b551-b6bb8572e4b4	2026-03-28 08:08:38.250553+00	2026-03-28 08:08:38.250553+00	password	d85d1d6e-2f8b-4a34-b8d3-7ae084726d54
e6888758-df45-4c67-8b9e-104c019531c2	2026-03-28 08:22:14.4297+00	2026-03-28 08:22:14.4297+00	password	e18c2d89-e629-4fbe-86c1-89c6e961d5bc
a5e9ac54-f82f-4310-8d2c-b78f9f4dc77e	2026-03-28 08:23:44.59946+00	2026-03-28 08:23:44.59946+00	password	0b19d13c-7e48-4a2a-b733-6889cce2f1d1
7f2d65d3-c90c-456a-825e-b6c4b0c5132f	2026-03-31 08:05:57.951713+00	2026-03-31 08:05:57.951713+00	password	779f5ab3-f002-4d3f-a66b-aaf5d17979ab
e79494cf-3acc-4de2-9f2c-cb34d60e456b	2026-03-31 16:43:40.699436+00	2026-03-31 16:43:40.699436+00	password	91ec92d9-62e2-4c38-8f36-beb71141e7ee
493a5611-d789-4195-8a4b-7eb20b413d69	2026-03-31 17:47:15.370565+00	2026-03-31 17:47:15.370565+00	password	b4cefea2-4c1c-4ba7-9f56-a55d6949b6ae
0599110c-70a3-43b5-8eba-e6d3e86df115	2026-03-31 18:16:25.963398+00	2026-03-31 18:16:25.963398+00	password	c59e6675-679c-4bdf-baa7-4d674aa1f089
4503e0f8-7085-4202-9396-fca513ee2737	2026-03-31 18:49:23.567284+00	2026-03-31 18:49:23.567284+00	password	1cd1beb1-3696-42c4-a996-9290b0ed7319
0249cdd6-8123-456f-aa2e-30ce29ad020e	2026-04-01 01:50:48.435366+00	2026-04-01 01:50:48.435366+00	password	f382063b-2e0b-473f-b59f-8052db2643cb
7fc03b47-c7c1-4780-8f89-3310bbd03a61	2026-04-04 03:57:27.088537+00	2026-04-04 03:57:27.088537+00	password	06413272-7c6f-4186-a070-9da66504d36f
cdc76db6-4642-4d17-95bf-db04af47dd35	2026-04-01 11:17:01.847032+00	2026-04-01 11:17:01.847032+00	password	1e4392b4-0b0f-43a1-8203-5c66d6c2264a
cebd5bef-5261-4bbe-b58c-59a0cdb57768	2026-04-04 03:59:23.883673+00	2026-04-04 03:59:23.883673+00	password	1220e207-b0c0-4077-9f9f-5adc53e0c39c
70ae080e-bf8e-415a-91b7-974135faace5	2026-04-01 14:14:40.889476+00	2026-04-01 14:14:40.889476+00	password	90aec1b8-1fd7-4a4d-b628-d43ec297b5ce
1b679902-2027-4dca-8828-36b6948665cf	2026-04-01 14:28:11.730024+00	2026-04-01 14:28:11.730024+00	password	7958a888-c658-4283-8189-a1aba0d7ff0f
610b49bb-2d8b-428e-b0d0-cb62ee2e8bc5	2026-04-01 16:32:19.083163+00	2026-04-01 16:32:19.083163+00	password	ba69fa74-8b49-4d48-8c4e-71e25373110c
ad7d0121-8d1c-4cff-9540-8fa093f1572a	2026-04-04 07:51:05.614949+00	2026-04-04 07:51:05.614949+00	password	45f80127-30b8-4ac5-853a-bd75e837e2f1
fe23c9d7-936d-49c6-86f1-1d4336e20a51	2026-04-04 07:51:27.205785+00	2026-04-04 07:51:27.205785+00	password	c5d19963-3ad4-47f5-b4ec-abfdbed2a80d
251437b2-4a55-4dc1-b22d-6c010b579759	2026-04-04 07:52:50.501457+00	2026-04-04 07:52:50.501457+00	password	addf5d43-8c78-4db8-ba5b-14705965e5d9
4e068938-b824-4e70-846c-c4ddd6dec225	2026-04-04 07:53:45.515567+00	2026-04-04 07:53:45.515567+00	password	eb23b185-4b8d-4eee-b125-69a2733ac37d
5144bbc0-670d-41e6-a512-76a62cbc8558	2026-04-04 07:54:04.250878+00	2026-04-04 07:54:04.250878+00	password	ca33988b-7918-4c9f-a8d1-af313357d6cf
245f7d1f-825a-4b27-aaf1-09266ae1cd76	2026-04-04 08:04:56.490388+00	2026-04-04 08:04:56.490388+00	password	aa1a1d01-e0d0-479a-a533-e09b87a78c06
8af7e34c-9845-47e3-b62d-b4239885c0a5	2026-04-02 04:26:26.848909+00	2026-04-02 04:26:26.848909+00	password	4f6021c3-54ad-4cdc-bd72-1f336ad146de
0b9a2491-e8cc-4d38-8de7-228e4108e13e	2026-04-04 10:34:11.945165+00	2026-04-04 10:34:11.945165+00	password	525efd80-3915-42b6-b8fa-a5927c2f7807
1b2e33f2-b47e-45f1-8801-fe87aa7d6460	2026-04-04 18:28:29.922285+00	2026-04-04 18:28:29.922285+00	password	b76c27a0-0cd1-4caf-9cea-7645ded84dd1
4514e11f-b5ed-45bd-9900-951aaa4f021f	2026-04-05 01:01:57.048022+00	2026-04-05 01:01:57.048022+00	password	c6ad85de-34a6-4589-b978-a4a51a9da393
ca1db5ac-9f81-4a92-9541-ecb974715bd0	2026-04-05 01:19:30.061631+00	2026-04-05 01:19:30.061631+00	password	6d114c49-4b7c-4236-8532-cc0c762d6176
040b608f-a0b9-454f-a567-b7e3c8b2b94b	2026-04-05 02:35:29.425301+00	2026-04-05 02:35:29.425301+00	password	1cd3c97d-483c-49fd-ab1c-7717a80f694a
e00f1709-000a-463e-9630-8d01e977d82e	2026-04-05 02:56:14.137272+00	2026-04-05 02:56:14.137272+00	password	73895d49-2199-4853-90a4-4ac80836664b
695d41ea-2d9e-45d4-b583-3051112c8a72	2026-04-05 04:45:03.478815+00	2026-04-05 04:45:03.478815+00	password	ac9c93b1-9f47-45e5-9554-853301b1a00b
23ccc957-d9b5-4a80-8883-53655d3082e7	2026-04-05 04:50:51.888766+00	2026-04-05 04:50:51.888766+00	password	ea8b069c-d2eb-4a44-8349-1f7acb4e548b
ee15d3b8-509c-4555-b63c-947fe183de06	2026-04-05 04:56:27.693855+00	2026-04-05 04:56:27.693855+00	password	02cdd140-b48a-4e88-b572-f7c76dfb0cf6
a78df8c5-5bb7-4ddb-a769-8f24c9947986	2026-04-05 04:56:36.654411+00	2026-04-05 04:56:36.654411+00	password	4600239a-9e46-4e71-9c8b-337d6b0a7694
8574d4b8-dcaf-4162-8f5e-dcc50938f20d	2026-04-05 05:23:28.229279+00	2026-04-05 05:23:28.229279+00	password	9739b4d5-f0e1-44ba-817f-4b0a5cfde1dc
aaf5c08d-1737-46df-9073-20421a87b8dd	2026-04-05 05:32:57.138874+00	2026-04-05 05:32:57.138874+00	password	43f3ec4a-bb80-44fc-b786-9e97846b32f2
e7682a5e-30e8-4137-9902-c90791d54a6f	2026-04-05 05:48:03.222665+00	2026-04-05 05:48:03.222665+00	password	e5c2ffb0-45c0-4016-94a1-13d3864699f0
eff9ad30-a9b0-4016-ae83-767b064a7067	2026-04-05 06:42:46.719042+00	2026-04-05 06:42:46.719042+00	password	182c108b-d511-454c-b079-69e9cd42e3f2
c41aa3fa-899d-4497-98bc-aaaee6e3af9c	2026-04-05 06:53:28.142769+00	2026-04-05 06:53:28.142769+00	password	73e3fc63-3b02-4425-bb32-76fdc6d835b4
7da45766-3b2d-4b59-bd8d-f814a8faa88a	2026-04-05 07:31:26.296874+00	2026-04-05 07:31:26.296874+00	password	29f616b2-0c34-4bc0-92f9-a5a0030b70da
5d198fa3-a8ac-435c-8952-418db7e7400a	2026-04-05 07:43:54.58039+00	2026-04-05 07:43:54.58039+00	password	da12a884-dba9-440b-9a91-a50818df6dbf
3f827437-0fc8-4052-87f2-d78a44271efe	2026-04-05 07:45:30.350384+00	2026-04-05 07:45:30.350384+00	password	c690f398-586e-4926-ba25-57169398c06f
b0d4651b-f457-4257-a550-aa8c292efcf3	2026-04-05 07:47:42.785442+00	2026-04-05 07:47:42.785442+00	password	67c1ead5-7c32-4b2f-a65d-27f186e039bc
b8ab4d11-6742-4d43-a597-6e8f4376656f	2026-04-05 07:48:11.881645+00	2026-04-05 07:48:11.881645+00	password	04d19dce-5d10-41e6-94ca-a1f1806c3d32
0422fc81-6cec-46a3-bd08-219cf123b011	2026-04-05 07:48:33.8334+00	2026-04-05 07:48:33.8334+00	password	e6ea4f3e-8900-4999-aacd-d033b9137140
6b914ea3-faf7-4939-883f-41f74e4fd509	2026-04-05 07:52:37.40056+00	2026-04-05 07:52:37.40056+00	password	339502d8-a2f0-441e-b40e-6464c878f249
9451dd9d-e3a3-41b0-93f7-bd66404b9c9b	2026-04-05 08:06:24.249882+00	2026-04-05 08:06:24.249882+00	password	300d03b6-6845-48d7-a9ee-56e6d8170781
73fd57d5-6a76-4d95-b8ea-5102779f9cd2	2026-04-05 08:06:24.552418+00	2026-04-05 08:06:24.552418+00	password	68af1ce5-5d7b-45ae-b55d-0771ad7b576e
e8e90756-c4d4-4dff-b940-a903c24a65b4	2026-04-05 08:59:11.468932+00	2026-04-05 08:59:11.468932+00	password	cd2f240a-624a-4797-ae65-593ad0d58d69
e927ba34-f626-4ce0-a5ce-3de73935a0e5	2026-04-05 09:00:43.072279+00	2026-04-05 09:00:43.072279+00	password	e3853b18-b387-4690-a33c-60ff4303ee9e
cd87ed4e-bb74-42e5-932c-f6fd58c6c9c7	2026-04-05 09:08:17.970646+00	2026-04-05 09:08:17.970646+00	password	f2816e74-07ca-4153-a743-0040a1cf2436
ea7ba9f4-b502-425e-b8e3-b38f9e7c101f	2026-04-05 09:12:35.804823+00	2026-04-05 09:12:35.804823+00	password	b75a1dc5-87d4-4f46-b2cf-ee77633b97ab
654d799b-5c16-42e6-9889-d3538e11b2f0	2026-04-05 15:50:44.095673+00	2026-04-05 15:50:44.095673+00	password	d631f23c-f420-4f8e-bebd-2bb7994944e6
34412fcc-c2ce-4f07-ae6c-7e77b04b0a7f	2026-04-05 15:54:11.730963+00	2026-04-05 15:54:11.730963+00	password	1487f2e1-fe88-4061-8ca8-73ee8008c8a1
4cdd848a-8208-4fe5-a57b-bfbf61174421	2026-04-05 16:12:49.237922+00	2026-04-05 16:12:49.237922+00	password	75d746c0-0b32-4d23-b5b5-67d51fa3ed76
f6c62ca2-d98f-4b7d-95b0-333b2b3b90b9	2026-04-05 16:13:08.606044+00	2026-04-05 16:13:08.606044+00	password	87145f97-a202-4bb2-8b54-2bbfd71f7c5e
5f8aebcc-d8d7-447a-97d1-8ae357a6d843	2026-04-05 16:30:40.364071+00	2026-04-05 16:30:40.364071+00	password	af059b6d-2930-4574-83a2-eec236c38e73
77a76653-2f24-4da2-aa64-42fab3198bc2	2026-04-05 16:31:53.089959+00	2026-04-05 16:31:53.089959+00	password	645631ea-19fe-42b3-9048-5494ddda5859
11bcd35c-fdd4-4f7b-b97a-8e019e8f8de7	2026-04-05 16:32:41.46031+00	2026-04-05 16:32:41.46031+00	password	7f7558a2-07ec-47ad-a49d-2330a9867586
bae03e61-1bd5-4fad-a630-ddd0f7fe0002	2026-04-05 16:41:10.150356+00	2026-04-05 16:41:10.150356+00	password	7d255cdd-a158-4c8d-878c-c4e086dcd153
0d4ab3bb-c2ce-4410-92b2-117dc3e92920	2026-04-05 16:42:38.253265+00	2026-04-05 16:42:38.253265+00	password	4b090a8f-abdf-4535-b0d1-2e8b292dceb1
4c5f914a-622c-40a9-8f53-4467164dd7f2	2026-04-05 16:59:31.207781+00	2026-04-05 16:59:31.207781+00	password	a0b14e42-c33d-4a71-84b9-ea123702b6a4
43cb828c-d78a-42d9-bcc7-484c82e4e3f6	2026-04-05 17:00:38.722923+00	2026-04-05 17:00:38.722923+00	password	541917a3-5a95-44da-9c37-f0d43b6bd765
0119cc33-ac64-4932-8a72-be982dbdad88	2026-04-06 03:41:55.629619+00	2026-04-06 03:41:55.629619+00	password	491b199d-7cfc-4ba2-8b4c-9adc11867ce4
ccd0f18d-4c82-4856-869e-50c23b0d8ef1	2026-04-07 17:40:58.375844+00	2026-04-07 17:40:58.375844+00	password	789f9c80-7d0e-46f4-8fe1-2949f2d95687
042c59a5-d1bd-4d56-9da7-1e0bc8e1c5a5	2026-04-07 17:48:56.767403+00	2026-04-07 17:48:56.767403+00	password	21cad6ac-9764-46d6-bb87-76e5b3d681b2
5922f71b-9413-47d2-ade1-0801adeb1df2	2026-04-07 17:49:04.737164+00	2026-04-07 17:49:04.737164+00	password	8cb4f434-ab89-49c6-9254-bc9f6565e84a
3e28e52f-9858-4465-9ceb-fa38bbc9f384	2026-04-08 00:12:05.302789+00	2026-04-08 00:12:05.302789+00	password	a0276384-9489-4ac3-b3dd-5652f9e0af40
115b8691-1176-4e5e-a613-97fd732a736b	2026-04-08 02:21:18.950186+00	2026-04-08 02:21:18.950186+00	password	e75c053b-0dc8-44a7-a40e-498982e18bb5
66c55acf-1e3b-497b-af03-74f823201120	2026-04-08 05:31:18.601837+00	2026-04-08 05:31:18.601837+00	password	0c06002d-64fc-4730-9ba6-490503952372
991ebdc1-fc1b-4ded-ba49-6a05e4fff500	2026-04-08 05:43:19.852531+00	2026-04-08 05:43:19.852531+00	password	3a4582e7-fe5e-438f-85d5-fc16c33eb866
3173ad85-deb3-4d0c-bcaa-fd86c2d2461b	2026-04-08 06:17:51.568149+00	2026-04-08 06:17:51.568149+00	password	5327b1a9-d53e-4937-94f8-632e690b38e0
827fdd99-5450-4335-bd71-83e0ff828220	2026-04-08 04:22:56.010183+00	2026-04-08 04:22:56.010183+00	password	1a7ee861-3ddc-45df-8a4e-17e4c30d203d
3d68bfa9-c0dd-4257-bc91-97fb80c177db	2026-04-08 04:24:23.183024+00	2026-04-08 04:24:23.183024+00	password	4924967f-b54b-4be2-9111-9d946eab8e76
6d751c3e-a94f-4fb1-81ac-eb4ec322d6e4	2026-04-08 15:11:23.227091+00	2026-04-08 15:11:23.227091+00	password	4e2df7e9-c771-47bb-9b9d-61c96b0ce3a9
e1a3942d-5af2-4133-8c1c-04f6efee55bf	2026-04-08 15:18:12.900465+00	2026-04-08 15:18:12.900465+00	password	4878364e-835f-443d-ab12-e895c2b38e25
f8f351eb-69cf-420d-b4ed-0c17d754a664	2026-04-08 15:18:38.196495+00	2026-04-08 15:18:38.196495+00	password	9728a596-5222-413c-b0c7-a1aa1e6375b8
9083959f-697d-446e-bf34-1fd18a6056bf	2026-04-08 17:46:37.916317+00	2026-04-08 17:46:37.916317+00	password	8c22d026-0a61-45f0-8b19-d6b60fcc86a2
12db1045-139d-4647-8d4f-62ee0723c70d	2026-04-08 17:53:22.436077+00	2026-04-08 17:53:22.436077+00	password	f3b4912c-4f9f-4c9d-9bb9-0c1404b4a084
cd3f1f3c-8357-441b-9cd6-75042221fd17	2026-04-08 18:04:51.764749+00	2026-04-08 18:04:51.764749+00	password	6d67144f-796b-4a3c-8a7f-a8ed60c5d2a7
ab173c51-525c-4ac8-868f-3dfb4652033c	2026-04-08 18:09:59.034338+00	2026-04-08 18:09:59.034338+00	password	eab76581-9cee-47a1-b503-c9c541287da8
a2f0a879-6414-41d4-b61f-7aa0c7092a11	2026-04-08 18:16:38.290829+00	2026-04-08 18:16:38.290829+00	password	5e462146-1ca3-4632-8da1-d93a053576ca
66d6648a-f131-4e63-b9cc-9e20ef0d5017	2026-04-08 18:20:22.6045+00	2026-04-08 18:20:22.6045+00	password	f0b7b8fa-1d7c-489c-b574-f84ab8b92102
77ea16d6-7933-49a9-8888-d23a182cffd4	2026-04-08 18:20:48.042184+00	2026-04-08 18:20:48.042184+00	password	b22a3aeb-a217-42cc-b462-45ff5aa7f4b7
3d7daaa9-9b5f-4395-8b0d-d72f68861551	2026-04-08 18:27:28.164617+00	2026-04-08 18:27:28.164617+00	password	1da1ac1c-acbf-43c5-aab9-5f02539ab28a
a3d58d52-785f-4e10-938f-6b4ab220a0bd	2026-04-08 18:27:49.982144+00	2026-04-08 18:27:49.982144+00	password	8de98a0e-b676-4db9-9487-a4c4a06ee472
230b1049-dbe5-4757-a62b-92e6b5f04c01	2026-04-08 18:33:08.36932+00	2026-04-08 18:33:08.36932+00	password	a16f0c1b-ae70-4347-8093-b9ce705ced67
b27ec1c4-dff1-4e3b-84f1-30bac0703dc6	2026-04-08 18:34:23.761505+00	2026-04-08 18:34:23.761505+00	password	b703b0b7-4c19-4c73-833d-d0472dd176c1
9bed12d3-68b3-4186-8057-681568de7e5c	2026-04-08 18:35:06.80185+00	2026-04-08 18:35:06.80185+00	password	6be84d00-52b4-4c9a-81af-9250b9a55ab6
d3814b86-56f1-4008-8d6e-2172fcec553d	2026-04-08 18:48:14.34266+00	2026-04-08 18:48:14.34266+00	password	fcc647df-b506-4765-9949-971c362ce96d
cc2355ac-f5b4-418d-b290-8980231b2136	2026-04-08 18:55:18.086503+00	2026-04-08 18:55:18.086503+00	password	889c9e26-084f-4fea-928a-3f599731d031
446b0b2a-d1ce-43e3-a911-12e76bc3cfb8	2026-04-08 18:56:36.239485+00	2026-04-08 18:56:36.239485+00	password	c249731d-45ae-4927-921c-5cfe1c195617
45339381-c0d5-4ebc-807c-39bafc3927f3	2026-04-08 19:04:07.999875+00	2026-04-08 19:04:07.999875+00	password	6fe60d51-561e-43ad-b11e-0d3f17ed4d9f
9ad46c0d-ea02-423d-8e8e-0cbc4d84c7c4	2026-04-09 03:18:06.61094+00	2026-04-09 03:18:06.61094+00	password	06a7c419-4c85-40e0-8a45-3e191efcbf92
605136e8-7c28-4d57-a4fb-7ea0e7c1ffff	2026-04-09 03:40:02.30608+00	2026-04-09 03:40:02.30608+00	password	b9fe7c28-5f3e-4b8e-9f13-b9d5ef36c5a5
6f76e629-f577-4f70-8335-08b21d8337b8	2026-04-09 03:48:09.08958+00	2026-04-09 03:48:09.08958+00	password	2927415e-41f0-489a-a888-c4a91ca5e69d
b87ac33e-6110-44a1-8f93-87dfd314302f	2026-04-09 04:20:48.580035+00	2026-04-09 04:20:48.580035+00	password	d284355c-2126-40c6-9714-5b165c46bc17
860db37a-f6f9-4ad6-84eb-106ad60c40b0	2026-04-09 04:24:26.597114+00	2026-04-09 04:24:26.597114+00	password	469fee19-e9fa-474c-90f1-73b1e2154222
41c91e36-0a9c-4a7a-81c6-e8902da0731c	2026-04-09 04:28:21.463553+00	2026-04-09 04:28:21.463553+00	password	e9e43281-410b-4801-a3bf-a2440fc72b00
4be11cae-afff-4e54-9aaa-5e8f49fe3d15	2026-04-09 10:52:05.865263+00	2026-04-09 10:52:05.865263+00	password	8336428d-dd24-40a1-a080-b714958c8a42
4a8bade7-41be-488d-a279-535f4115d7ef	2026-04-09 10:52:44.583459+00	2026-04-09 10:52:44.583459+00	password	506245a6-ca47-4a6c-83d0-d0c6bf4e069f
38ff7050-ac73-4245-ada6-dab762adec7a	2026-04-09 11:05:34.181079+00	2026-04-09 11:05:34.181079+00	password	0f74ab45-5f51-4043-92da-01a6e52e9c03
8e8cc93a-d1da-4c90-8f18-ac7d7d3bb16c	2026-04-09 11:20:51.139887+00	2026-04-09 11:20:51.139887+00	password	e95517ef-7f1a-4a33-a3d8-4b5b7de2f4e9
672f35d0-a631-438d-b49e-e556dd03e89b	2026-04-09 11:41:12.760874+00	2026-04-09 11:41:12.760874+00	password	9e6779ed-2587-47d4-b0c7-45efe459fbf4
a2caeb8c-5f67-47a9-aaaa-2e72a56436bf	2026-04-09 11:45:27.312502+00	2026-04-09 11:45:27.312502+00	password	079f6740-0e5d-481c-9e26-2e28d1d06e13
c7a9483f-8aff-42e4-b367-d45dfbc5101e	2026-04-09 12:21:11.769452+00	2026-04-09 12:21:11.769452+00	password	088a827d-23b8-49a3-9b12-903fcf04d25f
1a96ef1e-004a-4844-8f95-3c6b302752ce	2026-04-09 12:35:34.59131+00	2026-04-09 12:35:34.59131+00	password	82a5bd78-2e69-4a45-a4e2-a38a11b99837
3f8d4d3a-2fd0-4667-940d-2234e1d1428b	2026-04-09 12:49:21.070938+00	2026-04-09 12:49:21.070938+00	password	8ba70fbf-395f-44f3-a235-f1df250f63a7
dfdcc693-06c1-42ab-9f93-dfd24cd0a9ec	2026-04-09 14:31:38.625789+00	2026-04-09 14:31:38.625789+00	password	436ef3e9-0f8a-4221-b1a4-018d947e0379
94977f2c-aef1-460f-8533-69fd63f52b84	2026-04-09 14:34:18.706951+00	2026-04-09 14:34:18.706951+00	password	1bb48ada-134f-4e5a-9285-ae3a7f89bf51
4939619b-9c09-43fc-8df6-764f2e026168	2026-04-09 14:40:33.553454+00	2026-04-09 14:40:33.553454+00	password	163d67f6-952b-4c75-b6d4-652409164b66
d403b595-4031-4419-bbfd-43edcc9e0fc5	2026-04-09 14:51:29.076769+00	2026-04-09 14:51:29.076769+00	password	365860fa-3990-4df1-b86b-0501abed6974
cf2bcd4c-230d-469e-9e66-df376be5e63e	2026-04-09 14:52:35.298971+00	2026-04-09 14:52:35.298971+00	password	16dd2953-0f7a-4bc7-97ab-8f58b1e905cb
94958ed7-5fb8-4ade-b0ed-8b368f032bca	2026-04-09 15:07:03.019579+00	2026-04-09 15:07:03.019579+00	password	e7db894d-9e6b-49ec-9ca5-599b4524dad7
ebb3fd0f-34c2-4ce0-833a-218b5b955f7d	2026-04-09 15:07:41.307025+00	2026-04-09 15:07:41.307025+00	password	6c6204e1-af65-4bfb-a30c-2f791eb5338c
1a6182e0-ea08-4f13-842d-b59de3178c2e	2026-04-09 15:14:19.568144+00	2026-04-09 15:14:19.568144+00	password	91f6e19d-8321-49a3-b469-0017e4d14f3d
18c1ab85-14a6-4882-aaa9-c921e07b442c	2026-04-09 15:17:00.556167+00	2026-04-09 15:17:00.556167+00	password	790ef9d2-080e-4c2f-9e76-86e9870972f9
78c5c1dc-e31f-4873-b197-292b416aa21a	2026-04-09 15:18:26.94284+00	2026-04-09 15:18:26.94284+00	password	a2ec8176-7132-4512-90e3-cac4cb3851ab
41fdc79f-85f7-4d1e-8cfc-bc6fe90253f0	2026-04-09 15:33:11.61773+00	2026-04-09 15:33:11.61773+00	password	4aa335e6-e85d-4b55-aaf3-dec712ee5f05
49ca9e9e-15e1-4185-a711-165d53d07cb9	2026-04-09 15:35:12.326742+00	2026-04-09 15:35:12.326742+00	password	b19a41c2-fdb0-4d04-9cf3-794e16067c04
fa8e3245-62bd-45e9-8dad-3686a991a5dc	2026-04-09 15:51:40.396865+00	2026-04-09 15:51:40.396865+00	password	80aed498-8e26-4ead-926e-f5b49d5e397d
7d86e62f-ea74-4e27-86cc-57c137dd4b2f	2026-04-09 16:00:15.657983+00	2026-04-09 16:00:15.657983+00	password	c4cd797e-454b-47be-87c3-47617fb22704
4102ed6f-80a4-41c0-9883-5389550ffd05	2026-04-09 16:00:58.600647+00	2026-04-09 16:00:58.600647+00	password	f07dde05-5a9a-4b30-8eba-f0d6820a7fa7
f1479da9-0b38-4cc9-b725-a4a49aa1b19e	2026-04-09 21:17:36.116747+00	2026-04-09 21:17:36.116747+00	password	efa3fda7-acb0-4d55-aa42-7ee63a091b6f
852e2731-4a26-48b6-9b65-c7ee6cbfc807	2026-04-09 21:17:36.352063+00	2026-04-09 21:17:36.352063+00	password	d7653737-d338-4939-954c-b45efba57851
b6f91aee-d8ce-4f29-a8f4-ff83f50f34f1	2026-04-09 21:42:01.462681+00	2026-04-09 21:42:01.462681+00	password	7bd7dafb-a5ed-415b-aaf9-33dddbacb011
4d6c18a9-355d-454e-8ef4-c59d8146fd5b	2026-04-09 21:42:43.186458+00	2026-04-09 21:42:43.186458+00	password	e82304d2-c14c-4339-a1d5-07afa3e53f84
90c9b7b8-c533-4be5-86c9-77e2a42884fd	2026-04-09 22:19:32.658934+00	2026-04-09 22:19:32.658934+00	password	fa71efd7-bee1-45b5-9516-0eec80b5c2ac
853af437-1271-404f-b04a-3a569364e01c	2026-04-09 22:19:32.767559+00	2026-04-09 22:19:32.767559+00	password	41857f04-1592-4a42-8fd4-0c68c4926b17
7c6fc506-745b-4107-a054-8a804f58c135	2026-04-10 05:09:23.232205+00	2026-04-10 05:09:23.232205+00	password	0c094ee7-a237-49b8-aa90-8d45fd913674
b151bf43-e4eb-440c-8117-c319eadef5bc	2026-04-10 05:19:08.684538+00	2026-04-10 05:19:08.684538+00	password	bc9c882e-e14f-48ed-a2d2-23d3a8861493
107c3c53-4020-4707-89da-783b783a238c	2026-04-10 08:27:09.35603+00	2026-04-10 08:27:09.35603+00	password	257745e6-1d39-4dff-94e7-67b828d4ac41
730795c6-6e10-4b42-8bae-acfebe488c23	2026-04-10 09:01:32.846483+00	2026-04-10 09:01:32.846483+00	password	7b365dde-9c06-4d19-8896-510574bc432a
eeb8bb05-c0ee-4c9d-9869-8ecee23b9dbd	2026-04-10 09:04:53.60293+00	2026-04-10 09:04:53.60293+00	password	18326d57-cb56-4c4c-9dca-82f6ff13db0f
c412a67b-c3e5-49f2-8148-e325d54a904c	2026-04-10 09:05:43.49911+00	2026-04-10 09:05:43.49911+00	password	7c099e5b-de77-4140-96c7-ec197d068da8
e39d804d-3d19-403a-bc55-9c5556992cfd	2026-04-10 09:18:31.197099+00	2026-04-10 09:18:31.197099+00	password	30f3bb77-442f-4608-a612-1d9090a474bf
895454fa-5370-4cf4-99dc-9620ed02e563	2026-04-10 10:11:18.037027+00	2026-04-10 10:11:18.037027+00	password	6704513b-1684-4acd-a4fb-57cbece11f48
b13e9062-37f2-4094-aa75-3b54cea9968c	2026-04-10 14:41:21.846602+00	2026-04-10 14:41:21.846602+00	password	cf5d97c6-98b3-4039-97b1-aea71dafcd01
965edad2-085d-4506-940c-d3d94f09fcb5	2026-04-10 14:42:44.633215+00	2026-04-10 14:42:44.633215+00	password	c9586f24-25d3-4061-8568-74e808b6935f
4dd03a28-6c75-4978-ba53-907a795c00df	2026-04-10 15:00:55.819811+00	2026-04-10 15:00:55.819811+00	password	3340e372-3868-4e5a-8eac-7f41f8e82400
efb1fb1a-e0bc-4b43-99c5-75a98dc8b127	2026-04-10 15:48:56.567442+00	2026-04-10 15:48:56.567442+00	password	0a02aa13-c97b-4e71-8b21-c2defc855462
b3b46df2-09ee-455d-82d0-2632025ffc0f	2026-04-10 15:52:41.330256+00	2026-04-10 15:52:41.330256+00	password	69c5df20-9245-4f69-9441-0ac2a11eb126
0ebde23d-6f72-4865-b17f-f6a3a9e7be8a	2026-04-10 16:12:41.850954+00	2026-04-10 16:12:41.850954+00	oauth	af5e10e3-536d-4d87-85dd-ded911833d62
a0688797-88ee-4a28-a749-30bf52f41e4d	2026-04-10 16:13:02.822697+00	2026-04-10 16:13:02.822697+00	oauth	112eeb99-99c6-4640-a557-9e7ffcde4024
7c6b9d36-52cb-4f22-b7ba-6906ab2bb285	2026-04-10 16:13:20.920738+00	2026-04-10 16:13:20.920738+00	oauth	b5ebc6d9-3ade-4fb0-83de-3c65cd06b3b8
7b15ea91-79c6-4f0b-b8c5-3e622813f410	2026-04-10 16:14:20.885237+00	2026-04-10 16:14:20.885237+00	oauth	f66b5fba-964d-4632-818f-7a0a8bd030f1
e516d52e-2a50-4959-870e-53cafefafffa	2026-04-10 16:14:53.211097+00	2026-04-10 16:14:53.211097+00	oauth	16caa145-f431-4c10-aa79-e544c72cb4b1
15dfe990-d8e3-4c76-9fb7-29878ea148f9	2026-04-10 16:29:47.707231+00	2026-04-10 16:29:47.707231+00	oauth	854f59b6-4435-4529-81dd-a23fa8c09e19
7e9ebbe9-868d-40d0-b2fb-ed693bc4ea0e	2026-04-10 16:30:26.389961+00	2026-04-10 16:30:26.389961+00	oauth	1a435bc1-01c3-4bb9-9100-5c0edd7777ab
5256115a-b313-4f00-abde-d25df23916e7	2026-04-10 16:30:47.164688+00	2026-04-10 16:30:47.164688+00	oauth	e07b98af-919a-4ace-9062-9d15463b1ec0
202e2e02-7f0d-4e66-9bb1-849605e0b4d8	2026-04-10 16:31:17.583886+00	2026-04-10 16:31:17.583886+00	oauth	a5d4a661-3885-408f-8457-7269c2fe84d9
846000e9-fa3c-4fb8-83b5-ae8efcc5124f	2026-04-10 16:32:00.259102+00	2026-04-10 16:32:00.259102+00	oauth	b7277b5b-bbea-4907-b666-79b322c65c86
c68158c0-71d9-40a4-a7b8-d3c5e0110fb1	2026-04-10 16:35:43.080543+00	2026-04-10 16:35:43.080543+00	oauth	3bcc1798-183c-4ff1-a1f2-5c12101e1170
292f721d-521a-45c5-8569-954cf514ea96	2026-04-10 16:42:23.228626+00	2026-04-10 16:42:23.228626+00	oauth	6f19a29b-e2a2-48e4-91ca-071ebe0d67f6
f02014fd-bc95-42cc-8df8-9c13c22fb156	2026-04-10 16:44:33.221518+00	2026-04-10 16:44:33.221518+00	oauth	6f5d9c90-470a-4daf-87b4-277f1de783d4
086f5fd8-416c-45ae-83c2-a07eb0c86cf4	2026-04-10 16:46:27.741331+00	2026-04-10 16:46:27.741331+00	oauth	bbb9b3d9-434f-4b88-b81c-ebefba229e84
632aa82e-758e-44af-b046-9bde3d450fde	2026-04-10 16:47:41.815062+00	2026-04-10 16:47:41.815062+00	oauth	3a9b4389-bff8-4225-8021-60a70fee5c68
78acba6b-1edd-4f27-a220-da300b9a2d91	2026-04-10 16:51:12.137505+00	2026-04-10 16:51:12.137505+00	oauth	18db4f9b-3b04-4ade-a63c-e07d35d30388
99e1f7bd-6e55-4561-85d4-81884ba7c836	2026-04-10 16:51:15.404821+00	2026-04-10 16:51:15.404821+00	oauth	36e44ce7-3510-4d80-8b62-c417f724c376
2057b8ca-1005-459e-9ca5-b8ed27ee66ed	2026-04-10 16:51:34.559474+00	2026-04-10 16:51:34.559474+00	oauth	bca4d8f7-383a-428a-b973-19ebdee8e877
12f5ccb1-d502-4b0a-a7de-3e4be0c927a5	2026-04-10 16:53:47.943562+00	2026-04-10 16:53:47.943562+00	oauth	bb166498-a96e-430b-a0fd-07c214bf31c5
7f3a7968-eb00-4302-850e-ac777a3be059	2026-04-10 16:53:51.615311+00	2026-04-10 16:53:51.615311+00	oauth	d89d5f3d-f496-404f-9610-accf865da4e8
283ce205-363d-49c6-ae76-1a9cbd877afa	2026-04-10 16:53:53.3894+00	2026-04-10 16:53:53.3894+00	oauth	c2a8a9db-d7f9-42fe-9815-dc3d4354c0f4
7a1f0588-42c9-4ed7-b0cc-dda4d61c1ac9	2026-04-10 16:57:31.884857+00	2026-04-10 16:57:31.884857+00	oauth	98ae4a3a-a0bc-4df6-90f9-686f4a4a6ef3
b0a04083-52c0-4b16-ac5f-5137c6f35435	2026-04-10 16:58:39.935821+00	2026-04-10 16:58:39.935821+00	oauth	b953a4a6-55a9-4cdb-973b-46825bd4d6d0
8adb3c8c-c1df-46d9-9fba-6a702ba63673	2026-04-10 17:00:12.537222+00	2026-04-10 17:00:12.537222+00	oauth	eff6447e-70b3-4547-9f07-a4ea471b05c6
3c59e60d-0e4e-434a-8d0a-c67568aaa9a2	2026-04-10 17:02:12.83132+00	2026-04-10 17:02:12.83132+00	oauth	d3dce6c2-4c3f-438f-8acb-3c582bc565ef
e0e538cc-501f-4f38-a4df-9ac0934133cd	2026-04-10 17:03:09.251314+00	2026-04-10 17:03:09.251314+00	oauth	a22ed1d5-a6e5-42ed-94e6-6701cbc7798c
7eb67265-79da-431d-80ed-b72cdfa306ce	2026-04-10 17:03:24.187759+00	2026-04-10 17:03:24.187759+00	oauth	270ab21a-58bd-4deb-93ed-f79ca88ae915
2d2eb69b-0c14-456e-af5c-99e14821b375	2026-04-10 17:05:43.225117+00	2026-04-10 17:05:43.225117+00	oauth	a5460b0e-c918-4c37-9808-5604a3705790
3696f9e7-75a6-4c4b-97d0-1e3bd5ac8efb	2026-04-10 17:06:18.048704+00	2026-04-10 17:06:18.048704+00	password	6a5b6ca1-55af-4bf3-84c4-7ef9d32ba1a1
934b3b8f-095f-4735-962e-519807375bbb	2026-04-10 17:06:20.505993+00	2026-04-10 17:06:20.505993+00	oauth	a1a307c3-8189-4673-a76a-e74b607ac992
0956f384-ebca-4f45-adee-3638724d8068	2026-04-10 17:07:23.82107+00	2026-04-10 17:07:23.82107+00	password	6dac28c2-cdba-4d49-b822-6ce3852474db
f64f8e7b-1e2d-4e27-9616-501eff3d829f	2026-04-10 17:10:26.499542+00	2026-04-10 17:10:26.499542+00	oauth	0f0af0f0-5ce6-47b3-9a9f-e31de75a609a
9508a15a-2a02-4fcc-b1e3-d759774a66b2	2026-04-11 07:09:34.42824+00	2026-04-11 07:09:34.42824+00	password	98acb51b-c8b5-4fcb-8f55-a4f73604b9ad
3db53a0e-f2c4-4617-bbc4-873fbf4b7aa4	2026-04-11 09:06:31.412622+00	2026-04-11 09:06:31.412622+00	oauth	fa6d91e7-73e2-48af-b982-c1ea7b54be1f
6692f176-23b7-40d4-8dda-ea5102a0920b	2026-04-11 09:09:06.684604+00	2026-04-11 09:09:06.684604+00	oauth	b185b082-871d-40b6-8767-a2bbd8a8786f
003b3965-9930-46ff-8f8c-ab568e15448b	2026-04-11 09:09:54.942725+00	2026-04-11 09:09:54.942725+00	oauth	ed583ffa-7f35-4866-9be5-8b97b865174f
292fd353-81a9-4968-8bda-f3b5f3524d0a	2026-04-11 09:12:12.362628+00	2026-04-11 09:12:12.362628+00	password	cfe86edb-17ba-4470-befa-c99d180b0572
2694f434-2df6-4043-97bf-a1a023e92ce9	2026-04-11 09:16:14.714277+00	2026-04-11 09:16:14.714277+00	password	e9d38c78-f9ce-4d97-8e74-86757145dbd3
07e8acc3-cc9f-4757-8c4f-cac1a466718e	2026-04-11 09:30:06.629102+00	2026-04-11 09:30:06.629102+00	password	ec677dbe-406c-45fe-8539-5aca09fab64c
10312692-65ed-46a9-9dc2-f813263e3ef7	2026-04-11 09:30:06.651704+00	2026-04-11 09:30:06.651704+00	password	4cb791ec-3e94-4ad1-aa05-7a6eebb38730
e60f3551-c451-46e9-aa93-d0f832eca2da	2026-04-11 09:30:06.775351+00	2026-04-11 09:30:06.775351+00	password	d075107b-ec2e-4532-a0c9-9e1afbfb86d7
1c28a564-15eb-4e6b-a8e8-c60ebf05bd78	2026-04-11 09:34:34.716399+00	2026-04-11 09:34:34.716399+00	password	d7a536cd-04aa-4c0b-8251-ac5470964f7d
59ba7115-3cea-42ad-83a0-5846056f418a	2026-04-11 10:17:53.816419+00	2026-04-11 10:17:53.816419+00	password	e89dc279-8699-40bf-a4b3-d443c9c968e2
ef245e24-09ef-423b-bf83-385d36e80a52	2026-04-11 10:53:52.78586+00	2026-04-11 10:53:52.78586+00	password	5f63052f-6c43-44bd-a65f-0726945aa346
ad859007-f70b-478c-be93-452ed49c300e	2026-04-11 11:55:49.333822+00	2026-04-11 11:55:49.333822+00	password	6458d199-47ed-4d35-a743-865e94ce70ed
55b9ff8f-6aca-40c1-8e7e-3957bb09be0c	2026-04-11 12:51:38.757526+00	2026-04-11 12:51:38.757526+00	password	91ae76b1-d726-45fd-8875-5c11113c75f1
06b2ceac-a05a-4017-ac6d-ec15345efb19	2026-04-11 13:03:49.819088+00	2026-04-11 13:03:49.819088+00	password	1bd926b1-46a0-4600-959b-9089bcb59b2a
3f14eb88-e31a-4fb2-ae11-3fed723df711	2026-04-11 13:31:08.863459+00	2026-04-11 13:31:08.863459+00	password	b4e728bf-cc24-4e54-aa7e-56ad9d9c73c8
f8d90d41-2fb4-43bd-a606-bd1d33a1c7b4	2026-04-11 13:40:01.553792+00	2026-04-11 13:40:01.553792+00	password	88a57605-4ebc-4ce4-8de9-86d069b4bda1
ae92d4d9-9950-4674-a655-106d46666883	2026-04-11 13:45:14.370676+00	2026-04-11 13:45:14.370676+00	password	260d57da-41ca-479f-9223-6504ae8a2721
474689b1-275b-49b1-912c-f8e282c019e4	2026-04-11 13:51:22.184407+00	2026-04-11 13:51:22.184407+00	password	03a5764e-cbea-4072-95ac-88182b876fb6
520684cd-cd01-47e3-b0cc-c09cfee2d2e8	2026-04-11 13:56:34.652062+00	2026-04-11 13:56:34.652062+00	password	14d284e4-672f-4402-9f0b-22f58c5c34d6
e032c352-7dad-4a60-9757-6da3b36f87aa	2026-04-13 03:48:40.075429+00	2026-04-13 03:48:40.075429+00	password	6ceea210-6b59-4af1-81f3-c0d4b1713f70
bac8d93a-d73f-4e62-a520-346f3e3ffea5	2026-04-13 11:20:01.001702+00	2026-04-13 11:20:01.001702+00	password	8ab4da22-c564-4c94-9d38-ea7ba10bbdf0
fda68434-192d-4b25-bbc6-aec0a0b8d19d	2026-04-13 13:54:01.894701+00	2026-04-13 13:54:01.894701+00	password	29e86f28-c4f0-47d2-b601-e7d6d8eda626
19004738-5909-4cde-8365-ac413d966b6c	2026-04-13 14:05:30.330016+00	2026-04-13 14:05:30.330016+00	password	4d77a097-c365-41d0-b2d8-43de7fe765f1
9ef6999a-c45f-4bf8-98e6-eb97688030c2	2026-04-13 14:06:17.955397+00	2026-04-13 14:06:17.955397+00	password	c44a5de0-8817-4740-8b83-7fb2ecd75de6
a2ba4e36-3153-481f-a290-515205ea36bd	2026-04-13 14:08:22.457268+00	2026-04-13 14:08:22.457268+00	password	3eef896f-d2a9-4edc-a3cb-1a98a60c2607
ad494a33-0e49-4e91-839c-d99239a4edf4	2026-04-14 05:58:00.093873+00	2026-04-14 05:58:00.093873+00	password	16c7efc2-c3dd-4ad6-8915-6ed4c1193f3d
512cc0a7-aa75-4029-a2e7-60c8439acd1b	2026-04-14 06:07:16.656101+00	2026-04-14 06:07:16.656101+00	password	4f25f9e1-eb2b-4080-87e8-49f91803b1a8
301021e1-45b8-4126-80db-0a80c542f57b	2026-04-14 12:36:46.122668+00	2026-04-14 12:36:46.122668+00	oauth	a469d4b1-f6de-419f-bc94-b9ee167cd023
60f0333f-7c0d-49f5-abc4-d79ef8ccd579	2026-04-14 12:38:55.750402+00	2026-04-14 12:38:55.750402+00	oauth	a9a1bdbb-7b29-4ba2-8cde-49310135dd50
2257693b-1afe-4371-8279-b418139efb66	2026-04-14 12:39:15.178788+00	2026-04-14 12:39:15.178788+00	oauth	4fed1fcd-131c-4f67-8dea-c75e4b95ff76
7f2c308f-dec8-439f-aad0-3398795292a5	2026-04-14 12:43:09.412601+00	2026-04-14 12:43:09.412601+00	oauth	899970df-4ef0-47f4-a248-c83604bc830a
64c80928-9861-4d0b-8cb7-5840abab701c	2026-04-14 12:59:51.897538+00	2026-04-14 12:59:51.897538+00	password	fc513aeb-68a4-4787-8e02-091ef75cedc5
6603ed2f-67dc-4878-9a39-14611d383f0a	2026-04-14 15:21:58.510054+00	2026-04-14 15:21:58.510054+00	password	47bff86c-c4ee-4300-bf3a-7a67a216aa34
04077440-648c-46ff-8d3e-91db2d139df6	2026-04-14 15:36:23.488207+00	2026-04-14 15:36:23.488207+00	password	a7f26899-d9bc-4c6c-a55e-d21876cdcfc3
bbf42b3c-9c63-4b78-9c4c-2329e8fd1c6e	2026-04-17 10:12:59.092787+00	2026-04-17 10:12:59.092787+00	oauth	394c112e-9b76-44dd-834c-96c6902f3806
134767f5-c810-439c-a555-fab0dd2b6c8f	2026-04-17 10:13:19.143453+00	2026-04-17 10:13:19.143453+00	password	be485e8d-ee03-47ee-999a-e321ba1ae9fb
c71f1c13-f6ea-4b1f-a4cf-16bc7fa0fd85	2026-04-17 11:27:35.266988+00	2026-04-17 11:27:35.266988+00	password	edb53880-f657-4022-9e9f-3e71ca5beb9c
bbccc945-19f6-4ffd-8607-3bf905e083e3	2026-04-17 12:06:04.011338+00	2026-04-17 12:06:04.011338+00	password	46445bfb-e305-45e3-9d0c-85f82f30b631
15a87b72-219f-4a9f-baac-230af6e36039	2026-04-22 09:06:12.753098+00	2026-04-22 09:06:12.753098+00	password	935d6aac-26f7-4585-8bb4-3837d8450eed
de953c7b-1d6c-4ce7-9781-f9095836ec07	2026-04-23 04:08:58.858475+00	2026-04-23 04:08:58.858475+00	password	750ab4a6-a0d7-494d-9a22-4c89bb65d7a3
43c74528-18ca-4519-9aeb-f06147467b38	2026-04-23 04:08:59.079904+00	2026-04-23 04:08:59.079904+00	password	38e0dab6-1244-410a-bca5-f4db779b6e14
1cad9c4a-87dc-4a5e-ab8e-4c2dec41487b	2026-04-23 04:18:30.874804+00	2026-04-23 04:18:30.874804+00	password	46bd07f5-325f-4edc-bc32-da83850915c4
866d904d-d838-43b8-9947-350497ff3b98	2026-04-23 04:32:48.830109+00	2026-04-23 04:32:48.830109+00	password	0e3880eb-cf1d-4036-88b5-fb9c0fe62def
522c813d-8c54-4b54-9809-b13cf8be9826	2026-04-23 04:34:21.945646+00	2026-04-23 04:34:21.945646+00	password	cb295ba6-07cf-4fed-809e-b3c69cbde24f
ed7b6210-1e89-4b93-9987-c8524f8c2a95	2026-04-23 04:36:34.810332+00	2026-04-23 04:36:34.810332+00	password	9165238c-2428-48a6-994f-af0a22ce2fd8
142fed24-3fd1-436a-9d89-d0822e88f5a8	2026-04-23 04:47:21.230388+00	2026-04-23 04:47:21.230388+00	password	e1860093-0355-4cf1-b6f0-60fb2451b324
e3708d9a-b8a4-46ab-8f43-ed369693b9a2	2026-04-23 04:47:21.264664+00	2026-04-23 04:47:21.264664+00	password	e0ab2d9e-7c95-4d16-9842-ff9f23b592e0
ae64e15d-6d2a-4623-8c09-8c4727b19112	2026-04-23 04:54:58.187061+00	2026-04-23 04:54:58.187061+00	password	2e7b1b3b-2ae8-4fc7-b3e0-79981b92d656
0d3666d1-4386-464d-b736-6009559e0328	2026-04-23 04:58:59.053125+00	2026-04-23 04:58:59.053125+00	password	99cb2c84-fa51-455a-879f-def8dab693cd
82ddf6b8-e582-4e63-892d-5c18edcfacce	2026-04-23 04:59:58.385233+00	2026-04-23 04:59:58.385233+00	password	bca529f2-acb0-4b47-b742-4b52da9f6a21
f499267d-7e1d-4916-9edf-9066996bdc27	2026-04-23 04:59:58.713585+00	2026-04-23 04:59:58.713585+00	password	ce9ae81e-97a2-4b91-a95f-db4018145bd6
ec960bb7-ead4-42af-ae91-33c3e05ff0aa	2026-04-23 05:06:08.015781+00	2026-04-23 05:06:08.015781+00	password	f51b5728-910e-48bb-bf3c-2af852cee894
708f8bf8-89ab-448d-95c6-caa12a894a3a	2026-04-23 05:07:54.521237+00	2026-04-23 05:07:54.521237+00	password	a72c6293-dae0-4704-913d-55f011eeef93
f36230c8-dc1a-4882-962d-10b3d099045a	2026-04-23 05:07:55.072086+00	2026-04-23 05:07:55.072086+00	password	697f05f0-4a48-49eb-8241-df0283ca9a29
e29606d5-f536-4d2f-9fae-39dbe5ba2d67	2026-04-23 05:16:16.557545+00	2026-04-23 05:16:16.557545+00	password	97eb9b5e-a9e7-487e-b43a-fc954f2b23ca
450c3154-d86b-458c-8de6-cec1c3c4c72d	2026-04-23 05:19:33.384382+00	2026-04-23 05:19:33.384382+00	password	be87b3b4-1454-4325-914c-310a33481fea
789a758a-becd-4e6b-bae3-91a90ed35d74	2026-04-23 05:20:29.222291+00	2026-04-23 05:20:29.222291+00	password	3f369154-ef2d-4bbc-a6be-de3b159457c8
1cdc98b7-6bca-4b85-8577-0fedfcd5479d	2026-04-23 06:20:33.212184+00	2026-04-23 06:20:33.212184+00	password	f56da5d3-c1ec-4df9-ac74-10839e4ba5f6
3e636757-f459-4475-81ec-a9acc46912fe	2026-04-23 06:30:14.23254+00	2026-04-23 06:30:14.23254+00	password	efbc0dff-d728-426e-a8da-85ccef8a7522
6e129402-ff18-45de-8c4b-d4db15e4d9f2	2026-04-23 06:32:03.768784+00	2026-04-23 06:32:03.768784+00	password	8d32991a-7f5d-46e2-8868-47c39037bdfa
7f600af5-fd5e-46d7-a357-0d2aacc833b5	2026-04-23 07:41:23.397027+00	2026-04-23 07:41:23.397027+00	password	06aeec65-ba41-40f6-8684-c2a30d5c3a25
837f156c-e13e-4c6b-a65c-b9521fc036b6	2026-04-25 07:11:22.135539+00	2026-04-25 07:11:22.135539+00	password	6c89fc04-2ef1-43ba-a3b0-eefcc64bb125
30afd630-1eb3-4d12-bab5-72efc3aa6fc5	2026-04-25 07:20:18.185732+00	2026-04-25 07:20:18.185732+00	password	98fef670-894b-42c2-b4ab-da737b4daf56
1e7c37a9-acd1-4514-b246-9bccbd131e9c	2026-04-25 07:21:58.102305+00	2026-04-25 07:21:58.102305+00	password	90fe8f1c-4007-4a8c-a1c8-3d46624d8116
93183258-df1a-4289-ac1e-3a93cc3cee38	2026-04-25 07:22:13.508115+00	2026-04-25 07:22:13.508115+00	password	21bbbbc9-5141-41c1-90a8-f2db85eb0aef
61b300dc-c5fd-480d-be95-bd3c34e65722	2026-04-25 07:26:07.911542+00	2026-04-25 07:26:07.911542+00	password	da0d4b48-b859-4ca4-bea3-da86e06418d2
2497a9b2-5060-4936-aa07-3e3a875a4df1	2026-04-25 07:26:52.592364+00	2026-04-25 07:26:52.592364+00	password	b900d8bc-33d6-4259-bcf3-a53fd423f64b
59547bab-e551-45b8-b459-dee61fe3180c	2026-04-25 07:28:19.277486+00	2026-04-25 07:28:19.277486+00	password	6b184b9c-2164-4c71-a527-67a682603bdd
2e917f3f-e275-4a33-87ef-80fa832b198a	2026-04-25 07:44:09.555881+00	2026-04-25 07:44:09.555881+00	password	fac0ee09-3ad6-4947-8f5a-6ca51155c4c0
cf005b5b-240c-4817-a1dd-e1a94262e0cc	2026-04-25 07:45:34.934227+00	2026-04-25 07:45:34.934227+00	password	24ae62cb-7a60-43cf-8744-f46c55493b96
ec07e553-53f0-46a4-8be7-2000403f6880	2026-04-25 08:05:53.028767+00	2026-04-25 08:05:53.028767+00	password	1e08db44-f5ec-4a8d-8ecc-9ed45626ec6d
6d6f187d-0a97-4b20-b42f-db786b8806a0	2026-04-25 08:51:17.203927+00	2026-04-25 08:51:17.203927+00	password	11ff4a60-4749-46ef-ad83-b1b12d642172
20ee1434-65ec-4218-b286-57cd2deba9ff	2026-04-26 07:51:19.319681+00	2026-04-26 07:51:19.319681+00	password	0dc6486f-4c1b-49a3-89fe-a7920879d682
400a2425-c85d-4496-86f2-c5f3a8c5e173	2026-04-26 09:04:45.921331+00	2026-04-26 09:04:45.921331+00	password	afd21a39-1b26-47ce-99b8-4e5305d7efce
9ee7992c-859a-454e-b3b7-ae938f59897f	2026-04-26 09:54:59.281694+00	2026-04-26 09:54:59.281694+00	password	c433c140-9e88-44d7-82d8-8ebb7348b054
aa203841-80bd-43cc-9173-5746b29433b8	2026-04-26 15:50:15.021632+00	2026-04-26 15:50:15.021632+00	password	9612dcef-2422-4274-aca8-42859bd1fb07
f20e91a2-ab5a-44ae-9f2f-8224659364a6	2026-04-26 16:09:28.903655+00	2026-04-26 16:09:28.903655+00	password	7270f8e7-2f54-47d4-a0b5-f3108d693140
199e2056-5d90-4ce5-9aa7-11d5f59b5668	2026-04-26 16:10:08.942968+00	2026-04-26 16:10:08.942968+00	password	61183008-28f1-4901-b2f3-f2c9f56426cc
cf3f4c69-64a9-471b-8f22-39f79acccb6f	2026-04-26 16:38:36.31029+00	2026-04-26 16:38:36.31029+00	password	3be0939c-9138-4549-a0f9-c149e8bb40a2
40a3fd43-4ae9-44bb-92bc-60ee9c38c0f9	2026-04-27 07:32:16.238457+00	2026-04-27 07:32:16.238457+00	password	f3834bd0-d787-4063-9692-d17c01b55875
8af31811-1f63-482e-bafb-347aca143299	2026-04-27 07:33:46.630879+00	2026-04-27 07:33:46.630879+00	password	6baccd01-3b62-4461-9e73-4973b474d27a
62d42694-f59f-4410-a26a-7c8ede8dc3ed	2026-04-27 07:49:20.772835+00	2026-04-27 07:49:20.772835+00	password	5c2153ba-6bc4-42c0-97e0-7babefc4934e
ff711ff8-0c2f-47c7-91f8-a87609860615	2026-04-27 08:22:50.848226+00	2026-04-27 08:22:50.848226+00	password	e2de05f3-d3d0-4431-8b00-fd7f65942b7d
e9618869-24d6-4a54-a65d-f79d05bf86c4	2026-04-27 08:34:13.249762+00	2026-04-27 08:34:13.249762+00	password	c92d0a03-3f42-4a60-a191-292a6406a3c5
1cbf971e-ee8e-4b64-bc57-bd0179738cc0	2026-04-27 16:26:39.293051+00	2026-04-27 16:26:39.293051+00	password	e0bd49df-a78b-41bb-aa09-f13732680343
05fdcbb8-7bd1-4b03-a9d0-9209fbff7043	2026-04-27 16:28:05.078598+00	2026-04-27 16:28:05.078598+00	password	29740b50-f9ab-4951-9907-ff644803963b
1cdd067d-162b-43af-ad75-9816962f9949	2026-04-27 17:47:19.158615+00	2026-04-27 17:47:19.158615+00	password	67e9f8a2-4cf1-40a9-86d8-56cb001577e7
2b072cf8-3998-4c14-83e8-4284faffc351	2026-04-27 18:11:05.383793+00	2026-04-27 18:11:05.383793+00	password	054c9cc7-a6b3-4a34-a2fd-83c139bfeab2
e2319ddd-38f2-4be8-ae50-0314cd6056ec	2026-04-27 19:16:29.237668+00	2026-04-27 19:16:29.237668+00	password	50a5c700-2d9c-425b-b523-a8bf7c663676
9f7d3b81-fae5-45ea-994e-5f05bc01521a	2026-04-28 14:00:38.82598+00	2026-04-28 14:00:38.82598+00	password	de384168-db9a-4fa6-9d70-382b8821a88d
7641547c-c648-402f-a9a9-43025fd40763	2026-04-28 14:36:38.20975+00	2026-04-28 14:36:38.20975+00	password	0418af1d-8357-4d9e-b36f-0003dc51cc83
5191d1f1-cb05-4eaf-833a-0edf35c35f8d	2026-04-28 14:38:36.676762+00	2026-04-28 14:38:36.676762+00	password	9a8715b1-5ce0-48c5-bd7f-172f7f70fbcf
ae7f4174-8a0f-44bc-b540-88e7f86e4ea7	2026-04-30 15:26:22.508679+00	2026-04-30 15:26:22.508679+00	password	a24c013e-8226-4c22-abd3-27c801b882f3
8bcc60ba-6d73-41f1-98d3-2733814e470e	2026-04-30 17:44:16.695213+00	2026-04-30 17:44:16.695213+00	password	9817e33b-8c6b-470c-99c1-15bd41228581
742e7725-6094-4cf8-9a5b-cd5d942d1e04	2026-05-01 01:20:21.703806+00	2026-05-01 01:20:21.703806+00	password	c2f35027-925b-4dfc-b76c-4f47ff79036b
f42ca4bb-08d5-411d-96f2-7391c3afbd46	2026-05-01 02:02:42.987577+00	2026-05-01 02:02:42.987577+00	password	00b18604-5e7a-433e-bedb-20971b568331
8fffaf74-714c-414b-a594-74ddf9741101	2026-05-01 06:20:34.837761+00	2026-05-01 06:20:34.837761+00	password	56ffa522-7898-4a04-977c-c174a9afd4c7
bfb580a2-9591-4653-ab7a-2e4c5fa6afe3	2026-05-01 06:48:27.178345+00	2026-05-01 06:48:27.178345+00	password	0e20793a-f441-4b02-97df-f1f9aea2d489
782335c8-92d6-4b46-ba89-8b81eb4be51c	2026-05-01 07:01:52.926501+00	2026-05-01 07:01:52.926501+00	password	3e19e1f3-ffd4-4ec5-aec7-ad04dca3bd7f
81ea8cdf-d813-4dc3-8a59-05cacdb7d098	2026-05-01 07:07:18.398411+00	2026-05-01 07:07:18.398411+00	password	dbe9358f-add9-48ae-91b7-2e5720ac9b7a
6d5696e0-1092-4d21-bb85-5084d80704e4	2026-05-01 08:19:58.322054+00	2026-05-01 08:19:58.322054+00	password	043ad466-eb6a-4cd5-ba26-f90259ed7401
6d4dfaec-07d8-4ce8-8f02-b29366a4b1da	2026-05-01 09:06:19.83904+00	2026-05-01 09:06:19.83904+00	password	a6bbe10d-2ff3-43c8-8959-298ff9a7b5ec
962c4531-eb5a-42b0-b95d-b9c1365d8c8f	2026-05-01 09:10:46.211021+00	2026-05-01 09:10:46.211021+00	password	876974cc-9dbe-41f5-a92f-2ea5ca8522c0
e6a3f828-1bde-44ab-b5fe-24bb16c98be0	2026-05-01 13:06:45.463744+00	2026-05-01 13:06:45.463744+00	password	9c0bf976-0ee4-4281-9403-bbeaf6a6632f
1997b91d-e471-4d0d-a2bb-df5fe442c36c	2026-05-01 14:19:55.966157+00	2026-05-01 14:19:55.966157+00	password	9abc8abb-3b9d-4cf2-8074-a4605ae996ef
3b9d0ec0-36d0-4a25-b018-c235f9a93629	2026-05-01 14:27:08.861769+00	2026-05-01 14:27:08.861769+00	password	3b2de065-aad3-4aeb-95ef-cb178f738ba8
8a8da4c8-0118-4a9f-bb1f-a0cad1ce1daf	2026-05-02 09:56:07.549505+00	2026-05-02 09:56:07.549505+00	password	5a130c05-00fe-475c-a813-510d0c21921e
383bed75-5c57-4a04-9303-3a8b0567ab3c	2026-05-02 10:10:14.673639+00	2026-05-02 10:10:14.673639+00	password	185a952b-de28-49b0-b6f4-21c37cc84939
39a139b2-624e-456c-874f-5c711b37838e	2026-05-02 11:40:59.204053+00	2026-05-02 11:40:59.204053+00	password	a79216ba-735d-46b6-aed0-4c8b4932b23a
fb85bd44-f69b-4a13-98dc-6321840f5007	2026-05-02 12:01:20.717609+00	2026-05-02 12:01:20.717609+00	password	087b430b-e027-4c31-a666-39297bb2d30e
d3d07b39-f66f-4443-a112-5a4f1c8e56fc	2026-05-02 16:07:12.452142+00	2026-05-02 16:07:12.452142+00	password	8df3603b-c543-4899-a75c-92ac26a3f239
cddf1de4-bbaa-4abd-bcc8-af2d17435e06	2026-05-02 16:10:29.218373+00	2026-05-02 16:10:29.218373+00	password	64c2d7bd-308e-4b93-a690-f595e083276b
0acc2bf0-119b-4927-a968-f2b7ce0c52f7	2026-05-04 10:26:54.755677+00	2026-05-04 10:26:54.755677+00	oauth	924ab1b2-9c9b-41c5-b1f8-82bd143a86f9
3b46e5a8-cbc9-43a4-a63c-89698fdd0fb4	2026-05-04 10:29:01.866599+00	2026-05-04 10:29:01.866599+00	password	d35fa3d0-1617-4949-9f31-4ad2bbb0c330
22b18105-79b2-4147-9b54-2c96a5fbc748	2026-05-04 11:06:17.707436+00	2026-05-04 11:06:17.707436+00	password	420f693b-4dc6-4975-89ab-860da8e5cada
4f08a901-8d1e-4112-9c15-808ebedfb9c2	2026-05-04 11:09:55.556496+00	2026-05-04 11:09:55.556496+00	password	9723ef65-1cbe-4a9c-a64a-37aa55edb538
26d1ef9f-4ac7-4d4e-baf0-0321d422a933	2026-05-04 11:17:38.832597+00	2026-05-04 11:17:38.832597+00	oauth	42e0474f-ca8a-46b4-b8ef-91448635e589
18955def-8aef-4bff-bacc-42e47501b39d	2026-05-04 11:22:20.550042+00	2026-05-04 11:22:20.550042+00	password	76370a9b-02e6-447c-8b2b-ceb535965882
9aa95227-cb72-4ac8-ae6b-1ce60dbf0cbc	2026-05-04 12:50:29.731148+00	2026-05-04 12:50:29.731148+00	password	6a4afd83-5d94-4236-af48-675c4b675647
271ee288-b483-4e81-b696-f7ba1a92d95f	2026-05-04 13:12:47.774164+00	2026-05-04 13:12:47.774164+00	password	a63d9ac5-7970-481d-8e58-e8a16bc88258
bf0fd37f-0fa9-4edd-bf7d-9765348598ce	2026-05-04 13:16:37.599816+00	2026-05-04 13:16:37.599816+00	password	29349336-90c0-41d3-9c00-cd903e7d6981
0a561128-767e-486e-8ad4-708497c76b3f	2026-05-04 13:19:29.4617+00	2026-05-04 13:19:29.4617+00	password	a9e18496-87bf-4a14-815e-f23438e70493
784695ac-1358-445f-92b1-ff40b95305b1	2026-05-04 13:22:52.366297+00	2026-05-04 13:22:52.366297+00	password	67298a97-0143-40d6-aba8-c9ec7c8b2528
9e5ff786-e71b-4194-a2cd-84a597343d8a	2026-05-04 13:28:19.696047+00	2026-05-04 13:28:19.696047+00	password	3720ca0d-a863-4da9-8148-baed8575b4b3
a5faaf51-7136-4bd4-93e6-1976a525a986	2026-05-04 13:31:23.384576+00	2026-05-04 13:31:23.384576+00	password	6f9866cb-1467-40e6-a343-d4b0de87c333
b508f14d-e413-4a16-a855-f83c2848fcef	2026-05-04 13:36:10.135137+00	2026-05-04 13:36:10.135137+00	password	4c22d321-09e0-4d0a-8123-018eb1531387
9aa136a9-8f95-4cff-b636-ef5833db697c	2026-05-04 13:37:34.837349+00	2026-05-04 13:37:34.837349+00	password	df473aa9-ef3d-4059-a1b7-9d4627d5830b
6eccbdc1-253f-4634-a0ff-fe3a0d05985a	2026-05-04 13:39:14.902046+00	2026-05-04 13:39:14.902046+00	password	fecedb57-eea8-4ff4-9ccb-8c315c78fd41
3db5d471-14d4-4740-b317-36e5310b6127	2026-05-04 13:39:34.825113+00	2026-05-04 13:39:34.825113+00	password	cab6783e-71f4-4f8f-b800-90b1c23bee55
9fd983ef-6082-4532-ac21-aeff8cf8529b	2026-05-04 13:42:21.687783+00	2026-05-04 13:42:21.687783+00	password	20b3bafe-da77-4ef5-9cf0-5a3ab8270ade
55ea2531-9642-4600-a2c2-ac42cf20fd29	2026-05-04 13:44:06.570023+00	2026-05-04 13:44:06.570023+00	password	0bed924b-2adf-4d15-97e8-447d0ece0c21
d66310fb-a991-47a0-9b56-92182d261438	2026-05-04 13:49:56.933349+00	2026-05-04 13:49:56.933349+00	password	13d0ad40-5afe-484e-8722-bf787b33749d
406eee40-0460-4967-835b-3a0c698de3c0	2026-05-04 13:56:19.121887+00	2026-05-04 13:56:19.121887+00	password	cf21c022-778c-4fda-a252-b806d425ec9c
91a2d06e-b4fc-4758-99c5-7ff4044c354f	2026-05-04 13:57:42.630505+00	2026-05-04 13:57:42.630505+00	password	dad321f2-f275-47a2-acee-d7880b14135f
9534a5a0-4a59-4509-8219-b7b423e78f45	2026-05-04 13:58:33.910411+00	2026-05-04 13:58:33.910411+00	password	f579e7ee-5560-4225-b9d1-bb2ce1854ac5
6efa0733-afd7-4fd9-a1b6-1a81b2a950b1	2026-05-04 14:01:32.012698+00	2026-05-04 14:01:32.012698+00	password	01f7edbe-8fdb-42c0-99a0-e4a24d671615
156740f7-41a1-49b7-8720-5fd84ced4089	2026-05-04 14:06:18.715121+00	2026-05-04 14:06:18.715121+00	password	5a6cf82a-7b15-46ad-adae-d3e7a7439fbc
ea062a4b-fc3e-4deb-a2c3-f7b9d616d25a	2026-05-04 14:07:07.339035+00	2026-05-04 14:07:07.339035+00	password	a725b29c-09f0-4785-bfce-fedd2d47fc38
0da322a3-9ddd-4d84-9976-c7d5cb5aea74	2026-05-04 14:09:04.578366+00	2026-05-04 14:09:04.578366+00	password	cd6f8cc4-c413-4562-9a2c-8c23779c040e
5f184909-fe5c-4fc1-ad7a-486d3b3e9c89	2026-05-04 14:13:25.603774+00	2026-05-04 14:13:25.603774+00	password	c8e34835-1c38-459b-8ce4-33fe72de1df4
85566771-04bc-4947-ad48-3bb5192e30a5	2026-05-04 14:25:28.844685+00	2026-05-04 14:25:28.844685+00	password	3e326c26-be2a-4964-8091-b458f6d8ff2d
2735619f-7862-47d2-a1f3-73386e4cdb61	2026-05-04 14:27:32.957496+00	2026-05-04 14:27:32.957496+00	password	014497f0-ed14-4e92-8376-e02ffc2bc483
cb2aed6f-5bec-4cb8-a18b-6fe17900bd18	2026-05-04 14:34:07.050389+00	2026-05-04 14:34:07.050389+00	password	cd8be7fa-610c-44d4-b6a8-54c6f0c02f59
16c8d526-de6c-4e64-a752-5bd21fac4d64	2026-05-04 14:39:04.39286+00	2026-05-04 14:39:04.39286+00	password	d8c02707-e2e8-490a-8091-3d7dd2c122e8
f2d9cadb-4971-4305-a788-14b15222ab44	2026-05-04 14:41:19.708593+00	2026-05-04 14:41:19.708593+00	password	d3fb3e24-ac1d-4c5b-8a08-ff47f31d39ae
f473ec2e-6b3e-47be-9991-1876f4663cf8	2026-05-04 15:09:23.68966+00	2026-05-04 15:09:23.68966+00	password	7995b474-e041-484e-acee-e72fdf0652eb
273540f7-359b-498f-a51d-6cd362c9c412	2026-05-04 15:21:31.562476+00	2026-05-04 15:21:31.562476+00	password	6500cf90-8210-4061-8e9a-97d3ecdfd2cd
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid, last_webauthn_challenge_data) FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_authorizations (id, authorization_id, client_id, user_id, redirect_uri, scope, state, resource, code_challenge, code_challenge_method, response_type, status, authorization_code, created_at, expires_at, approved_at, nonce) FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_client_states (id, provider_type, code_verifier, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at, client_type, token_endpoint_auth_method) FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_consents (id, user_id, client_id, scopes, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
00000000-0000-0000-0000-000000000000	84	jz32xbk6zg5b	b7ea8833-6fff-4302-8d1b-4424676cb299	f	2026-03-28 08:31:55.120179+00	2026-03-28 08:31:55.120179+00	\N	e8a00a84-273b-483c-b0ff-83a9e3615c01
00000000-0000-0000-0000-000000000000	133	igvqo7zjw2ex	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 04:29:59.889186+00	2026-03-30 04:29:59.889186+00	\N	f5e3e664-975d-4b0a-b33a-5ab39ac418f8
00000000-0000-0000-0000-000000000000	135	z5wbem44f4pg	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 13:42:52.873735+00	2026-03-30 13:42:52.873735+00	\N	3e559c7e-1091-4689-b4a1-e1dc37bf377d
00000000-0000-0000-0000-000000000000	137	ydjc2rlglm3s	9a54cb41-ee7d-417e-9563-9fb95a35c29c	f	2026-03-30 15:19:41.772059+00	2026-03-30 15:19:41.772059+00	yfdj7rjw6acg	3d4f2bff-d3a0-4036-8fa7-3c02c9cf5d9d
00000000-0000-0000-0000-000000000000	139	2grwdihuput7	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 17:34:13.428223+00	2026-03-30 17:34:13.428223+00	\N	75d31b9c-c80d-44dd-9a03-4e2288d73f77
00000000-0000-0000-0000-000000000000	280	v4osgvpi3xse	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-04 03:57:27.047536+00	2026-04-04 03:57:27.047536+00	\N	7fc03b47-c7c1-4780-8f89-3310bbd03a61
00000000-0000-0000-0000-000000000000	143	cdbv3wk65cyf	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 18:03:17.23057+00	2026-03-30 18:03:17.23057+00	\N	17262a5c-d9da-4f53-bb82-d90c3064e6dd
00000000-0000-0000-0000-000000000000	145	vowu5o5o3xbf	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-30 21:58:57.44821+00	2026-03-30 21:58:57.44821+00	\N	7bd622c1-32a1-4c81-bd09-85b64b99060a
00000000-0000-0000-0000-000000000000	351	4g3baysfttmz	b7ea8833-6fff-4302-8d1b-4424676cb299	f	2026-04-05 09:08:17.941245+00	2026-04-05 09:08:17.941245+00	\N	cd87ed4e-bb74-42e5-932c-f6fd58c6c9c7
00000000-0000-0000-0000-000000000000	356	depv6b2fpwtq	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 15:50:44.050344+00	2026-04-05 15:50:44.050344+00	\N	654d799b-5c16-42e6-9889-d3538e11b2f0
00000000-0000-0000-0000-000000000000	104	bkdtix5z2api	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 10:49:53.515449+00	2026-03-28 10:49:53.515449+00	\N	c021202a-ecea-40c3-887c-473c4b4ec0bf
00000000-0000-0000-0000-000000000000	283	gplsvxgxhzl7	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-04 03:59:23.86945+00	2026-04-04 03:59:23.86945+00	\N	cebd5bef-5261-4bbe-b58c-59a0cdb57768
00000000-0000-0000-0000-000000000000	107	jnjr4fadfkmw	ca38c166-41e5-4f9d-b14a-caa71d08be01	t	2026-03-28 11:28:14.286692+00	2026-03-28 12:59:33.991673+00	\N	3d329806-9118-42b4-9c8f-ef0e302f0cc8
00000000-0000-0000-0000-000000000000	109	knu54wjgbjrz	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 13:22:47.951492+00	2026-03-28 13:22:47.951492+00	\N	382934bf-9061-4b64-a014-9e9aa79c72d9
00000000-0000-0000-0000-000000000000	150	p46g74gwpo3z	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-31 08:05:57.936858+00	2026-03-31 08:05:57.936858+00	\N	7f2d65d3-c90c-456a-825e-b6c4b0c5132f
00000000-0000-0000-0000-000000000000	152	lrm6glx7gtjl	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-31 17:42:01.581059+00	2026-03-31 17:42:01.581059+00	h5f5iacy4zmj	e79494cf-3acc-4de2-9f2c-cb34d60e456b
00000000-0000-0000-0000-000000000000	154	iu5no74ligvk	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-31 18:16:25.949148+00	2026-03-31 18:16:25.949148+00	\N	0599110c-70a3-43b5-8eba-e6d3e86df115
00000000-0000-0000-0000-000000000000	115	zei3rht547vp	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 15:50:14.357814+00	2026-03-28 15:50:14.357814+00	\N	a5800bb6-a6c4-4c6e-ac71-721e31ce5ec5
00000000-0000-0000-0000-000000000000	123	utra3kogmo4n	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 17:06:01.907464+00	2026-03-28 17:06:01.907464+00	\N	1f1b6f71-bb3f-4fb0-985f-57148503ae26
00000000-0000-0000-0000-000000000000	125	pwssjhllqiuh	b7ea8833-6fff-4302-8d1b-4424676cb299	f	2026-03-28 17:10:35.781454+00	2026-03-28 17:10:35.781454+00	\N	5f283801-6258-4685-a036-a138031ba1ac
00000000-0000-0000-0000-000000000000	127	ovzexvxlkgbd	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 17:17:20.884418+00	2026-03-28 17:17:20.884418+00	\N	b71c06e8-0eba-4aab-bdde-19c57b0a0adc
00000000-0000-0000-0000-000000000000	129	5b3ytvhwumow	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 17:38:30.375412+00	2026-03-28 17:38:30.375412+00	\N	9974e216-5cb6-4c74-8cbd-cad4cdcce380
00000000-0000-0000-0000-000000000000	131	4h4sry7fxsor	ca38c166-41e5-4f9d-b14a-caa71d08be01	t	2026-03-30 03:18:41.66062+00	2026-03-30 04:16:59.298275+00	\N	fd1ea4aa-e0d9-4fee-932c-83032fa4290d
00000000-0000-0000-0000-000000000000	160	7pesdj7xr7xi	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-01 01:50:48.418987+00	2026-04-01 01:50:48.418987+00	\N	0249cdd6-8123-456f-aa2e-30ce29ad020e
00000000-0000-0000-0000-000000000000	289	afbnfbeumbqf	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-04 07:51:05.586983+00	2026-04-04 07:51:05.586983+00	\N	ad7d0121-8d1c-4cff-9540-8fa093f1572a
00000000-0000-0000-0000-000000000000	290	tb3znygwysl3	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-04 07:51:27.202163+00	2026-04-04 07:51:27.202163+00	\N	fe23c9d7-936d-49c6-86f1-1d4336e20a51
00000000-0000-0000-0000-000000000000	291	xfz7qr2vkbng	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-04 07:52:50.458115+00	2026-04-04 07:52:50.458115+00	\N	251437b2-4a55-4dc1-b22d-6c010b579759
00000000-0000-0000-0000-000000000000	292	tom74hls2cmg	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-04 07:53:45.498317+00	2026-04-04 07:53:45.498317+00	\N	4e068938-b824-4e70-846c-c4ddd6dec225
00000000-0000-0000-0000-000000000000	293	2l7dz5gbc4dg	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-04 07:54:04.234456+00	2026-04-04 07:54:04.234456+00	\N	5144bbc0-670d-41e6-a512-76a62cbc8558
00000000-0000-0000-0000-000000000000	297	pzo62d34vtl3	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-04 08:04:56.448051+00	2026-04-04 08:04:56.448051+00	\N	245f7d1f-825a-4b27-aaf1-09266ae1cd76
00000000-0000-0000-0000-000000000000	179	hcx6a2mai32o	10f4c984-9b5d-46dd-8d98-00573752f50a	t	2026-04-01 14:28:11.687195+00	2026-04-01 15:26:35.179618+00	\N	1b679902-2027-4dca-8828-36b6948665cf
00000000-0000-0000-0000-000000000000	183	2x46ng53bowu	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-01 16:11:25.092636+00	2026-04-01 16:11:25.092636+00	fxxrdhvzndcc	70ae080e-bf8e-415a-91b7-974135faace5
00000000-0000-0000-0000-000000000000	185	zofr4tngnk6n	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-01 16:32:19.068288+00	2026-04-01 16:32:19.068288+00	\N	610b49bb-2d8b-428e-b0d0-cb62ee2e8bc5
00000000-0000-0000-0000-000000000000	189	nh6q3w262o7m	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-04-02 00:04:53.830812+00	2026-04-02 00:04:53.830812+00	qjqrcvkmand4	1b679902-2027-4dca-8828-36b6948665cf
00000000-0000-0000-0000-000000000000	218	5mmds4f6wqho	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-04-03 20:47:05.801207+00	2026-04-03 20:47:05.801207+00	\N	e353cb40-9817-40a3-8128-9f5baa3140e5
00000000-0000-0000-0000-000000000000	219	inxqrvaqhzh4	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-04-03 21:50:14.375581+00	2026-04-03 21:50:14.375581+00	\N	d41d46f9-f562-42ab-8079-ef938e36defa
00000000-0000-0000-0000-000000000000	220	rnweoxncdujf	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-04-03 22:05:30.845856+00	2026-04-03 22:05:30.845856+00	\N	832a7ffd-b1c0-42a9-9efc-7178db1a8f09
00000000-0000-0000-0000-000000000000	319	34qts4aafjah	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-04 10:34:11.894435+00	2026-04-04 10:34:11.894435+00	\N	0b9a2491-e8cc-4d38-8de7-228e4108e13e
00000000-0000-0000-0000-000000000000	321	mkofo3qta6wi	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-04 19:26:56.42329+00	2026-04-04 19:26:56.42329+00	rzzx43egrhta	1b2e33f2-b47e-45f1-8801-fe87aa7d6460
00000000-0000-0000-0000-000000000000	324	usm6x7dclb62	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 01:19:30.03634+00	2026-04-05 01:19:30.03634+00	\N	ca1db5ac-9f81-4a92-9541-ecb974715bd0
00000000-0000-0000-0000-000000000000	326	q72syosd4umm	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 02:56:14.102785+00	2026-04-05 02:56:14.102785+00	\N	e00f1709-000a-463e-9630-8d01e977d82e
00000000-0000-0000-0000-000000000000	328	ucvmdwyzi5q7	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 04:50:51.86022+00	2026-04-05 04:50:51.86022+00	\N	23ccc957-d9b5-4a80-8883-53655d3082e7
00000000-0000-0000-0000-000000000000	330	sl73iafmrvzy	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 04:56:36.651947+00	2026-04-05 04:56:36.651947+00	\N	a78df8c5-5bb7-4ddb-a769-8f24c9947986
00000000-0000-0000-0000-000000000000	331	xjf7mvo3nt6m	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 05:23:28.199477+00	2026-04-05 05:23:28.199477+00	\N	8574d4b8-dcaf-4162-8f5e-dcc50938f20d
00000000-0000-0000-0000-000000000000	332	3xo53puyhiag	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 05:32:57.104475+00	2026-04-05 05:32:57.104475+00	\N	aaf5c08d-1737-46df-9073-20421a87b8dd
00000000-0000-0000-0000-000000000000	334	wgexyyxehgoh	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 06:42:46.675465+00	2026-04-05 06:42:46.675465+00	\N	eff9ad30-a9b0-4016-ae83-767b064a7067
00000000-0000-0000-0000-000000000000	335	eqezae7ci7i5	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 06:53:28.096893+00	2026-04-05 06:53:28.096893+00	\N	c41aa3fa-899d-4497-98bc-aaaee6e3af9c
00000000-0000-0000-0000-000000000000	336	cukn2xz44o4o	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 07:31:26.253186+00	2026-04-05 07:31:26.253186+00	\N	7da45766-3b2d-4b59-bd8d-f814a8faa88a
00000000-0000-0000-0000-000000000000	337	rvglbnq4sn3a	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 07:43:54.546077+00	2026-04-05 07:43:54.546077+00	\N	5d198fa3-a8ac-435c-8952-418db7e7400a
00000000-0000-0000-0000-000000000000	338	zrzv2lb2p4th	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 07:45:30.314961+00	2026-04-05 07:45:30.314961+00	\N	3f827437-0fc8-4052-87f2-d78a44271efe
00000000-0000-0000-0000-000000000000	339	xrqfiehncqlx	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 07:47:42.736148+00	2026-04-05 07:47:42.736148+00	\N	b0d4651b-f457-4257-a550-aa8c292efcf3
00000000-0000-0000-0000-000000000000	340	viv66xrlvdng	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 07:48:11.85627+00	2026-04-05 07:48:11.85627+00	\N	b8ab4d11-6742-4d43-a597-6e8f4376656f
00000000-0000-0000-0000-000000000000	134	77ithgu5zbj2	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 04:44:36.451606+00	2026-03-30 04:44:36.451606+00	\N	2784f74c-b2dd-494a-8db7-e5865052f0e3
00000000-0000-0000-0000-000000000000	352	qowdh6rfz6l6	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 09:12:35.770541+00	2026-04-05 09:12:35.770541+00	\N	ea7ba9f4-b502-425e-b8e3-b38f9e7c101f
00000000-0000-0000-0000-000000000000	136	yfdj7rjw6acg	9a54cb41-ee7d-417e-9563-9fb95a35c29c	t	2026-03-30 14:21:19.855633+00	2026-03-30 15:19:41.754161+00	\N	3d4f2bff-d3a0-4036-8fa7-3c02c9cf5d9d
00000000-0000-0000-0000-000000000000	138	ufm6agesoedz	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 16:33:43.72411+00	2026-03-30 16:33:43.72411+00	\N	188e2d63-486d-4fa4-9f6f-c08d676e7a07
00000000-0000-0000-0000-000000000000	85	safqjwnenvd4	b7ea8833-6fff-4302-8d1b-4424676cb299	f	2026-03-28 08:33:56.244139+00	2026-03-28 08:33:56.244139+00	\N	105726ea-31d8-4cad-ac45-143cce6df58d
00000000-0000-0000-0000-000000000000	140	wb5mdpx37la5	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 17:46:39.066213+00	2026-03-30 17:46:39.066213+00	\N	9e6f6203-a900-4c39-9ace-3b2464c6f912
00000000-0000-0000-0000-000000000000	142	65tuadukxtu7	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 17:50:29.41975+00	2026-03-30 17:50:29.41975+00	\N	cc103ed1-c431-45b8-9778-e86609069bbb
00000000-0000-0000-0000-000000000000	86	qwby2iqfxpjb	b7ea8833-6fff-4302-8d1b-4424676cb299	f	2026-03-28 08:34:38.215648+00	2026-03-28 08:34:38.215648+00	\N	2389047d-42c5-484b-afdf-485a584b99ed
00000000-0000-0000-0000-000000000000	144	mjlr2yvhyrfg	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 18:21:03.778046+00	2026-03-30 18:21:03.778046+00	\N	17857740-6c3a-47e4-922a-64eed22f2f5e
00000000-0000-0000-0000-000000000000	146	qaxmlenvlgao	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-30 23:02:53.017615+00	2026-03-30 23:02:53.017615+00	\N	5c9b733c-38d0-4a8d-b6b8-be693b23fef9
00000000-0000-0000-0000-000000000000	357	gxoshdffovaq	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 15:54:11.706697+00	2026-04-05 15:54:11.706697+00	\N	34412fcc-c2ce-4f07-ae6c-7e77b04b0a7f
00000000-0000-0000-0000-000000000000	151	h5f5iacy4zmj	10f4c984-9b5d-46dd-8d98-00573752f50a	t	2026-03-31 16:43:40.683698+00	2026-03-31 17:42:01.565837+00	\N	e79494cf-3acc-4de2-9f2c-cb34d60e456b
00000000-0000-0000-0000-000000000000	153	b2no2nu64chs	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-31 17:47:15.365813+00	2026-03-31 17:47:15.365813+00	\N	493a5611-d789-4195-8a4b-7eb20b413d69
00000000-0000-0000-0000-000000000000	91	6vagwgn7hvyn	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 09:21:47.286292+00	2026-03-28 09:21:47.286292+00	\N	69d65f9e-c13e-45c7-bad4-c3060de1924e
00000000-0000-0000-0000-000000000000	155	m5tbstlnfsve	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-31 18:49:23.55059+00	2026-03-31 18:49:23.55059+00	\N	4503e0f8-7085-4202-9396-fca513ee2737
00000000-0000-0000-0000-000000000000	360	ucdlzztg3axd	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 16:30:40.322163+00	2026-04-05 16:30:40.322163+00	\N	5f8aebcc-d8d7-447a-97d1-8ae357a6d843
00000000-0000-0000-0000-000000000000	363	7yszwshu3yxc	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 16:41:10.106474+00	2026-04-05 16:41:10.106474+00	\N	bae03e61-1bd5-4fad-a630-ddd0f7fe0002
00000000-0000-0000-0000-000000000000	365	prjiq6plajzt	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 16:59:31.180805+00	2026-04-05 16:59:31.180805+00	\N	4c5f914a-622c-40a9-8f53-4467164dd7f2
00000000-0000-0000-0000-000000000000	333	4nehqoptrtfz	10f4c984-9b5d-46dd-8d98-00573752f50a	t	2026-04-05 05:48:03.178931+00	2026-04-05 20:11:36.171698+00	\N	e7682a5e-30e8-4137-9902-c90791d54a6f
00000000-0000-0000-0000-000000000000	170	mmvvwxguwnfd	353b8afb-61a8-4233-96dd-480e99a0ff83	f	2026-04-01 11:17:01.826222+00	2026-04-01 11:17:01.826222+00	\N	cdc76db6-4642-4d17-95bf-db04af47dd35
00000000-0000-0000-0000-000000000000	72	q3yoitp5oasg	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-27 16:58:06.947099+00	2026-03-27 16:58:06.947099+00	\N	31bf9fe8-e7a0-48dc-879f-8fc3f35e414c
00000000-0000-0000-0000-000000000000	73	ptsjwxwrxwi5	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-27 16:58:45.984062+00	2026-03-27 16:58:45.984062+00	\N	83ec774a-ba4c-4408-bb58-b85fa25cd59a
00000000-0000-0000-0000-000000000000	74	nlzsvx2oumex	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-03-27 17:24:53.413874+00	2026-03-27 17:24:53.413874+00	\N	18deef48-5bff-46cb-a7da-8f0004979157
00000000-0000-0000-0000-000000000000	178	wcqpuhk3xluz	ca38c166-41e5-4f9d-b14a-caa71d08be01	t	2026-04-01 14:14:40.85895+00	2026-04-01 15:12:54.165932+00	\N	70ae080e-bf8e-415a-91b7-974135faace5
00000000-0000-0000-0000-000000000000	79	hre7yhdkysp3	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-03-28 08:05:30.7168+00	2026-03-28 08:05:30.7168+00	\N	6a15d8e8-aaea-4a29-8d03-749bbdfe9ad1
00000000-0000-0000-0000-000000000000	80	7axtjgbhnjbu	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-03-28 08:05:49.587516+00	2026-03-28 08:05:49.587516+00	\N	c19c862e-45f3-4ff6-b760-6ad50934eb53
00000000-0000-0000-0000-000000000000	81	2rmn4jyhe3xi	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-03-28 08:08:38.230185+00	2026-03-28 08:08:38.230185+00	\N	3a784b14-6d9e-4cb7-b551-b6bb8572e4b4
00000000-0000-0000-0000-000000000000	82	kkhzpadf7a27	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-03-28 08:22:14.410176+00	2026-03-28 08:22:14.410176+00	\N	e6888758-df45-4c67-8b9e-104c019531c2
00000000-0000-0000-0000-000000000000	83	ejpxzlnxqzi7	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-03-28 08:23:44.58878+00	2026-03-28 08:23:44.58878+00	\N	a5e9ac54-f82f-4310-8d2c-b78f9f4dc77e
00000000-0000-0000-0000-000000000000	180	fxxrdhvzndcc	ca38c166-41e5-4f9d-b14a-caa71d08be01	t	2026-04-01 15:12:54.203628+00	2026-04-01 16:11:25.076528+00	wcqpuhk3xluz	70ae080e-bf8e-415a-91b7-974135faace5
00000000-0000-0000-0000-000000000000	182	vir3a7iohygz	10f4c984-9b5d-46dd-8d98-00573752f50a	t	2026-04-01 15:26:35.191334+00	2026-04-01 16:24:36.316082+00	hcx6a2mai32o	1b679902-2027-4dca-8828-36b6948665cf
00000000-0000-0000-0000-000000000000	108	z72dnbjedzqh	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 12:59:34.00452+00	2026-03-28 12:59:34.00452+00	jnjr4fadfkmw	3d329806-9118-42b4-9c8f-ef0e302f0cc8
00000000-0000-0000-0000-000000000000	110	nxlcycalpb5l	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 13:34:52.109779+00	2026-03-28 13:34:52.109779+00	\N	05dd48ae-bdc0-44c6-820f-e83d2fe6ca22
00000000-0000-0000-0000-000000000000	184	vpfdg54algdk	10f4c984-9b5d-46dd-8d98-00573752f50a	t	2026-04-01 16:24:36.328184+00	2026-04-01 20:05:17.42434+00	vir3a7iohygz	1b679902-2027-4dca-8828-36b6948665cf
00000000-0000-0000-0000-000000000000	188	qjqrcvkmand4	10f4c984-9b5d-46dd-8d98-00573752f50a	t	2026-04-01 20:05:17.446788+00	2026-04-02 00:04:53.810163+00	vpfdg54algdk	1b679902-2027-4dca-8828-36b6948665cf
00000000-0000-0000-0000-000000000000	120	vp2khldrgs2q	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 15:54:53.500131+00	2026-03-28 15:54:53.500131+00	\N	1d69f845-b46e-44ae-9612-c79c6e172ed4
00000000-0000-0000-0000-000000000000	122	cwgd7dataaqy	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-03-28 16:48:02.250353+00	2026-03-28 16:48:02.250353+00	\N	abf8dff8-a1d4-4e4a-a5db-0ff8b92ad244
00000000-0000-0000-0000-000000000000	124	yc62htylwyud	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 17:07:58.325984+00	2026-03-28 17:07:58.325984+00	\N	cea9febb-5890-4f81-a6e8-718a8292501d
00000000-0000-0000-0000-000000000000	126	ajdpa42i6fcl	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 17:13:15.417585+00	2026-03-28 17:13:15.417585+00	\N	e44291d0-c38c-4971-901d-a3e213900a36
00000000-0000-0000-0000-000000000000	128	kwxpofkk4gxk	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 17:37:23.737149+00	2026-03-28 17:37:23.737149+00	\N	b973abc9-79ac-49d8-b5d3-eab9b6e439f6
00000000-0000-0000-0000-000000000000	130	unszftglarvf	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-28 18:16:28.113918+00	2026-03-28 18:16:28.113918+00	\N	daddfdd9-0ac8-4af0-93c3-ac7b638c7c30
00000000-0000-0000-0000-000000000000	132	xdr5ychrkuxl	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-03-30 04:16:59.307548+00	2026-03-30 04:16:59.307548+00	4h4sry7fxsor	fd1ea4aa-e0d9-4fee-932c-83032fa4290d
00000000-0000-0000-0000-000000000000	205	vly4grt2q27f	f1723551-793e-40ee-9996-853d1cfc04cc	f	2026-04-02 04:26:26.847621+00	2026-04-02 04:26:26.847621+00	\N	8af7e34c-9845-47e3-b62d-b4239885c0a5
00000000-0000-0000-0000-000000000000	207	kviqf4vadgpr	f1723551-793e-40ee-9996-853d1cfc04cc	f	2026-04-03 17:04:37.266061+00	2026-04-03 17:04:37.266061+00	\N	20f2ddcf-73a6-46d8-886b-73e5c6d7e84b
00000000-0000-0000-0000-000000000000	210	tusk2bveodxs	f1723551-793e-40ee-9996-853d1cfc04cc	f	2026-04-03 17:12:04.710911+00	2026-04-03 17:12:04.710911+00	\N	5d072393-1c6a-4a2d-a590-9132554e1471
00000000-0000-0000-0000-000000000000	211	lleq54zsuv77	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-03 17:12:19.151511+00	2026-04-03 17:12:19.151511+00	\N	b3dfc00b-a88f-4255-908c-1d5db383852e
00000000-0000-0000-0000-000000000000	320	rzzx43egrhta	c6ad1e17-f6f1-4229-8580-b00e595c3050	t	2026-04-04 18:28:29.878382+00	2026-04-04 19:26:56.397512+00	\N	1b2e33f2-b47e-45f1-8801-fe87aa7d6460
00000000-0000-0000-0000-000000000000	323	m2jnmug7txgx	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 01:01:57.040612+00	2026-04-05 01:01:57.040612+00	\N	4514e11f-b5ed-45bd-9900-951aaa4f021f
00000000-0000-0000-0000-000000000000	325	yjsuspjrrtb2	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 02:35:29.372793+00	2026-04-05 02:35:29.372793+00	\N	040b608f-a0b9-454f-a567-b7e3c8b2b94b
00000000-0000-0000-0000-000000000000	327	eiqmnu44hnkq	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 04:45:03.442889+00	2026-04-05 04:45:03.442889+00	\N	695d41ea-2d9e-45d4-b583-3051112c8a72
00000000-0000-0000-0000-000000000000	329	gqzhvci4jlrq	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 04:56:27.663929+00	2026-04-05 04:56:27.663929+00	\N	ee15d3b8-509c-4555-b63c-947fe183de06
00000000-0000-0000-0000-000000000000	341	bxfadjoohgh7	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 07:48:33.826354+00	2026-04-05 07:48:33.826354+00	\N	0422fc81-6cec-46a3-bd08-219cf123b011
00000000-0000-0000-0000-000000000000	342	5mwk6cg3iivn	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 07:52:37.38766+00	2026-04-05 07:52:37.38766+00	\N	6b914ea3-faf7-4939-883f-41f74e4fd509
00000000-0000-0000-0000-000000000000	343	27vodndfpuso	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 08:06:24.211136+00	2026-04-05 08:06:24.211136+00	\N	9451dd9d-e3a3-41b0-93f7-bd66404b9c9b
00000000-0000-0000-0000-000000000000	344	p3lrvnfg6qhm	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 08:06:24.551166+00	2026-04-05 08:06:24.551166+00	\N	73fd57d5-6a76-4d95-b8ea-5102779f9cd2
00000000-0000-0000-0000-000000000000	346	bhr5b7incnzv	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 08:59:11.446576+00	2026-04-05 08:59:11.446576+00	\N	e8e90756-c4d4-4dff-b940-a903c24a65b4
00000000-0000-0000-0000-000000000000	347	xh5cof2thjed	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 09:00:43.05557+00	2026-04-05 09:00:43.05557+00	\N	e927ba34-f626-4ce0-a5ce-3de73935a0e5
00000000-0000-0000-0000-000000000000	358	4syy7w7wruwj	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 16:12:49.192347+00	2026-04-05 16:12:49.192347+00	\N	4cdd848a-8208-4fe5-a57b-bfbf61174421
00000000-0000-0000-0000-000000000000	359	dtmzguebccb6	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 16:13:08.581378+00	2026-04-05 16:13:08.581378+00	\N	f6c62ca2-d98f-4b7d-95b0-333b2b3b90b9
00000000-0000-0000-0000-000000000000	361	ndi6uu3ejqoc	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 16:31:53.076521+00	2026-04-05 16:31:53.076521+00	\N	77a76653-2f24-4da2-aa64-42fab3198bc2
00000000-0000-0000-0000-000000000000	362	c7gkcsrzs2ar	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 16:32:41.439529+00	2026-04-05 16:32:41.439529+00	\N	11bcd35c-fdd4-4f7b-b97a-8e019e8f8de7
00000000-0000-0000-0000-000000000000	364	iys6jjjtnbbx	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-05 16:42:38.195492+00	2026-04-05 16:42:38.195492+00	\N	0d4ab3bb-c2ce-4410-92b2-117dc3e92920
00000000-0000-0000-0000-000000000000	366	a25nsxwr4hp2	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-05 17:00:38.699235+00	2026-04-05 17:00:38.699235+00	\N	43cb828c-d78a-42d9-bcc7-484c82e4e3f6
00000000-0000-0000-0000-000000000000	367	g2zkk5dfvlav	10f4c984-9b5d-46dd-8d98-00573752f50a	t	2026-04-05 20:11:36.195798+00	2026-04-06 00:21:06.961698+00	4nehqoptrtfz	e7682a5e-30e8-4137-9902-c90791d54a6f
00000000-0000-0000-0000-000000000000	368	s5tgkqwwfghx	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-04-06 00:21:06.979695+00	2026-04-06 00:21:06.979695+00	g2zkk5dfvlav	e7682a5e-30e8-4137-9902-c90791d54a6f
00000000-0000-0000-0000-000000000000	369	xyb7g3krjyrc	c48465fb-520d-445f-b8cc-e8f08c1b8a38	f	2026-04-06 03:41:55.571437+00	2026-04-06 03:41:55.571437+00	\N	0119cc33-ac64-4932-8a72-be982dbdad88
00000000-0000-0000-0000-000000000000	370	qsfwqbhyqniv	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-07 17:40:58.330375+00	2026-04-07 17:40:58.330375+00	\N	ccd0f18d-4c82-4856-869e-50c23b0d8ef1
00000000-0000-0000-0000-000000000000	371	kb3jtcaa55o5	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-07 17:48:56.725736+00	2026-04-07 17:48:56.725736+00	\N	042c59a5-d1bd-4d56-9da7-1e0bc8e1c5a5
00000000-0000-0000-0000-000000000000	372	qtrvqzsa24du	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-07 17:49:04.719296+00	2026-04-07 17:49:04.719296+00	\N	5922f71b-9413-47d2-ade1-0801adeb1df2
00000000-0000-0000-0000-000000000000	373	u454q3ybpugx	c48465fb-520d-445f-b8cc-e8f08c1b8a38	f	2026-04-08 00:12:05.263576+00	2026-04-08 00:12:05.263576+00	\N	3e28e52f-9858-4465-9ceb-fa38bbc9f384
00000000-0000-0000-0000-000000000000	375	4aymt5prbdhw	c48465fb-520d-445f-b8cc-e8f08c1b8a38	f	2026-04-08 02:21:18.933099+00	2026-04-08 02:21:18.933099+00	\N	115b8691-1176-4e5e-a613-97fd732a736b
00000000-0000-0000-0000-000000000000	386	ykdv3e4os2jn	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-08 04:22:55.993645+00	2026-04-08 04:22:55.993645+00	\N	827fdd99-5450-4335-bd71-83e0ff828220
00000000-0000-0000-0000-000000000000	387	erdbyxez7fel	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-08 04:24:23.163762+00	2026-04-08 04:24:23.163762+00	\N	3d68bfa9-c0dd-4257-bc91-97fb80c177db
00000000-0000-0000-0000-000000000000	398	iti6txlp4dt5	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-08 05:31:18.578052+00	2026-04-08 05:31:18.578052+00	\N	66c55acf-1e3b-497b-af03-74f823201120
00000000-0000-0000-0000-000000000000	399	cmqrbffjauls	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-08 05:43:19.839496+00	2026-04-08 05:43:19.839496+00	\N	991ebdc1-fc1b-4ded-ba49-6a05e4fff500
00000000-0000-0000-0000-000000000000	400	gk4lr46a5kko	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-08 06:17:51.523294+00	2026-04-08 06:17:51.523294+00	\N	3173ad85-deb3-4d0c-bcaa-fd86c2d2461b
00000000-0000-0000-0000-000000000000	408	jesykffom54f	d2b3704a-f14e-47ad-a8e4-8a7fa617f32a	f	2026-04-08 15:11:23.199379+00	2026-04-08 15:11:23.199379+00	\N	6d751c3e-a94f-4fb1-81ac-eb4ec322d6e4
00000000-0000-0000-0000-000000000000	411	ldx3ze67kiek	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-08 15:18:12.882667+00	2026-04-08 15:18:12.882667+00	\N	e1a3942d-5af2-4133-8c1c-04f6efee55bf
00000000-0000-0000-0000-000000000000	412	pdey5fbahudv	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-08 15:18:38.167745+00	2026-04-08 15:18:38.167745+00	\N	f8f351eb-69cf-420d-b4ed-0c17d754a664
00000000-0000-0000-0000-000000000000	416	stfk2y65laet	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 17:46:37.884943+00	2026-04-08 17:46:37.884943+00	\N	9083959f-697d-446e-bf34-1fd18a6056bf
00000000-0000-0000-0000-000000000000	417	5xrwqk6m5kd5	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 17:53:22.418979+00	2026-04-08 17:53:22.418979+00	\N	12db1045-139d-4647-8d4f-62ee0723c70d
00000000-0000-0000-0000-000000000000	418	sxx6bfl67l5z	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 18:04:51.722067+00	2026-04-08 18:04:51.722067+00	\N	cd3f1f3c-8357-441b-9cd6-75042221fd17
00000000-0000-0000-0000-000000000000	419	mmlkugr5wpqo	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 18:09:59.025177+00	2026-04-08 18:09:59.025177+00	\N	ab173c51-525c-4ac8-868f-3dfb4652033c
00000000-0000-0000-0000-000000000000	420	uz3p2ag3owdk	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 18:16:38.251376+00	2026-04-08 18:16:38.251376+00	\N	a2f0a879-6414-41d4-b61f-7aa0c7092a11
00000000-0000-0000-0000-000000000000	421	soh6sngbj7es	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 18:20:22.592715+00	2026-04-08 18:20:22.592715+00	\N	66d6648a-f131-4e63-b9cc-9e20ef0d5017
00000000-0000-0000-0000-000000000000	422	x3kdtc7ig643	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 18:20:48.031808+00	2026-04-08 18:20:48.031808+00	\N	77ea16d6-7933-49a9-8888-d23a182cffd4
00000000-0000-0000-0000-000000000000	423	nxiguwzartvc	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 18:27:28.137548+00	2026-04-08 18:27:28.137548+00	\N	3d7daaa9-9b5f-4395-8b0d-d72f68861551
00000000-0000-0000-0000-000000000000	424	galy547o3ojt	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 18:27:49.95902+00	2026-04-08 18:27:49.95902+00	\N	a3d58d52-785f-4e10-938f-6b4ab220a0bd
00000000-0000-0000-0000-000000000000	425	q2vhg6ysaowm	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 18:33:08.351834+00	2026-04-08 18:33:08.351834+00	\N	230b1049-dbe5-4757-a62b-92e6b5f04c01
00000000-0000-0000-0000-000000000000	426	ehtd7grqclxk	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 18:34:23.744537+00	2026-04-08 18:34:23.744537+00	\N	b27ec1c4-dff1-4e3b-84f1-30bac0703dc6
00000000-0000-0000-0000-000000000000	427	o7yqmjr7layg	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 18:35:06.787818+00	2026-04-08 18:35:06.787818+00	\N	9bed12d3-68b3-4186-8057-681568de7e5c
00000000-0000-0000-0000-000000000000	428	el7n5xyzxivl	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 18:48:14.314483+00	2026-04-08 18:48:14.314483+00	\N	d3814b86-56f1-4008-8d6e-2172fcec553d
00000000-0000-0000-0000-000000000000	429	v24wojf4mzbp	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 18:55:18.06755+00	2026-04-08 18:55:18.06755+00	\N	cc2355ac-f5b4-418d-b290-8980231b2136
00000000-0000-0000-0000-000000000000	430	fj53llxhwzkp	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-08 18:56:36.191463+00	2026-04-08 18:56:36.191463+00	\N	446b0b2a-d1ce-43e3-a911-12e76bc3cfb8
00000000-0000-0000-0000-000000000000	431	tk7gtgss3yd7	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-08 19:04:07.962498+00	2026-04-08 19:04:07.962498+00	\N	45339381-c0d5-4ebc-807c-39bafc3927f3
00000000-0000-0000-0000-000000000000	432	5u4iib3xlqpk	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 03:18:06.557226+00	2026-04-09 03:18:06.557226+00	\N	9ad46c0d-ea02-423d-8e8e-0cbc4d84c7c4
00000000-0000-0000-0000-000000000000	433	ijf5wfxazkla	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 03:40:02.282257+00	2026-04-09 03:40:02.282257+00	\N	605136e8-7c28-4d57-a4fb-7ea0e7c1ffff
00000000-0000-0000-0000-000000000000	434	hovfrqjubvju	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 03:48:09.065233+00	2026-04-09 03:48:09.065233+00	\N	6f76e629-f577-4f70-8335-08b21d8337b8
00000000-0000-0000-0000-000000000000	437	c3b4jjowjfxz	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 04:20:48.578754+00	2026-04-09 04:20:48.578754+00	\N	b87ac33e-6110-44a1-8f93-87dfd314302f
00000000-0000-0000-0000-000000000000	438	5ro7d4gyt2r5	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 04:24:26.577243+00	2026-04-09 04:24:26.577243+00	\N	860db37a-f6f9-4ad6-84eb-106ad60c40b0
00000000-0000-0000-0000-000000000000	439	honoeercxguv	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 04:28:21.433595+00	2026-04-09 04:28:21.433595+00	\N	41c91e36-0a9c-4a7a-81c6-e8902da0731c
00000000-0000-0000-0000-000000000000	440	rykd7hx2rwz5	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 10:52:05.818368+00	2026-04-09 10:52:05.818368+00	\N	4be11cae-afff-4e54-9aaa-5e8f49fe3d15
00000000-0000-0000-0000-000000000000	441	tw3czt3hfbem	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 10:52:44.557329+00	2026-04-09 10:52:44.557329+00	\N	4a8bade7-41be-488d-a279-535f4115d7ef
00000000-0000-0000-0000-000000000000	442	biyjifcyy4cb	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 11:05:34.132133+00	2026-04-09 11:05:34.132133+00	\N	38ff7050-ac73-4245-ada6-dab762adec7a
00000000-0000-0000-0000-000000000000	443	p32zpm6xodqd	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 11:20:51.096019+00	2026-04-09 11:20:51.096019+00	\N	8e8cc93a-d1da-4c90-8f18-ac7d7d3bb16c
00000000-0000-0000-0000-000000000000	444	rfgsipb5yvy5	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 11:41:12.747692+00	2026-04-09 11:41:12.747692+00	\N	672f35d0-a631-438d-b49e-e556dd03e89b
00000000-0000-0000-0000-000000000000	445	dzllxb7a7fgb	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 11:45:27.267254+00	2026-04-09 11:45:27.267254+00	\N	a2caeb8c-5f67-47a9-aaaa-2e72a56436bf
00000000-0000-0000-0000-000000000000	446	ylh3wior3vtb	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 12:21:11.758721+00	2026-04-09 12:21:11.758721+00	\N	c7a9483f-8aff-42e4-b367-d45dfbc5101e
00000000-0000-0000-0000-000000000000	447	ytymbq7ih2qf	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 12:35:34.564442+00	2026-04-09 12:35:34.564442+00	\N	1a96ef1e-004a-4844-8f95-3c6b302752ce
00000000-0000-0000-0000-000000000000	448	mxsqk2rjkrhs	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 12:49:21.052071+00	2026-04-09 12:49:21.052071+00	\N	3f8d4d3a-2fd0-4667-940d-2234e1d1428b
00000000-0000-0000-0000-000000000000	451	akjkznmn6txk	353b8afb-61a8-4233-96dd-480e99a0ff83	f	2026-04-09 14:31:38.608214+00	2026-04-09 14:31:38.608214+00	\N	dfdcc693-06c1-42ab-9f93-dfd24cd0a9ec
00000000-0000-0000-0000-000000000000	452	xexz7net5awc	353b8afb-61a8-4233-96dd-480e99a0ff83	f	2026-04-09 14:34:18.683148+00	2026-04-09 14:34:18.683148+00	\N	94977f2c-aef1-460f-8533-69fd63f52b84
00000000-0000-0000-0000-000000000000	460	43dunoro2gn3	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 14:40:33.551119+00	2026-04-09 14:40:33.551119+00	\N	4939619b-9c09-43fc-8df6-764f2e026168
00000000-0000-0000-0000-000000000000	461	d62roowppknw	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 14:51:29.040981+00	2026-04-09 14:51:29.040981+00	\N	d403b595-4031-4419-bbfd-43edcc9e0fc5
00000000-0000-0000-0000-000000000000	462	op3riabyziry	c7910199-028e-4d56-b029-aeb553d977d0	f	2026-04-09 14:52:35.291486+00	2026-04-09 14:52:35.291486+00	\N	cf2bcd4c-230d-469e-9e66-df376be5e63e
00000000-0000-0000-0000-000000000000	463	vy4loyfcl2xq	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 15:07:02.973349+00	2026-04-09 15:07:02.973349+00	\N	94958ed7-5fb8-4ade-b0ed-8b368f032bca
00000000-0000-0000-0000-000000000000	464	w6lsx67jh75y	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 15:07:41.278379+00	2026-04-09 15:07:41.278379+00	\N	ebb3fd0f-34c2-4ce0-833a-218b5b955f7d
00000000-0000-0000-0000-000000000000	465	tc5d52j54lar	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 15:14:19.433615+00	2026-04-09 15:14:19.433615+00	\N	1a6182e0-ea08-4f13-842d-b59de3178c2e
00000000-0000-0000-0000-000000000000	466	eykjrqbpbnqs	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 15:17:00.503974+00	2026-04-09 15:17:00.503974+00	\N	18c1ab85-14a6-4882-aaa9-c921e07b442c
00000000-0000-0000-0000-000000000000	467	ievhsgwfoyal	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 15:18:26.919123+00	2026-04-09 15:18:26.919123+00	\N	78c5c1dc-e31f-4873-b197-292b416aa21a
00000000-0000-0000-0000-000000000000	468	oxig2ion4nst	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 15:33:11.577555+00	2026-04-09 15:33:11.577555+00	\N	41fdc79f-85f7-4d1e-8cfc-bc6fe90253f0
00000000-0000-0000-0000-000000000000	469	alsu6uh7gdpo	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 15:35:12.277262+00	2026-04-09 15:35:12.277262+00	\N	49ca9e9e-15e1-4185-a711-165d53d07cb9
00000000-0000-0000-0000-000000000000	470	3x53mojyoq34	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 15:51:40.27856+00	2026-04-09 15:51:40.27856+00	\N	fa8e3245-62bd-45e9-8dad-3686a991a5dc
00000000-0000-0000-0000-000000000000	471	6wsc3njduhlw	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	f	2026-04-09 16:00:15.638497+00	2026-04-09 16:00:15.638497+00	\N	7d86e62f-ea74-4e27-86cc-57c137dd4b2f
00000000-0000-0000-0000-000000000000	472	mrmkjmypwexc	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-09 16:00:58.572692+00	2026-04-09 16:00:58.572692+00	\N	4102ed6f-80a4-41c0-9883-5389550ffd05
00000000-0000-0000-0000-000000000000	473	xq6gnqo5xuwn	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-09 21:17:36.072094+00	2026-04-09 21:17:36.072094+00	\N	f1479da9-0b38-4cc9-b725-a4a49aa1b19e
00000000-0000-0000-0000-000000000000	474	neuqjedqolq3	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-09 21:17:36.346651+00	2026-04-09 21:17:36.346651+00	\N	852e2731-4a26-48b6-9b65-c7ee6cbfc807
00000000-0000-0000-0000-000000000000	475	i3y2nou5a2fe	10f4c984-9b5d-46dd-8d98-00573752f50a	f	2026-04-09 21:42:01.418108+00	2026-04-09 21:42:01.418108+00	\N	b6f91aee-d8ce-4f29-a8f4-ff83f50f34f1
00000000-0000-0000-0000-000000000000	476	ns7pvywwh7n5	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-09 21:42:43.157623+00	2026-04-09 21:42:43.157623+00	\N	4d6c18a9-355d-454e-8ef4-c59d8146fd5b
00000000-0000-0000-0000-000000000000	477	5ileykl6adqc	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-09 22:19:32.635389+00	2026-04-09 22:19:32.635389+00	\N	90c9b7b8-c533-4be5-86c9-77e2a42884fd
00000000-0000-0000-0000-000000000000	478	cnofruffkpad	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-09 22:19:32.764928+00	2026-04-09 22:19:32.764928+00	\N	853af437-1271-404f-b04a-3a569364e01c
00000000-0000-0000-0000-000000000000	479	bbi6xgibgxj6	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-10 05:09:23.183522+00	2026-04-10 05:09:23.183522+00	\N	7c6fc506-745b-4107-a054-8a804f58c135
00000000-0000-0000-0000-000000000000	480	b3gv5j5yluw7	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 05:19:08.660297+00	2026-04-10 05:19:08.660297+00	\N	b151bf43-e4eb-440c-8117-c319eadef5bc
00000000-0000-0000-0000-000000000000	481	h2o7ttyocjfb	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 08:27:09.326013+00	2026-04-10 08:27:09.326013+00	\N	107c3c53-4020-4707-89da-783b783a238c
00000000-0000-0000-0000-000000000000	482	aansiymteeru	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-10 09:01:32.809254+00	2026-04-10 09:01:32.809254+00	\N	730795c6-6e10-4b42-8bae-acfebe488c23
00000000-0000-0000-0000-000000000000	483	zbpve7rttxfr	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-10 09:04:53.572387+00	2026-04-10 09:04:53.572387+00	\N	eeb8bb05-c0ee-4c9d-9869-8ecee23b9dbd
00000000-0000-0000-0000-000000000000	484	35dvcrd22gt4	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 09:05:43.486935+00	2026-04-10 09:05:43.486935+00	\N	c412a67b-c3e5-49f2-8148-e325d54a904c
00000000-0000-0000-0000-000000000000	485	uiyulv5y55f3	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-10 09:18:31.178184+00	2026-04-10 09:18:31.178184+00	\N	e39d804d-3d19-403a-bc55-9c5556992cfd
00000000-0000-0000-0000-000000000000	486	mgbcymnp2hou	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 10:11:18.013475+00	2026-04-10 10:11:18.013475+00	\N	895454fa-5370-4cf4-99dc-9620ed02e563
00000000-0000-0000-0000-000000000000	487	opraodpj3wt7	353b8afb-61a8-4233-96dd-480e99a0ff83	f	2026-04-10 14:41:21.827849+00	2026-04-10 14:41:21.827849+00	\N	b13e9062-37f2-4094-aa75-3b54cea9968c
00000000-0000-0000-0000-000000000000	488	tzcki2rgmyfe	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 14:42:44.596065+00	2026-04-10 14:42:44.596065+00	\N	965edad2-085d-4506-940c-d3d94f09fcb5
00000000-0000-0000-0000-000000000000	489	vwlfo6lz5oyz	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 15:00:55.781436+00	2026-04-10 15:00:55.781436+00	\N	4dd03a28-6c75-4978-ba53-907a795c00df
00000000-0000-0000-0000-000000000000	490	b6ekitjosie4	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 15:48:56.527235+00	2026-04-10 15:48:56.527235+00	\N	efb1fb1a-e0bc-4b43-99c5-75a98dc8b127
00000000-0000-0000-0000-000000000000	491	enfeqck6jzb7	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 15:52:41.304223+00	2026-04-10 15:52:41.304223+00	\N	b3b46df2-09ee-455d-82d0-2632025ffc0f
00000000-0000-0000-0000-000000000000	492	3i3d52bawasb	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:12:41.842375+00	2026-04-10 16:12:41.842375+00	\N	0ebde23d-6f72-4865-b17f-f6a3a9e7be8a
00000000-0000-0000-0000-000000000000	493	gxlahe7uxwnj	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:13:02.809219+00	2026-04-10 16:13:02.809219+00	\N	a0688797-88ee-4a28-a749-30bf52f41e4d
00000000-0000-0000-0000-000000000000	494	5wps3o5lz4yg	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:13:20.89829+00	2026-04-10 16:13:20.89829+00	\N	7c6b9d36-52cb-4f22-b7ba-6906ab2bb285
00000000-0000-0000-0000-000000000000	495	scalqaogqtwv	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:14:20.871064+00	2026-04-10 16:14:20.871064+00	\N	7b15ea91-79c6-4f0b-b8c5-3e622813f410
00000000-0000-0000-0000-000000000000	496	hapd6n762p3e	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:14:53.206566+00	2026-04-10 16:14:53.206566+00	\N	e516d52e-2a50-4959-870e-53cafefafffa
00000000-0000-0000-0000-000000000000	497	cnwtu6erl5bm	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:29:47.676962+00	2026-04-10 16:29:47.676962+00	\N	15dfe990-d8e3-4c76-9fb7-29878ea148f9
00000000-0000-0000-0000-000000000000	498	k6qcjkeoa5pm	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:30:26.381835+00	2026-04-10 16:30:26.381835+00	\N	7e9ebbe9-868d-40d0-b2fb-ed693bc4ea0e
00000000-0000-0000-0000-000000000000	499	4xfpa7qtactg	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:30:47.115507+00	2026-04-10 16:30:47.115507+00	\N	5256115a-b313-4f00-abde-d25df23916e7
00000000-0000-0000-0000-000000000000	500	td3iney6xn5f	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:31:17.563641+00	2026-04-10 16:31:17.563641+00	\N	202e2e02-7f0d-4e66-9bb1-849605e0b4d8
00000000-0000-0000-0000-000000000000	501	decusz3fdimh	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:32:00.248493+00	2026-04-10 16:32:00.248493+00	\N	846000e9-fa3c-4fb8-83b5-ae8efcc5124f
00000000-0000-0000-0000-000000000000	502	rnfmycjdbkcm	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:35:43.062839+00	2026-04-10 16:35:43.062839+00	\N	c68158c0-71d9-40a4-a7b8-d3c5e0110fb1
00000000-0000-0000-0000-000000000000	503	zh5rhayarczv	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:42:23.215722+00	2026-04-10 16:42:23.215722+00	\N	292f721d-521a-45c5-8569-954cf514ea96
00000000-0000-0000-0000-000000000000	504	jzo6ytu2sn3r	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:44:33.213909+00	2026-04-10 16:44:33.213909+00	\N	f02014fd-bc95-42cc-8df8-9c13c22fb156
00000000-0000-0000-0000-000000000000	505	pr6xjdbl6wrn	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:46:27.731682+00	2026-04-10 16:46:27.731682+00	\N	086f5fd8-416c-45ae-83c2-a07eb0c86cf4
00000000-0000-0000-0000-000000000000	506	pissttezoxhj	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:47:41.803601+00	2026-04-10 16:47:41.803601+00	\N	632aa82e-758e-44af-b046-9bde3d450fde
00000000-0000-0000-0000-000000000000	507	kq5ctmamnvwy	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:51:12.132816+00	2026-04-10 16:51:12.132816+00	\N	78acba6b-1edd-4f27-a220-da300b9a2d91
00000000-0000-0000-0000-000000000000	508	7k77bhn6dxjo	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:51:15.402153+00	2026-04-10 16:51:15.402153+00	\N	99e1f7bd-6e55-4561-85d4-81884ba7c836
00000000-0000-0000-0000-000000000000	509	iv6yakpc5up4	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:51:34.554869+00	2026-04-10 16:51:34.554869+00	\N	2057b8ca-1005-459e-9ca5-b8ed27ee66ed
00000000-0000-0000-0000-000000000000	510	pis5kmib5cxo	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:53:47.936726+00	2026-04-10 16:53:47.936726+00	\N	12f5ccb1-d502-4b0a-a7de-3e4be0c927a5
00000000-0000-0000-0000-000000000000	511	y4gpv44uqhqv	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:53:51.611013+00	2026-04-10 16:53:51.611013+00	\N	7f3a7968-eb00-4302-850e-ac777a3be059
00000000-0000-0000-0000-000000000000	512	e6gqxnazip5d	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:53:53.38687+00	2026-04-10 16:53:53.38687+00	\N	283ce205-363d-49c6-ae76-1a9cbd877afa
00000000-0000-0000-0000-000000000000	513	ijdzgcygpugo	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:57:31.846371+00	2026-04-10 16:57:31.846371+00	\N	7a1f0588-42c9-4ed7-b0cc-dda4d61c1ac9
00000000-0000-0000-0000-000000000000	514	jdjuirqhb6lf	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 16:58:39.933467+00	2026-04-10 16:58:39.933467+00	\N	b0a04083-52c0-4b16-ac5f-5137c6f35435
00000000-0000-0000-0000-000000000000	515	vajenx7ofnjw	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 17:00:12.529079+00	2026-04-10 17:00:12.529079+00	\N	8adb3c8c-c1df-46d9-9fba-6a702ba63673
00000000-0000-0000-0000-000000000000	516	ttynjlnovlkm	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 17:02:12.81537+00	2026-04-10 17:02:12.81537+00	\N	3c59e60d-0e4e-434a-8d0a-c67568aaa9a2
00000000-0000-0000-0000-000000000000	517	bw7b5emq6j4v	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 17:03:09.24757+00	2026-04-10 17:03:09.24757+00	\N	e0e538cc-501f-4f38-a4df-9ac0934133cd
00000000-0000-0000-0000-000000000000	518	jf64akk6iqrf	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 17:03:24.183137+00	2026-04-10 17:03:24.183137+00	\N	7eb67265-79da-431d-80ed-b72cdfa306ce
00000000-0000-0000-0000-000000000000	519	b5sngu7pcx6s	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 17:05:43.217803+00	2026-04-10 17:05:43.217803+00	\N	2d2eb69b-0c14-456e-af5c-99e14821b375
00000000-0000-0000-0000-000000000000	520	hqp4h5zqv6oe	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 17:06:18.044355+00	2026-04-10 17:06:18.044355+00	\N	3696f9e7-75a6-4c4b-97d0-1e3bd5ac8efb
00000000-0000-0000-0000-000000000000	521	syqcbe2dv6xg	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-10 17:06:20.499347+00	2026-04-10 17:06:20.499347+00	\N	934b3b8f-095f-4735-962e-519807375bbb
00000000-0000-0000-0000-000000000000	522	525tqmtojqmr	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-10 17:07:23.782707+00	2026-04-10 17:07:23.782707+00	\N	0956f384-ebca-4f45-adee-3638724d8068
00000000-0000-0000-0000-000000000000	524	t2jy7uv2l3je	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 07:09:34.392851+00	2026-04-11 07:09:34.392851+00	\N	9508a15a-2a02-4fcc-b1e3-d759774a66b2
00000000-0000-0000-0000-000000000000	523	gybc2o6cds75	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-10 17:10:26.472063+00	2026-04-11 09:03:52.393879+00	\N	f64f8e7b-1e2d-4e27-9616-501eff3d829f
00000000-0000-0000-0000-000000000000	525	isxdbidkk7dy	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-11 09:03:52.411634+00	2026-04-11 09:03:52.411634+00	gybc2o6cds75	f64f8e7b-1e2d-4e27-9616-501eff3d829f
00000000-0000-0000-0000-000000000000	526	zjfca44hdg6q	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-11 09:06:31.403305+00	2026-04-11 09:06:31.403305+00	\N	3db53a0e-f2c4-4617-bbc4-873fbf4b7aa4
00000000-0000-0000-0000-000000000000	527	bzsfgfhkq76k	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-11 09:09:06.670909+00	2026-04-11 09:09:06.670909+00	\N	6692f176-23b7-40d4-8dda-ea5102a0920b
00000000-0000-0000-0000-000000000000	529	rddrdecak3o5	ecebd763-797d-4b9f-beff-63f5044776fc	f	2026-04-11 09:12:12.344638+00	2026-04-11 09:12:12.344638+00	\N	292fd353-81a9-4968-8bda-f3b5f3524d0a
00000000-0000-0000-0000-000000000000	530	dftmpgc2o5wg	ecebd763-797d-4b9f-beff-63f5044776fc	f	2026-04-11 09:16:14.698696+00	2026-04-11 09:16:14.698696+00	\N	2694f434-2df6-4043-97bf-a1a023e92ce9
00000000-0000-0000-0000-000000000000	531	jbidnaicu5f7	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 09:30:06.592659+00	2026-04-11 09:30:06.592659+00	\N	10312692-65ed-46a9-9dc2-f813263e3ef7
00000000-0000-0000-0000-000000000000	532	egp2jxgtauh7	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 09:30:06.592658+00	2026-04-11 09:30:06.592658+00	\N	07e8acc3-cc9f-4757-8c4f-cac1a466718e
00000000-0000-0000-0000-000000000000	533	4owrpmngc5hj	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 09:30:06.773128+00	2026-04-11 09:30:06.773128+00	\N	e60f3551-c451-46e9-aa93-d0f832eca2da
00000000-0000-0000-0000-000000000000	534	5fzftmnmlc7s	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 09:34:34.697896+00	2026-04-11 09:34:34.697896+00	\N	1c28a564-15eb-4e6b-a8e8-c60ebf05bd78
00000000-0000-0000-0000-000000000000	535	o324bxuhllrf	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 10:17:53.780066+00	2026-04-11 10:17:53.780066+00	\N	59ba7115-3cea-42ad-83a0-5846056f418a
00000000-0000-0000-0000-000000000000	528	xpghvws5z2am	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-11 09:09:54.937463+00	2026-04-11 10:33:18.937803+00	\N	003b3965-9930-46ff-8f8c-ab568e15448b
00000000-0000-0000-0000-000000000000	537	txlnp4vzfy5e	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 10:53:52.731017+00	2026-04-11 10:53:52.731017+00	\N	ef245e24-09ef-423b-bf83-385d36e80a52
00000000-0000-0000-0000-000000000000	538	yyc6dutqqw4l	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 11:55:49.269804+00	2026-04-11 11:55:49.269804+00	\N	ad859007-f70b-478c-be93-452ed49c300e
00000000-0000-0000-0000-000000000000	539	euopdvgpshn6	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-11 12:51:38.721387+00	2026-04-11 12:51:38.721387+00	\N	55b9ff8f-6aca-40c1-8e7e-3957bb09be0c
00000000-0000-0000-0000-000000000000	540	shdcirvukrs3	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 13:03:49.790473+00	2026-04-11 13:03:49.790473+00	\N	06b2ceac-a05a-4017-ac6d-ec15345efb19
00000000-0000-0000-0000-000000000000	541	6emm4w3hl7ph	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-11 13:31:08.747811+00	2026-04-11 13:31:08.747811+00	\N	3f14eb88-e31a-4fb2-ae11-3fed723df711
00000000-0000-0000-0000-000000000000	542	jz4iicffncmo	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-11 13:40:01.503049+00	2026-04-11 13:40:01.503049+00	\N	f8d90d41-2fb4-43bd-a606-bd1d33a1c7b4
00000000-0000-0000-0000-000000000000	543	ajvjc2aknkdi	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-11 13:45:14.336374+00	2026-04-11 13:45:14.336374+00	\N	ae92d4d9-9950-4674-a655-106d46666883
00000000-0000-0000-0000-000000000000	544	on7bvorlwkfb	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-11 13:51:22.145737+00	2026-04-11 13:51:22.145737+00	\N	474689b1-275b-49b1-912c-f8e282c019e4
00000000-0000-0000-0000-000000000000	545	rzx6v5a3mxby	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-11 13:56:34.622213+00	2026-04-11 13:56:34.622213+00	\N	520684cd-cd01-47e3-b0cc-c09cfee2d2e8
00000000-0000-0000-0000-000000000000	536	opazhqj5f4kn	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-11 10:33:18.957896+00	2026-04-11 18:10:49.821099+00	xpghvws5z2am	003b3965-9930-46ff-8f8c-ab568e15448b
00000000-0000-0000-0000-000000000000	547	cint27roylgw	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-13 03:48:40.02439+00	2026-04-13 03:48:40.02439+00	\N	e032c352-7dad-4a60-9757-6da3b36f87aa
00000000-0000-0000-0000-000000000000	548	bnt3quky4jig	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-13 11:20:00.963201+00	2026-04-13 11:20:00.963201+00	\N	bac8d93a-d73f-4e62-a520-346f3e3ffea5
00000000-0000-0000-0000-000000000000	549	smawgnteuinf	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-13 13:54:01.864918+00	2026-04-13 13:54:01.864918+00	\N	fda68434-192d-4b25-bbc6-aec0a0b8d19d
00000000-0000-0000-0000-000000000000	550	uusalasku65i	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-13 14:05:30.297693+00	2026-04-13 14:05:30.297693+00	\N	19004738-5909-4cde-8365-ac413d966b6c
00000000-0000-0000-0000-000000000000	551	btgecggdhmbd	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-13 14:06:17.930276+00	2026-04-13 14:06:17.930276+00	\N	9ef6999a-c45f-4bf8-98e6-eb97688030c2
00000000-0000-0000-0000-000000000000	552	m5tocnipjp2g	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-13 14:08:22.420667+00	2026-04-13 14:08:22.420667+00	\N	a2ba4e36-3153-481f-a290-515205ea36bd
00000000-0000-0000-0000-000000000000	553	si33hh5fpdcj	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-14 05:58:00.03906+00	2026-04-14 05:58:00.03906+00	\N	ad494a33-0e49-4e91-839c-d99239a4edf4
00000000-0000-0000-0000-000000000000	554	zorjqxglvsr5	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-14 06:07:16.59805+00	2026-04-14 06:07:16.59805+00	\N	512cc0a7-aa75-4029-a2e7-60c8439acd1b
00000000-0000-0000-0000-000000000000	546	vaxclhnuvmmn	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-11 18:10:49.836733+00	2026-04-14 12:20:54.434645+00	opazhqj5f4kn	003b3965-9930-46ff-8f8c-ab568e15448b
00000000-0000-0000-0000-000000000000	555	ujz35z637b6p	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-14 12:20:54.449545+00	2026-04-14 12:20:54.449545+00	vaxclhnuvmmn	003b3965-9930-46ff-8f8c-ab568e15448b
00000000-0000-0000-0000-000000000000	556	6udjsxoxdxne	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-14 12:36:46.096856+00	2026-04-14 12:36:46.096856+00	\N	301021e1-45b8-4126-80db-0a80c542f57b
00000000-0000-0000-0000-000000000000	557	34nnel3qxtxs	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-14 12:38:55.74091+00	2026-04-14 12:38:55.74091+00	\N	60f0333f-7c0d-49f5-abc4-d79ef8ccd579
00000000-0000-0000-0000-000000000000	558	tminzsr6amyk	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-14 12:39:15.170123+00	2026-04-14 12:39:15.170123+00	\N	2257693b-1afe-4371-8279-b418139efb66
00000000-0000-0000-0000-000000000000	560	5dx7k7l53neh	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-14 12:59:51.875518+00	2026-04-14 12:59:51.875518+00	\N	64c80928-9861-4d0b-8cb7-5840abab701c
00000000-0000-0000-0000-000000000000	559	i4qup72ljsft	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-14 12:43:09.385907+00	2026-04-14 15:19:51.962733+00	\N	7f2c308f-dec8-439f-aad0-3398795292a5
00000000-0000-0000-0000-000000000000	562	frk5nvesbxsp	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-14 15:21:58.495357+00	2026-04-14 15:21:58.495357+00	\N	6603ed2f-67dc-4878-9a39-14611d383f0a
00000000-0000-0000-0000-000000000000	563	dle6xemzdbbe	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-14 15:36:23.454284+00	2026-04-14 15:36:23.454284+00	\N	04077440-648c-46ff-8d3e-91db2d139df6
00000000-0000-0000-0000-000000000000	561	q52g6o32nmxf	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-14 15:19:51.988971+00	2026-04-17 04:03:20.487713+00	i4qup72ljsft	7f2c308f-dec8-439f-aad0-3398795292a5
00000000-0000-0000-0000-000000000000	564	7yuzkvnz7kmw	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-17 04:03:20.509639+00	2026-04-17 05:04:22.586345+00	q52g6o32nmxf	7f2c308f-dec8-439f-aad0-3398795292a5
00000000-0000-0000-0000-000000000000	565	6v4noflopbm6	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-17 05:04:22.613609+00	2026-04-17 06:05:47.777163+00	7yuzkvnz7kmw	7f2c308f-dec8-439f-aad0-3398795292a5
00000000-0000-0000-0000-000000000000	566	wvb47aqipsoy	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-17 06:05:47.79953+00	2026-04-17 08:21:08.176128+00	6v4noflopbm6	7f2c308f-dec8-439f-aad0-3398795292a5
00000000-0000-0000-0000-000000000000	567	f2hvgo5dbz2x	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-17 08:21:08.193708+00	2026-04-17 10:11:36.351352+00	wvb47aqipsoy	7f2c308f-dec8-439f-aad0-3398795292a5
00000000-0000-0000-0000-000000000000	568	t3wgvjyufl2d	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-17 10:11:36.375457+00	2026-04-17 10:11:36.375457+00	f2hvgo5dbz2x	7f2c308f-dec8-439f-aad0-3398795292a5
00000000-0000-0000-0000-000000000000	570	vr6u4nyoekke	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-17 10:13:19.138109+00	2026-04-17 10:13:19.138109+00	\N	134767f5-c810-439c-a555-fab0dd2b6c8f
00000000-0000-0000-0000-000000000000	569	7trk6rlej6zj	b326f22a-02fc-4d99-bce9-6c933113a7a0	t	2026-04-17 10:12:59.079801+00	2026-04-17 11:26:55.211603+00	\N	bbf42b3c-9c63-4b78-9c4c-2329e8fd1c6e
00000000-0000-0000-0000-000000000000	571	2tny4wn27jmg	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-04-17 11:26:55.230888+00	2026-04-17 11:26:55.230888+00	7trk6rlej6zj	bbf42b3c-9c63-4b78-9c4c-2329e8fd1c6e
00000000-0000-0000-0000-000000000000	572	ygbzoert6nvg	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-17 11:27:35.240939+00	2026-04-17 11:27:35.240939+00	\N	c71f1c13-f6ea-4b1f-a4cf-16bc7fa0fd85
00000000-0000-0000-0000-000000000000	574	lblwe42ldkue	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-17 12:06:03.999767+00	2026-04-17 12:06:03.999767+00	\N	bbccc945-19f6-4ffd-8607-3bf905e083e3
00000000-0000-0000-0000-000000000000	577	3jo5sbsm5wzv	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-22 09:06:12.73072+00	2026-04-22 09:06:12.73072+00	\N	15a87b72-219f-4a9f-baac-230af6e36039
00000000-0000-0000-0000-000000000000	578	oiekcwnhv3m2	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:08:58.797234+00	2026-04-23 04:08:58.797234+00	\N	de953c7b-1d6c-4ce7-9781-f9095836ec07
00000000-0000-0000-0000-000000000000	579	xtarxz434qez	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:08:59.074788+00	2026-04-23 04:08:59.074788+00	\N	43c74528-18ca-4519-9aeb-f06147467b38
00000000-0000-0000-0000-000000000000	580	o4s6mfmpiyd3	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:18:30.813837+00	2026-04-23 04:18:30.813837+00	\N	1cad9c4a-87dc-4a5e-ab8e-4c2dec41487b
00000000-0000-0000-0000-000000000000	581	352bsq5eo6wq	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:32:48.771275+00	2026-04-23 04:32:48.771275+00	\N	866d904d-d838-43b8-9947-350497ff3b98
00000000-0000-0000-0000-000000000000	582	y5n274ahbxjo	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:34:21.910064+00	2026-04-23 04:34:21.910064+00	\N	522c813d-8c54-4b54-9809-b13cf8be9826
00000000-0000-0000-0000-000000000000	583	fkkyrndgi2h6	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:36:34.765846+00	2026-04-23 04:36:34.765846+00	\N	ed7b6210-1e89-4b93-9987-c8524f8c2a95
00000000-0000-0000-0000-000000000000	584	ncdia57l3peq	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:47:21.179031+00	2026-04-23 04:47:21.179031+00	\N	142fed24-3fd1-436a-9d89-d0822e88f5a8
00000000-0000-0000-0000-000000000000	585	nqkiy2kvpvxz	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:47:21.23834+00	2026-04-23 04:47:21.23834+00	\N	e3708d9a-b8a4-46ab-8f43-ed369693b9a2
00000000-0000-0000-0000-000000000000	586	ivpu2g4reheg	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:54:58.146171+00	2026-04-23 04:54:58.146171+00	\N	ae64e15d-6d2a-4623-8c09-8c4727b19112
00000000-0000-0000-0000-000000000000	587	gy7tg7bo53fs	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:58:58.996384+00	2026-04-23 04:58:58.996384+00	\N	0d3666d1-4386-464d-b736-6009559e0328
00000000-0000-0000-0000-000000000000	588	jkq7c4eiwudh	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:59:58.351221+00	2026-04-23 04:59:58.351221+00	\N	82ddf6b8-e582-4e63-892d-5c18edcfacce
00000000-0000-0000-0000-000000000000	589	f3sclz5tctvh	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 04:59:58.710364+00	2026-04-23 04:59:58.710364+00	\N	f499267d-7e1d-4916-9edf-9066996bdc27
00000000-0000-0000-0000-000000000000	590	qdyk3enwzh5g	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 05:06:07.957943+00	2026-04-23 05:06:07.957943+00	\N	ec960bb7-ead4-42af-ae91-33c3e05ff0aa
00000000-0000-0000-0000-000000000000	591	oefy4rvdx6xx	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 05:07:54.496851+00	2026-04-23 05:07:54.496851+00	\N	708f8bf8-89ab-448d-95c6-caa12a894a3a
00000000-0000-0000-0000-000000000000	592	sfdudi244lsk	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 05:07:55.068588+00	2026-04-23 05:07:55.068588+00	\N	f36230c8-dc1a-4882-962d-10b3d099045a
00000000-0000-0000-0000-000000000000	593	tsujb7bhanva	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 05:16:16.513088+00	2026-04-23 05:16:16.513088+00	\N	e29606d5-f536-4d2f-9fae-39dbe5ba2d67
00000000-0000-0000-0000-000000000000	594	53dkgmfgc6s7	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 05:19:33.331817+00	2026-04-23 05:19:33.331817+00	\N	450c3154-d86b-458c-8de6-cec1c3c4c72d
00000000-0000-0000-0000-000000000000	595	vqkit2hjyctb	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 05:20:29.20923+00	2026-04-23 05:20:29.20923+00	\N	789a758a-becd-4e6b-bae3-91a90ed35d74
00000000-0000-0000-0000-000000000000	596	bnzyioip6wfo	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 06:20:33.177732+00	2026-04-23 06:20:33.177732+00	\N	1cdc98b7-6bca-4b85-8577-0fedfcd5479d
00000000-0000-0000-0000-000000000000	597	gfcck6g3rqeh	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 06:30:14.176192+00	2026-04-23 06:30:14.176192+00	\N	3e636757-f459-4475-81ec-a9acc46912fe
00000000-0000-0000-0000-000000000000	598	yqe2hrj5xu7v	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 06:32:03.722031+00	2026-04-23 06:32:03.722031+00	\N	6e129402-ff18-45de-8c4b-d4db15e4d9f2
00000000-0000-0000-0000-000000000000	599	kqnexe3a2xlx	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-23 07:41:23.345019+00	2026-04-23 07:41:23.345019+00	\N	7f600af5-fd5e-46d7-a357-0d2aacc833b5
00000000-0000-0000-0000-000000000000	600	hp5so4xzw3cl	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-25 07:11:22.10398+00	2026-04-25 07:11:22.10398+00	\N	837f156c-e13e-4c6b-a65c-b9521fc036b6
00000000-0000-0000-0000-000000000000	601	i4ctfrylqifs	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-25 07:20:18.130724+00	2026-04-25 07:20:18.130724+00	\N	30afd630-1eb3-4d12-bab5-72efc3aa6fc5
00000000-0000-0000-0000-000000000000	602	fuglldruxaju	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-25 07:21:58.062037+00	2026-04-25 07:21:58.062037+00	\N	1e7c37a9-acd1-4514-b246-9bccbd131e9c
00000000-0000-0000-0000-000000000000	603	vodzhkqetvmx	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-25 07:22:13.492524+00	2026-04-25 07:22:13.492524+00	\N	93183258-df1a-4289-ac1e-3a93cc3cee38
00000000-0000-0000-0000-000000000000	604	akgh7l7wzihj	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-25 07:26:07.862619+00	2026-04-25 07:26:07.862619+00	\N	61b300dc-c5fd-480d-be95-bd3c34e65722
00000000-0000-0000-0000-000000000000	605	jh2d667kysbs	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-25 07:26:52.546369+00	2026-04-25 07:26:52.546369+00	\N	2497a9b2-5060-4936-aa07-3e3a875a4df1
00000000-0000-0000-0000-000000000000	606	hzpwneukst6m	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-25 07:28:19.247248+00	2026-04-25 07:28:19.247248+00	\N	59547bab-e551-45b8-b459-dee61fe3180c
00000000-0000-0000-0000-000000000000	607	mxdx5ns5uxwp	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-25 07:44:09.49345+00	2026-04-25 07:44:09.49345+00	\N	2e917f3f-e275-4a33-87ef-80fa832b198a
00000000-0000-0000-0000-000000000000	608	2tnzj6zildog	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-25 07:45:34.869079+00	2026-04-25 07:45:34.869079+00	\N	cf005b5b-240c-4817-a1dd-e1a94262e0cc
00000000-0000-0000-0000-000000000000	609	tvgrk4ylyjav	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-25 08:05:52.971029+00	2026-04-25 08:05:52.971029+00	\N	ec07e553-53f0-46a4-8be7-2000403f6880
00000000-0000-0000-0000-000000000000	610	icqmfqtjjcre	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-25 08:51:17.165812+00	2026-04-25 08:51:17.165812+00	\N	6d6f187d-0a97-4b20-b42f-db786b8806a0
00000000-0000-0000-0000-000000000000	611	irlwzkp3i5eg	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-26 07:51:19.269556+00	2026-04-26 07:51:19.269556+00	\N	20ee1434-65ec-4218-b286-57cd2deba9ff
00000000-0000-0000-0000-000000000000	612	waunhghpgera	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-26 09:04:45.885525+00	2026-04-26 09:04:45.885525+00	\N	400a2425-c85d-4496-86f2-c5f3a8c5e173
00000000-0000-0000-0000-000000000000	613	7f2nnipybxqd	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-26 09:54:59.237386+00	2026-04-26 09:54:59.237386+00	\N	9ee7992c-859a-454e-b3b7-ae938f59897f
00000000-0000-0000-0000-000000000000	614	rxl2e4vivxhj	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-26 15:50:14.963708+00	2026-04-26 15:50:14.963708+00	\N	aa203841-80bd-43cc-9173-5746b29433b8
00000000-0000-0000-0000-000000000000	615	bstl7rttnqa6	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-26 16:09:28.865391+00	2026-04-26 16:09:28.865391+00	\N	f20e91a2-ab5a-44ae-9f2f-8224659364a6
00000000-0000-0000-0000-000000000000	616	fxgsfzz77fhc	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-26 16:10:08.902634+00	2026-04-26 16:10:08.902634+00	\N	199e2056-5d90-4ce5-9aa7-11d5f59b5668
00000000-0000-0000-0000-000000000000	617	k7qduefi5htr	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-26 16:38:36.264559+00	2026-04-26 16:38:36.264559+00	\N	cf3f4c69-64a9-471b-8f22-39f79acccb6f
00000000-0000-0000-0000-000000000000	618	pyeokmlbfbfy	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-27 07:32:16.194856+00	2026-04-27 07:32:16.194856+00	\N	40a3fd43-4ae9-44bb-92bc-60ee9c38c0f9
00000000-0000-0000-0000-000000000000	619	n6tkwwzsldc6	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-27 07:33:46.600814+00	2026-04-27 07:33:46.600814+00	\N	8af31811-1f63-482e-bafb-347aca143299
00000000-0000-0000-0000-000000000000	620	wzopmtjkydvy	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-27 07:49:20.711033+00	2026-04-27 07:49:20.711033+00	\N	62d42694-f59f-4410-a26a-7c8ede8dc3ed
00000000-0000-0000-0000-000000000000	621	6eze3onavmr6	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-27 08:22:50.781065+00	2026-04-27 08:22:50.781065+00	\N	ff711ff8-0c2f-47c7-91f8-a87609860615
00000000-0000-0000-0000-000000000000	622	cvpunz4xv6rz	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-27 08:34:12.7265+00	2026-04-27 08:34:12.7265+00	\N	e9618869-24d6-4a54-a65d-f79d05bf86c4
00000000-0000-0000-0000-000000000000	623	vbwjge5gm62a	c6ad1e17-f6f1-4229-8580-b00e595c3050	f	2026-04-27 16:26:39.256914+00	2026-04-27 16:26:39.256914+00	\N	1cbf971e-ee8e-4b64-bc57-bd0179738cc0
00000000-0000-0000-0000-000000000000	624	2omjf3es3uyu	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-27 16:28:05.03048+00	2026-04-27 16:28:05.03048+00	\N	05fdcbb8-7bd1-4b03-a9d0-9209fbff7043
00000000-0000-0000-0000-000000000000	625	z43uej2tgy7x	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-27 17:47:19.094529+00	2026-04-27 17:47:19.094529+00	\N	1cdd067d-162b-43af-ad75-9816962f9949
00000000-0000-0000-0000-000000000000	626	s5hpmfhcrnle	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-27 18:11:05.324612+00	2026-04-27 18:11:05.324612+00	\N	2b072cf8-3998-4c14-83e8-4284faffc351
00000000-0000-0000-0000-000000000000	627	xojvyjloefpc	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-27 19:16:29.17598+00	2026-04-27 19:16:29.17598+00	\N	e2319ddd-38f2-4be8-ae50-0314cd6056ec
00000000-0000-0000-0000-000000000000	628	edksg6pfrcok	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-28 14:00:38.781052+00	2026-04-28 14:00:38.781052+00	\N	9f7d3b81-fae5-45ea-994e-5f05bc01521a
00000000-0000-0000-0000-000000000000	629	2gmhvlq5oxm6	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-28 14:36:38.170398+00	2026-04-28 14:36:38.170398+00	\N	7641547c-c648-402f-a9a9-43025fd40763
00000000-0000-0000-0000-000000000000	630	bxiqjwjejphv	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-04-28 14:38:36.619809+00	2026-04-28 14:38:36.619809+00	\N	5191d1f1-cb05-4eaf-833a-0edf35c35f8d
00000000-0000-0000-0000-000000000000	631	f52v6exhnc2c	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-30 15:26:22.452566+00	2026-04-30 15:26:22.452566+00	\N	ae7f4174-8a0f-44bc-b540-88e7f86e4ea7
00000000-0000-0000-0000-000000000000	632	xyyb5guzisnt	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-04-30 17:44:16.612775+00	2026-04-30 17:44:16.612775+00	\N	8bcc60ba-6d73-41f1-98d3-2733814e470e
00000000-0000-0000-0000-000000000000	633	s4qzcjw47ma5	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 01:20:21.635405+00	2026-05-01 01:20:21.635405+00	\N	742e7725-6094-4cf8-9a5b-cd5d942d1e04
00000000-0000-0000-0000-000000000000	634	3k2crtl6um3k	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 02:02:42.95154+00	2026-05-01 02:02:42.95154+00	\N	f42ca4bb-08d5-411d-96f2-7391c3afbd46
00000000-0000-0000-0000-000000000000	635	swff3y53ol5d	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 06:20:34.769365+00	2026-05-01 06:20:34.769365+00	\N	8fffaf74-714c-414b-a594-74ddf9741101
00000000-0000-0000-0000-000000000000	636	y6j3bptaps4d	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 06:48:27.125235+00	2026-05-01 06:48:27.125235+00	\N	bfb580a2-9591-4653-ab7a-2e4c5fa6afe3
00000000-0000-0000-0000-000000000000	637	3ed2fpukkhle	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 07:01:52.864945+00	2026-05-01 07:01:52.864945+00	\N	782335c8-92d6-4b46-ba89-8b81eb4be51c
00000000-0000-0000-0000-000000000000	638	57wj3dqtppad	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 07:07:18.368609+00	2026-05-01 07:07:18.368609+00	\N	81ea8cdf-d813-4dc3-8a59-05cacdb7d098
00000000-0000-0000-0000-000000000000	639	skok5ijmmedf	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 08:19:58.258329+00	2026-05-01 08:19:58.258329+00	\N	6d5696e0-1092-4d21-bb85-5084d80704e4
00000000-0000-0000-0000-000000000000	640	hxf7vjypzq6s	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 09:06:19.767062+00	2026-05-01 09:06:19.767062+00	\N	6d4dfaec-07d8-4ce8-8f02-b29366a4b1da
00000000-0000-0000-0000-000000000000	641	xkictn3hyyqg	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 09:10:46.14527+00	2026-05-01 09:10:46.14527+00	\N	962c4531-eb5a-42b0-b95d-b9c1365d8c8f
00000000-0000-0000-0000-000000000000	642	4ylx7uvrg6q7	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-05-01 13:06:45.419461+00	2026-05-01 13:06:45.419461+00	\N	e6a3f828-1bde-44ab-b5fe-24bb16c98be0
00000000-0000-0000-0000-000000000000	643	5h7ypffugy4i	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 14:19:55.909725+00	2026-05-01 14:19:55.909725+00	\N	1997b91d-e471-4d0d-a2bb-df5fe442c36c
00000000-0000-0000-0000-000000000000	644	xgtt2gadxoxn	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-01 14:27:08.800698+00	2026-05-01 14:27:08.800698+00	\N	3b9d0ec0-36d0-4a25-b018-c235f9a93629
00000000-0000-0000-0000-000000000000	645	cu7ykqoj76am	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-02 09:56:07.494284+00	2026-05-02 09:56:07.494284+00	\N	8a8da4c8-0118-4a9f-bb1f-a0cad1ce1daf
00000000-0000-0000-0000-000000000000	646	hkxrmg3r64p2	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-02 10:10:14.607865+00	2026-05-02 10:10:14.607865+00	\N	383bed75-5c57-4a04-9303-3a8b0567ab3c
00000000-0000-0000-0000-000000000000	647	xqyubcmhuh6p	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-05-02 11:40:59.167071+00	2026-05-02 11:40:59.167071+00	\N	39a139b2-624e-456c-874f-5c711b37838e
00000000-0000-0000-0000-000000000000	648	3hbujyq6slu7	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-05-02 12:01:20.659726+00	2026-05-02 12:01:20.659726+00	\N	fb85bd44-f69b-4a13-98dc-6321840f5007
00000000-0000-0000-0000-000000000000	649	45dqutgvwvug	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-05-02 16:07:12.411963+00	2026-05-02 16:07:12.411963+00	\N	d3d07b39-f66f-4443-a112-5a4f1c8e56fc
00000000-0000-0000-0000-000000000000	650	gtkapty4eroj	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-05-02 16:10:29.198879+00	2026-05-02 16:10:29.198879+00	\N	cddf1de4-bbaa-4abd-bcc8-af2d17435e06
00000000-0000-0000-0000-000000000000	651	mlqppqn347c2	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-05-04 10:26:54.705736+00	2026-05-04 10:26:54.705736+00	\N	0acc2bf0-119b-4927-a968-f2b7ce0c52f7
00000000-0000-0000-0000-000000000000	652	d5kcir4udh3u	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 10:29:01.853655+00	2026-05-04 10:29:01.853655+00	\N	3b46e5a8-cbc9-43a4-a63c-89698fdd0fb4
00000000-0000-0000-0000-000000000000	653	o7uicdmhdmlp	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 11:06:17.67262+00	2026-05-04 11:06:17.67262+00	\N	22b18105-79b2-4147-9b54-2c96a5fbc748
00000000-0000-0000-0000-000000000000	654	zgs3op7fbhuj	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 11:09:55.504706+00	2026-05-04 11:09:55.504706+00	\N	4f08a901-8d1e-4112-9c15-808ebedfb9c2
00000000-0000-0000-0000-000000000000	655	em32yofpbzyh	b326f22a-02fc-4d99-bce9-6c933113a7a0	f	2026-05-04 11:17:38.805133+00	2026-05-04 11:17:38.805133+00	\N	26d1ef9f-4ac7-4d4e-baf0-0321d422a933
00000000-0000-0000-0000-000000000000	656	mi2fjezlahxi	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 11:22:20.514017+00	2026-05-04 11:22:20.514017+00	\N	18955def-8aef-4bff-bacc-42e47501b39d
00000000-0000-0000-0000-000000000000	657	jvzyzrrzcj6q	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 12:50:29.700361+00	2026-05-04 12:50:29.700361+00	\N	9aa95227-cb72-4ac8-ae6b-1ce60dbf0cbc
00000000-0000-0000-0000-000000000000	658	7gt6vtmupbms	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:12:47.714278+00	2026-05-04 13:12:47.714278+00	\N	271ee288-b483-4e81-b696-f7ba1a92d95f
00000000-0000-0000-0000-000000000000	659	fkxbt3hrmbqx	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:16:37.543892+00	2026-05-04 13:16:37.543892+00	\N	bf0fd37f-0fa9-4edd-bf7d-9765348598ce
00000000-0000-0000-0000-000000000000	660	7kk3hx4z5ltq	ca38c166-41e5-4f9d-b14a-caa71d08be01	f	2026-05-04 13:19:29.430457+00	2026-05-04 13:19:29.430457+00	\N	0a561128-767e-486e-8ad4-708497c76b3f
00000000-0000-0000-0000-000000000000	661	d626tajwoly7	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:22:52.312472+00	2026-05-04 13:22:52.312472+00	\N	784695ac-1358-445f-92b1-ff40b95305b1
00000000-0000-0000-0000-000000000000	662	6auvtzn4vcs5	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:28:19.644642+00	2026-05-04 13:28:19.644642+00	\N	9e5ff786-e71b-4194-a2cd-84a597343d8a
00000000-0000-0000-0000-000000000000	663	jdgktrjwbc4a	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:31:23.366903+00	2026-05-04 13:31:23.366903+00	\N	a5faaf51-7136-4bd4-93e6-1976a525a986
00000000-0000-0000-0000-000000000000	664	weh457vqiz5i	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:36:10.095342+00	2026-05-04 13:36:10.095342+00	\N	b508f14d-e413-4a16-a855-f83c2848fcef
00000000-0000-0000-0000-000000000000	665	o2xucvu5qtsg	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:37:34.776868+00	2026-05-04 13:37:34.776868+00	\N	9aa136a9-8f95-4cff-b636-ef5833db697c
00000000-0000-0000-0000-000000000000	666	yckq5lnrgjkp	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:39:14.858934+00	2026-05-04 13:39:14.858934+00	\N	6eccbdc1-253f-4634-a0ff-fe3a0d05985a
00000000-0000-0000-0000-000000000000	667	tfn7ba5rffk7	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:39:34.801011+00	2026-05-04 13:39:34.801011+00	\N	3db5d471-14d4-4740-b317-36e5310b6127
00000000-0000-0000-0000-000000000000	668	vyp4z53xlpok	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:42:21.624954+00	2026-05-04 13:42:21.624954+00	\N	9fd983ef-6082-4532-ac21-aeff8cf8529b
00000000-0000-0000-0000-000000000000	669	rcfovbe2pang	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:44:06.505615+00	2026-05-04 13:44:06.505615+00	\N	55ea2531-9642-4600-a2c2-ac42cf20fd29
00000000-0000-0000-0000-000000000000	670	moiamldspxny	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:49:56.891076+00	2026-05-04 13:49:56.891076+00	\N	d66310fb-a991-47a0-9b56-92182d261438
00000000-0000-0000-0000-000000000000	671	zbifr3xckpjr	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:56:19.058124+00	2026-05-04 13:56:19.058124+00	\N	406eee40-0460-4967-835b-3a0c698de3c0
00000000-0000-0000-0000-000000000000	672	25eeqd2gbnvb	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:57:42.578808+00	2026-05-04 13:57:42.578808+00	\N	91a2d06e-b4fc-4758-99c5-7ff4044c354f
00000000-0000-0000-0000-000000000000	673	tkndn3psqkhw	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 13:58:33.859756+00	2026-05-04 13:58:33.859756+00	\N	9534a5a0-4a59-4509-8219-b7b423e78f45
00000000-0000-0000-0000-000000000000	674	pwu7dstvn2np	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:01:31.972341+00	2026-05-04 14:01:31.972341+00	\N	6efa0733-afd7-4fd9-a1b6-1a81b2a950b1
00000000-0000-0000-0000-000000000000	675	aik2nkmge3x7	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:06:18.684583+00	2026-05-04 14:06:18.684583+00	\N	156740f7-41a1-49b7-8720-5fd84ced4089
00000000-0000-0000-0000-000000000000	676	mlzircsptdyn	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:07:07.301579+00	2026-05-04 14:07:07.301579+00	\N	ea062a4b-fc3e-4deb-a2c3-f7b9d616d25a
00000000-0000-0000-0000-000000000000	678	5fvcv5zc5wzf	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:13:25.570211+00	2026-05-04 14:13:25.570211+00	\N	5f184909-fe5c-4fc1-ad7a-486d3b3e9c89
00000000-0000-0000-0000-000000000000	679	sdqlk752fu7h	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:25:28.777113+00	2026-05-04 14:25:28.777113+00	\N	85566771-04bc-4947-ad48-3bb5192e30a5
00000000-0000-0000-0000-000000000000	680	g5gijfh3aw55	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:27:32.899842+00	2026-05-04 14:27:32.899842+00	\N	2735619f-7862-47d2-a1f3-73386e4cdb61
00000000-0000-0000-0000-000000000000	681	xxglt46tgtcn	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:34:07.022379+00	2026-05-04 14:34:07.022379+00	\N	cb2aed6f-5bec-4cb8-a18b-6fe17900bd18
00000000-0000-0000-0000-000000000000	682	n4zbzhbc2ah4	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:39:04.331872+00	2026-05-04 14:39:04.331872+00	\N	16c8d526-de6c-4e64-a752-5bd21fac4d64
00000000-0000-0000-0000-000000000000	683	2kzlbmjtqfuj	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 14:41:19.636378+00	2026-05-04 14:41:19.636378+00	\N	f2d9cadb-4971-4305-a788-14b15222ab44
00000000-0000-0000-0000-000000000000	677	ik53o7jl7ioy	5f56692b-8daa-4852-bfe7-1032a07635ff	t	2026-05-04 14:09:04.520371+00	2026-05-04 15:07:07.186114+00	\N	0da322a3-9ddd-4d84-9976-c7d5cb5aea74
00000000-0000-0000-0000-000000000000	684	mjywwusrtx75	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 15:07:07.215024+00	2026-05-04 15:07:07.215024+00	ik53o7jl7ioy	0da322a3-9ddd-4d84-9976-c7d5cb5aea74
00000000-0000-0000-0000-000000000000	685	revy7beq52kv	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 15:09:23.643345+00	2026-05-04 15:09:23.643345+00	\N	f473ec2e-6b3e-47be-9991-1876f4663cf8
00000000-0000-0000-0000-000000000000	686	36sjl4bdd3dx	5f56692b-8daa-4852-bfe7-1032a07635ff	f	2026-05-04 15:21:31.533839+00	2026-05-04 15:21:31.533839+00	\N	273540f7-359b-498f-a51d-6cd362c9c412
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag, oauth_client_id, refresh_token_hmac_key, refresh_token_counter, scopes) FROM stdin;
e8a00a84-273b-483c-b0ff-83a9e3615c01	b7ea8833-6fff-4302-8d1b-4424676cb299	2026-03-28 08:31:55.117471+00	2026-03-28 08:31:55.117471+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
105726ea-31d8-4cad-ac45-143cce6df58d	b7ea8833-6fff-4302-8d1b-4424676cb299	2026-03-28 08:33:56.227475+00	2026-03-28 08:33:56.227475+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
2389047d-42c5-484b-afdf-485a584b99ed	b7ea8833-6fff-4302-8d1b-4424676cb299	2026-03-28 08:34:38.1918+00	2026-03-28 08:34:38.1918+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
695d41ea-2d9e-45d4-b583-3051112c8a72	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 04:45:03.411914+00	2026-04-05 04:45:03.411914+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
8af7e34c-9845-47e3-b62d-b4239885c0a5	f1723551-793e-40ee-9996-853d1cfc04cc	2026-04-02 04:26:26.846362+00	2026-04-02 04:26:26.846362+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
83ec774a-ba4c-4408-bb58-b85fa25cd59a	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-27 16:58:45.968611+00	2026-03-27 16:58:45.968611+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
ee15d3b8-509c-4555-b63c-947fe183de06	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 04:56:27.633602+00	2026-04-05 04:56:27.633602+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
69d65f9e-c13e-45c7-bad4-c3060de1924e	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 09:21:47.27541+00	2026-03-28 09:21:47.27541+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
20f2ddcf-73a6-46d8-886b-73e5c6d7e84b	f1723551-793e-40ee-9996-853d1cfc04cc	2026-04-03 17:04:37.23025+00	2026-04-03 17:04:37.23025+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
a78df8c5-5bb7-4ddb-a769-8f24c9947986	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 04:56:36.64977+00	2026-04-05 04:56:36.64977+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
5d072393-1c6a-4a2d-a590-9132554e1471	f1723551-793e-40ee-9996-853d1cfc04cc	2026-04-03 17:12:04.685615+00	2026-04-03 17:12:04.685615+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
b3dfc00b-a88f-4255-908c-1d5db383852e	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-03 17:12:19.146123+00	2026-04-03 17:12:19.146123+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
aaf5c08d-1737-46df-9073-20421a87b8dd	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 05:32:57.07968+00	2026-04-05 05:32:57.07968+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
0b9a2491-e8cc-4d38-8de7-228e4108e13e	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-04 10:34:11.846978+00	2026-04-04 10:34:11.846978+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
4514e11f-b5ed-45bd-9900-951aaa4f021f	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 01:01:57.01849+00	2026-04-05 01:01:57.01849+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
040b608f-a0b9-454f-a567-b7e3c8b2b94b	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 02:35:29.326907+00	2026-04-05 02:35:29.326907+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
eff9ad30-a9b0-4016-ae83-767b064a7067	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 06:42:46.636587+00	2026-04-05 06:42:46.636587+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
7da45766-3b2d-4b59-bd8d-f814a8faa88a	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 07:31:26.215723+00	2026-04-05 07:31:26.215723+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
3f827437-0fc8-4052-87f2-d78a44271efe	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 07:45:30.280095+00	2026-04-05 07:45:30.280095+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
c021202a-ecea-40c3-887c-473c4b4ec0bf	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 10:49:53.493116+00	2026-03-28 10:49:53.493116+00	\N	aal1	\N	\N	node	118.69.13.249	\N	\N	\N	\N	\N
6b914ea3-faf7-4939-883f-41f74e4fd509	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 07:52:37.370711+00	2026-04-05 07:52:37.370711+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
e8e90756-c4d4-4dff-b940-a903c24a65b4	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 08:59:11.411122+00	2026-04-05 08:59:11.411122+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
3d329806-9118-42b4-9c8f-ef0e302f0cc8	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 11:28:14.255194+00	2026-03-28 12:59:34.020608+00	\N	aal1	\N	2026-03-28 12:59:34.019388	node	14.187.21.199	\N	\N	\N	\N	\N
382934bf-9061-4b64-a014-9e9aa79c72d9	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 13:22:47.906797+00	2026-03-28 13:22:47.906797+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
05dd48ae-bdc0-44c6-820f-e83d2fe6ca22	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 13:34:52.096072+00	2026-03-28 13:34:52.096072+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
2784f74c-b2dd-494a-8db7-e5865052f0e3	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 04:44:36.404693+00	2026-03-30 04:44:36.404693+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
654d799b-5c16-42e6-9889-d3538e11b2f0	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 15:50:44.005896+00	2026-04-05 15:50:44.005896+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
3e28e52f-9858-4465-9ceb-fa38bbc9f384	c48465fb-520d-445f-b8cc-e8f08c1b8a38	2026-04-08 00:12:05.214542+00	2026-04-08 00:12:05.214542+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
a5800bb6-a6c4-4c6e-ac71-721e31ce5ec5	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 15:50:14.330501+00	2026-03-28 15:50:14.330501+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
ea7ba9f4-b502-425e-b8e3-b38f9e7c101f	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 09:12:35.737127+00	2026-04-05 09:12:35.737127+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
4cdd848a-8208-4fe5-a57b-bfbf61174421	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 16:12:49.141818+00	2026-04-05 16:12:49.141818+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
f6c62ca2-d98f-4b7d-95b0-333b2b3b90b9	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 16:13:08.549572+00	2026-04-05 16:13:08.549572+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
77a76653-2f24-4da2-aa64-42fab3198bc2	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 16:31:53.074117+00	2026-04-05 16:31:53.074117+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
1d69f845-b46e-44ae-9612-c79c6e172ed4	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 15:54:53.46722+00	2026-03-28 15:54:53.46722+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
11bcd35c-fdd4-4f7b-b97a-8e019e8f8de7	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 16:32:41.417451+00	2026-04-05 16:32:41.417451+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
abf8dff8-a1d4-4e4a-a5db-0ff8b92ad244	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-03-28 16:48:02.242411+00	2026-03-28 16:48:02.242411+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
1f1b6f71-bb3f-4fb0-985f-57148503ae26	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 17:06:01.879506+00	2026-03-28 17:06:01.879506+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
cea9febb-5890-4f81-a6e8-718a8292501d	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 17:07:58.31695+00	2026-03-28 17:07:58.31695+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
5f283801-6258-4685-a036-a138031ba1ac	b7ea8833-6fff-4302-8d1b-4424676cb299	2026-03-28 17:10:35.769359+00	2026-03-28 17:10:35.769359+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
e44291d0-c38c-4971-901d-a3e213900a36	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 17:13:15.414941+00	2026-03-28 17:13:15.414941+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
b71c06e8-0eba-4aab-bdde-19c57b0a0adc	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 17:17:20.867399+00	2026-03-28 17:17:20.867399+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
b973abc9-79ac-49d8-b5d3-eab9b6e439f6	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 17:37:23.693717+00	2026-03-28 17:37:23.693717+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
9974e216-5cb6-4c74-8cbd-cad4cdcce380	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 17:38:30.355905+00	2026-03-28 17:38:30.355905+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
daddfdd9-0ac8-4af0-93c3-ac7b638c7c30	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-28 18:16:28.097416+00	2026-03-28 18:16:28.097416+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
fd1ea4aa-e0d9-4fee-932c-83032fa4290d	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 03:18:41.616418+00	2026-03-30 04:16:59.31736+00	\N	aal1	\N	2026-03-30 04:16:59.316621	node	14.187.21.199	\N	\N	\N	\N	\N
f5e3e664-975d-4b0a-b33a-5ab39ac418f8	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 04:29:59.847087+00	2026-03-30 04:29:59.847087+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
3e559c7e-1091-4689-b4a1-e1dc37bf377d	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 13:42:52.828687+00	2026-03-30 13:42:52.828687+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
3d4f2bff-d3a0-4036-8fa7-3c02c9cf5d9d	9a54cb41-ee7d-417e-9563-9fb95a35c29c	2026-03-30 14:21:19.827051+00	2026-03-30 15:19:41.791137+00	\N	aal1	\N	2026-03-30 15:19:41.791043	node	14.187.21.199	\N	\N	\N	\N	\N
188e2d63-486d-4fa4-9f6f-c08d676e7a07	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 16:33:43.686787+00	2026-03-30 16:33:43.686787+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
75d31b9c-c80d-44dd-9a03-4e2288d73f77	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 17:34:13.395914+00	2026-03-30 17:34:13.395914+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
9e6f6203-a900-4c39-9ace-3b2464c6f912	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 17:46:39.034572+00	2026-03-30 17:46:39.034572+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
0d4ab3bb-c2ce-4410-92b2-117dc3e92920	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 16:42:38.166255+00	2026-04-05 16:42:38.166255+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
cc103ed1-c431-45b8-9778-e86609069bbb	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 17:50:29.393543+00	2026-03-30 17:50:29.393543+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
17262a5c-d9da-4f53-bb82-d90c3064e6dd	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 18:03:17.213274+00	2026-03-30 18:03:17.213274+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
17857740-6c3a-47e4-922a-64eed22f2f5e	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-30 18:21:03.746149+00	2026-03-30 18:21:03.746149+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
7bd622c1-32a1-4c81-bd09-85b64b99060a	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-30 21:58:57.429867+00	2026-03-30 21:58:57.429867+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
5c9b733c-38d0-4a8d-b6b8-be693b23fef9	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-30 23:02:52.987133+00	2026-03-30 23:02:52.987133+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
43cb828c-d78a-42d9-bcc7-484c82e4e3f6	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 17:00:38.673983+00	2026-04-05 17:00:38.673983+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
ccd0f18d-4c82-4856-869e-50c23b0d8ef1	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-07 17:40:58.283891+00	2026-04-07 17:40:58.283891+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
7f2d65d3-c90c-456a-825e-b6c4b0c5132f	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-03-31 08:05:57.915331+00	2026-03-31 08:05:57.915331+00	\N	aal1	\N	\N	node	103.245.150.18	\N	\N	\N	\N	\N
e79494cf-3acc-4de2-9f2c-cb34d60e456b	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-31 16:43:40.660821+00	2026-03-31 17:42:01.602136+00	\N	aal1	\N	2026-03-31 17:42:01.601437	node	171.232.68.33	\N	\N	\N	\N	\N
31bf9fe8-e7a0-48dc-879f-8fc3f35e414c	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-27 16:58:06.915846+00	2026-03-27 16:58:06.915846+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
18deef48-5bff-46cb-a7da-8f0004979157	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-27 17:24:53.397028+00	2026-03-27 17:24:53.397028+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
493a5611-d789-4195-8a4b-7eb20b413d69	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-31 17:47:15.346092+00	2026-03-31 17:47:15.346092+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
0599110c-70a3-43b5-8eba-e6d3e86df115	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-31 18:16:25.925504+00	2026-03-31 18:16:25.925504+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
4503e0f8-7085-4202-9396-fca513ee2737	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-03-31 18:49:23.525934+00	2026-03-31 18:49:23.525934+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
6a15d8e8-aaea-4a29-8d03-749bbdfe9ad1	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-03-28 08:05:30.694764+00	2026-03-28 08:05:30.694764+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
c19c862e-45f3-4ff6-b760-6ad50934eb53	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-03-28 08:05:49.58422+00	2026-03-28 08:05:49.58422+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
3a784b14-6d9e-4cb7-b551-b6bb8572e4b4	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-03-28 08:08:38.201642+00	2026-03-28 08:08:38.201642+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
e6888758-df45-4c67-8b9e-104c019531c2	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-03-28 08:22:14.382851+00	2026-03-28 08:22:14.382851+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
a5e9ac54-f82f-4310-8d2c-b78f9f4dc77e	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-03-28 08:23:44.57541+00	2026-03-28 08:23:44.57541+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
0249cdd6-8123-456f-aa2e-30ce29ad020e	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-01 01:50:48.388763+00	2026-04-01 01:50:48.388763+00	\N	aal1	\N	\N	node	118.69.13.249	\N	\N	\N	\N	\N
cdc76db6-4642-4d17-95bf-db04af47dd35	353b8afb-61a8-4233-96dd-480e99a0ff83	2026-04-01 11:17:01.803962+00	2026-04-01 11:17:01.803962+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
70ae080e-bf8e-415a-91b7-974135faace5	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-01 14:14:40.821712+00	2026-04-01 16:11:25.115833+00	\N	aal1	\N	2026-04-01 16:11:25.115738	node	14.187.21.199	\N	\N	\N	\N	\N
610b49bb-2d8b-428e-b0d0-cb62ee2e8bc5	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-01 16:32:19.040923+00	2026-04-01 16:32:19.040923+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
1b679902-2027-4dca-8828-36b6948665cf	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-04-01 14:28:11.647965+00	2026-04-02 00:04:53.848091+00	\N	aal1	\N	2026-04-02 00:04:53.847969	node	171.232.68.33	\N	\N	\N	\N	\N
e353cb40-9817-40a3-8128-9f5baa3140e5	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-04-03 20:47:05.778071+00	2026-04-03 20:47:05.778071+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
d41d46f9-f562-42ab-8079-ef938e36defa	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-04-03 21:50:14.357156+00	2026-04-03 21:50:14.357156+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
832a7ffd-b1c0-42a9-9efc-7178db1a8f09	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-04-03 22:05:30.819786+00	2026-04-03 22:05:30.819786+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
827fdd99-5450-4335-bd71-83e0ff828220	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-08 04:22:55.97817+00	2026-04-08 04:22:55.97817+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
3d68bfa9-c0dd-4257-bc91-97fb80c177db	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-08 04:24:23.141373+00	2026-04-08 04:24:23.141373+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
1b2e33f2-b47e-45f1-8801-fe87aa7d6460	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-04 18:28:29.833823+00	2026-04-04 19:26:56.45497+00	\N	aal1	\N	2026-04-04 19:26:56.454875	node	42.116.172.137	\N	\N	\N	\N	\N
ca1db5ac-9f81-4a92-9541-ecb974715bd0	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 01:19:30.004377+00	2026-04-05 01:19:30.004377+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
e00f1709-000a-463e-9630-8d01e977d82e	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 02:56:14.074051+00	2026-04-05 02:56:14.074051+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
23ccc957-d9b5-4a80-8883-53655d3082e7	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 04:50:51.829615+00	2026-04-05 04:50:51.829615+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
8574d4b8-dcaf-4162-8f5e-dcc50938f20d	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 05:23:28.169993+00	2026-04-05 05:23:28.169993+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
c41aa3fa-899d-4497-98bc-aaaee6e3af9c	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 06:53:28.061789+00	2026-04-05 06:53:28.061789+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
5d198fa3-a8ac-435c-8952-418db7e7400a	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 07:43:54.510505+00	2026-04-05 07:43:54.510505+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
b0d4651b-f457-4257-a550-aa8c292efcf3	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 07:47:42.69992+00	2026-04-05 07:47:42.69992+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
b8ab4d11-6742-4d43-a597-6e8f4376656f	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 07:48:11.834735+00	2026-04-05 07:48:11.834735+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
0422fc81-6cec-46a3-bd08-219cf123b011	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 07:48:33.82119+00	2026-04-05 07:48:33.82119+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
9451dd9d-e3a3-41b0-93f7-bd66404b9c9b	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 08:06:24.176975+00	2026-04-05 08:06:24.176975+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
73fd57d5-6a76-4d95-b8ea-5102779f9cd2	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 08:06:24.549509+00	2026-04-05 08:06:24.549509+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
e927ba34-f626-4ce0-a5ce-3de73935a0e5	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 09:00:43.03991+00	2026-04-05 09:00:43.03991+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
cd87ed4e-bb74-42e5-932c-f6fd58c6c9c7	b7ea8833-6fff-4302-8d1b-4424676cb299	2026-04-05 09:08:17.914444+00	2026-04-05 09:08:17.914444+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
ad7d0121-8d1c-4cff-9540-8fa093f1572a	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-04 07:51:05.54878+00	2026-04-04 07:51:05.54878+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
fe23c9d7-936d-49c6-86f1-1d4336e20a51	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-04 07:51:27.197768+00	2026-04-04 07:51:27.197768+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
34412fcc-c2ce-4f07-ae6c-7e77b04b0a7f	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 15:54:11.678783+00	2026-04-05 15:54:11.678783+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
251437b2-4a55-4dc1-b22d-6c010b579759	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-04 07:52:50.411329+00	2026-04-04 07:52:50.411329+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
4e068938-b824-4e70-846c-c4ddd6dec225	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-04 07:53:45.476915+00	2026-04-04 07:53:45.476915+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
5f8aebcc-d8d7-447a-97d1-8ae357a6d843	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 16:30:40.286866+00	2026-04-05 16:30:40.286866+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
5144bbc0-670d-41e6-a512-76a62cbc8558	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-04 07:54:04.210803+00	2026-04-04 07:54:04.210803+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
bae03e61-1bd5-4fad-a630-ddd0f7fe0002	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-05 16:41:10.065561+00	2026-04-05 16:41:10.065561+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
4c5f914a-622c-40a9-8f53-4467164dd7f2	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-05 16:59:31.158452+00	2026-04-05 16:59:31.158452+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
e7682a5e-30e8-4137-9902-c90791d54a6f	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-04-05 05:48:03.14407+00	2026-04-06 00:21:06.997333+00	\N	aal1	\N	2026-04-06 00:21:06.997239	node	171.232.68.33	\N	\N	\N	\N	\N
0119cc33-ac64-4932-8a72-be982dbdad88	c48465fb-520d-445f-b8cc-e8f08c1b8a38	2026-04-06 03:41:55.524705+00	2026-04-06 03:41:55.524705+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
245f7d1f-825a-4b27-aaf1-09266ae1cd76	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-04 08:04:56.422482+00	2026-04-04 08:04:56.422482+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
042c59a5-d1bd-4d56-9da7-1e0bc8e1c5a5	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-07 17:48:56.697199+00	2026-04-07 17:48:56.697199+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
5922f71b-9413-47d2-ade1-0801adeb1df2	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-07 17:49:04.706114+00	2026-04-07 17:49:04.706114+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
115b8691-1176-4e5e-a613-97fd732a736b	c48465fb-520d-445f-b8cc-e8f08c1b8a38	2026-04-08 02:21:18.917175+00	2026-04-08 02:21:18.917175+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
7fc03b47-c7c1-4780-8f89-3310bbd03a61	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-04 03:57:27.012105+00	2026-04-04 03:57:27.012105+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
cebd5bef-5261-4bbe-b58c-59a0cdb57768	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-04 03:59:23.849297+00	2026-04-04 03:59:23.849297+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
66c55acf-1e3b-497b-af03-74f823201120	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-08 05:31:18.548852+00	2026-04-08 05:31:18.548852+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
991ebdc1-fc1b-4ded-ba49-6a05e4fff500	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-08 05:43:19.82482+00	2026-04-08 05:43:19.82482+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
3173ad85-deb3-4d0c-bcaa-fd86c2d2461b	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-08 06:17:51.48362+00	2026-04-08 06:17:51.48362+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
f8f351eb-69cf-420d-b4ed-0c17d754a664	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-08 15:18:38.148151+00	2026-04-08 15:18:38.148151+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
6d751c3e-a94f-4fb1-81ac-eb4ec322d6e4	d2b3704a-f14e-47ad-a8e4-8a7fa617f32a	2026-04-08 15:11:23.176142+00	2026-04-08 15:11:23.176142+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
860db37a-f6f9-4ad6-84eb-106ad60c40b0	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 04:24:26.544894+00	2026-04-09 04:24:26.544894+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
e1a3942d-5af2-4133-8c1c-04f6efee55bf	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-08 15:18:12.862245+00	2026-04-08 15:18:12.862245+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
41c91e36-0a9c-4a7a-81c6-e8902da0731c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 04:28:21.40686+00	2026-04-09 04:28:21.40686+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
9083959f-697d-446e-bf34-1fd18a6056bf	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 17:46:37.852336+00	2026-04-08 17:46:37.852336+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
12db1045-139d-4647-8d4f-62ee0723c70d	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 17:53:22.401975+00	2026-04-08 17:53:22.401975+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
cd3f1f3c-8357-441b-9cd6-75042221fd17	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 18:04:51.685775+00	2026-04-08 18:04:51.685775+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
ab173c51-525c-4ac8-868f-3dfb4652033c	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 18:09:59.010109+00	2026-04-08 18:09:59.010109+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
a2f0a879-6414-41d4-b61f-7aa0c7092a11	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 18:16:38.214511+00	2026-04-08 18:16:38.214511+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
66d6648a-f131-4e63-b9cc-9e20ef0d5017	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 18:20:22.571535+00	2026-04-08 18:20:22.571535+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
77ea16d6-7933-49a9-8888-d23a182cffd4	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 18:20:48.024927+00	2026-04-08 18:20:48.024927+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
3d7daaa9-9b5f-4395-8b0d-d72f68861551	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 18:27:28.10929+00	2026-04-08 18:27:28.10929+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
a3d58d52-785f-4e10-938f-6b4ab220a0bd	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 18:27:49.915266+00	2026-04-08 18:27:49.915266+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
230b1049-dbe5-4757-a62b-92e6b5f04c01	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 18:33:08.328226+00	2026-04-08 18:33:08.328226+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
b27ec1c4-dff1-4e3b-84f1-30bac0703dc6	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 18:34:23.713194+00	2026-04-08 18:34:23.713194+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
9bed12d3-68b3-4186-8057-681568de7e5c	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 18:35:06.773113+00	2026-04-08 18:35:06.773113+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
d3814b86-56f1-4008-8d6e-2172fcec553d	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 18:48:14.274487+00	2026-04-08 18:48:14.274487+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
cc2355ac-f5b4-418d-b290-8980231b2136	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 18:55:18.030733+00	2026-04-08 18:55:18.030733+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
446b0b2a-d1ce-43e3-a911-12e76bc3cfb8	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-08 18:56:36.148991+00	2026-04-08 18:56:36.148991+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
45339381-c0d5-4ebc-807c-39bafc3927f3	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-08 19:04:07.920014+00	2026-04-08 19:04:07.920014+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
9ad46c0d-ea02-423d-8e8e-0cbc4d84c7c4	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 03:18:06.503379+00	2026-04-09 03:18:06.503379+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
605136e8-7c28-4d57-a4fb-7ea0e7c1ffff	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 03:40:02.252772+00	2026-04-09 03:40:02.252772+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
6f76e629-f577-4f70-8335-08b21d8337b8	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 03:48:09.043139+00	2026-04-09 03:48:09.043139+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
b87ac33e-6110-44a1-8f93-87dfd314302f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 04:20:48.577346+00	2026-04-09 04:20:48.577346+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
4be11cae-afff-4e54-9aaa-5e8f49fe3d15	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 10:52:05.769311+00	2026-04-09 10:52:05.769311+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
4a8bade7-41be-488d-a279-535f4115d7ef	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 10:52:44.538306+00	2026-04-09 10:52:44.538306+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
38ff7050-ac73-4245-ada6-dab762adec7a	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 11:05:34.100332+00	2026-04-09 11:05:34.100332+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
8e8cc93a-d1da-4c90-8f18-ac7d7d3bb16c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 11:20:51.041066+00	2026-04-09 11:20:51.041066+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
672f35d0-a631-438d-b49e-e556dd03e89b	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 11:41:12.731086+00	2026-04-09 11:41:12.731086+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
a2caeb8c-5f67-47a9-aaaa-2e72a56436bf	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 11:45:27.222983+00	2026-04-09 11:45:27.222983+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
c7a9483f-8aff-42e4-b367-d45dfbc5101e	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 12:21:11.740521+00	2026-04-09 12:21:11.740521+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
1a96ef1e-004a-4844-8f95-3c6b302752ce	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 12:35:34.534894+00	2026-04-09 12:35:34.534894+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
3f8d4d3a-2fd0-4667-940d-2234e1d1428b	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 12:49:21.037299+00	2026-04-09 12:49:21.037299+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
dfdcc693-06c1-42ab-9f93-dfd24cd0a9ec	353b8afb-61a8-4233-96dd-480e99a0ff83	2026-04-09 14:31:38.58353+00	2026-04-09 14:31:38.58353+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
94977f2c-aef1-460f-8533-69fd63f52b84	353b8afb-61a8-4233-96dd-480e99a0ff83	2026-04-09 14:34:18.649093+00	2026-04-09 14:34:18.649093+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
4939619b-9c09-43fc-8df6-764f2e026168	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 14:40:33.544156+00	2026-04-09 14:40:33.544156+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
d403b595-4031-4419-bbfd-43edcc9e0fc5	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 14:51:28.997488+00	2026-04-09 14:51:28.997488+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
cf2bcd4c-230d-469e-9e66-df376be5e63e	c7910199-028e-4d56-b029-aeb553d977d0	2026-04-09 14:52:35.27473+00	2026-04-09 14:52:35.27473+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
94958ed7-5fb8-4ade-b0ed-8b368f032bca	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 15:07:02.926645+00	2026-04-09 15:07:02.926645+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
ebb3fd0f-34c2-4ce0-833a-218b5b955f7d	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 15:07:41.244891+00	2026-04-09 15:07:41.244891+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
1a6182e0-ea08-4f13-842d-b59de3178c2e	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 15:14:19.392509+00	2026-04-09 15:14:19.392509+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
18c1ab85-14a6-4882-aaa9-c921e07b442c	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 15:17:00.467789+00	2026-04-09 15:17:00.467789+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
78c5c1dc-e31f-4873-b197-292b416aa21a	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 15:18:26.882058+00	2026-04-09 15:18:26.882058+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
41fdc79f-85f7-4d1e-8cfc-bc6fe90253f0	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 15:33:11.477705+00	2026-04-09 15:33:11.477705+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
49ca9e9e-15e1-4185-a711-165d53d07cb9	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 15:35:12.240433+00	2026-04-09 15:35:12.240433+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
fa8e3245-62bd-45e9-8dad-3686a991a5dc	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 15:51:40.186552+00	2026-04-09 15:51:40.186552+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
7d86e62f-ea74-4e27-86cc-57c137dd4b2f	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	2026-04-09 16:00:15.615647+00	2026-04-09 16:00:15.615647+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
4102ed6f-80a4-41c0-9883-5389550ffd05	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-09 16:00:58.544033+00	2026-04-09 16:00:58.544033+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
f1479da9-0b38-4cc9-b725-a4a49aa1b19e	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-09 21:17:36.028763+00	2026-04-09 21:17:36.028763+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
852e2731-4a26-48b6-9b65-c7ee6cbfc807	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-09 21:17:36.345017+00	2026-04-09 21:17:36.345017+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
b6f91aee-d8ce-4f29-a8f4-ff83f50f34f1	10f4c984-9b5d-46dd-8d98-00573752f50a	2026-04-09 21:42:01.386102+00	2026-04-09 21:42:01.386102+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
4d6c18a9-355d-454e-8ef4-c59d8146fd5b	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-09 21:42:43.126337+00	2026-04-09 21:42:43.126337+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
90c9b7b8-c533-4be5-86c9-77e2a42884fd	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-09 22:19:32.609302+00	2026-04-09 22:19:32.609302+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
853af437-1271-404f-b04a-3a569364e01c	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-09 22:19:32.761871+00	2026-04-09 22:19:32.761871+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
7c6fc506-745b-4107-a054-8a804f58c135	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-10 05:09:23.141594+00	2026-04-10 05:09:23.141594+00	\N	aal1	\N	\N	node	203.205.33.15	\N	\N	\N	\N	\N
b151bf43-e4eb-440c-8117-c319eadef5bc	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 05:19:08.638713+00	2026-04-10 05:19:08.638713+00	\N	aal1	\N	\N	node	203.205.33.15	\N	\N	\N	\N	\N
107c3c53-4020-4707-89da-783b783a238c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 08:27:09.307018+00	2026-04-10 08:27:09.307018+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
730795c6-6e10-4b42-8bae-acfebe488c23	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-10 09:01:32.779399+00	2026-04-10 09:01:32.779399+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
eeb8bb05-c0ee-4c9d-9869-8ecee23b9dbd	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-10 09:04:53.551107+00	2026-04-10 09:04:53.551107+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
c412a67b-c3e5-49f2-8148-e325d54a904c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 09:05:43.457856+00	2026-04-10 09:05:43.457856+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
e39d804d-3d19-403a-bc55-9c5556992cfd	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-10 09:18:31.166407+00	2026-04-10 09:18:31.166407+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
895454fa-5370-4cf4-99dc-9620ed02e563	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 10:11:17.991964+00	2026-04-10 10:11:17.991964+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
b13e9062-37f2-4094-aa75-3b54cea9968c	353b8afb-61a8-4233-96dd-480e99a0ff83	2026-04-10 14:41:21.812258+00	2026-04-10 14:41:21.812258+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
965edad2-085d-4506-940c-d3d94f09fcb5	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 14:42:44.559017+00	2026-04-10 14:42:44.559017+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
4dd03a28-6c75-4978-ba53-907a795c00df	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 15:00:55.746092+00	2026-04-10 15:00:55.746092+00	\N	aal1	\N	\N	node	14.187.21.199	\N	\N	\N	\N	\N
efb1fb1a-e0bc-4b43-99c5-75a98dc8b127	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 15:48:56.48581+00	2026-04-10 15:48:56.48581+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
b3b46df2-09ee-455d-82d0-2632025ffc0f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 15:52:41.267517+00	2026-04-10 15:52:41.267517+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
0ebde23d-6f72-4865-b17f-f6a3a9e7be8a	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:12:41.832296+00	2026-04-10 16:12:41.832296+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
a0688797-88ee-4a28-a749-30bf52f41e4d	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:13:02.791292+00	2026-04-10 16:13:02.791292+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
7c6b9d36-52cb-4f22-b7ba-6906ab2bb285	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:13:20.8699+00	2026-04-10 16:13:20.8699+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
7b15ea91-79c6-4f0b-b8c5-3e622813f410	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:14:20.846425+00	2026-04-10 16:14:20.846425+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
e516d52e-2a50-4959-870e-53cafefafffa	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:14:53.202666+00	2026-04-10 16:14:53.202666+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
15dfe990-d8e3-4c76-9fb7-29878ea148f9	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:29:47.640808+00	2026-04-10 16:29:47.640808+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
7e9ebbe9-868d-40d0-b2fb-ed693bc4ea0e	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:30:26.379183+00	2026-04-10 16:30:26.379183+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
5256115a-b313-4f00-abde-d25df23916e7	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:30:46.906086+00	2026-04-10 16:30:46.906086+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
202e2e02-7f0d-4e66-9bb1-849605e0b4d8	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:31:17.546631+00	2026-04-10 16:31:17.546631+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
846000e9-fa3c-4fb8-83b5-ae8efcc5124f	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:32:00.234931+00	2026-04-10 16:32:00.234931+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
c68158c0-71d9-40a4-a7b8-d3c5e0110fb1	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:35:43.044917+00	2026-04-10 16:35:43.044917+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
292f721d-521a-45c5-8569-954cf514ea96	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:42:23.200599+00	2026-04-10 16:42:23.200599+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
f02014fd-bc95-42cc-8df8-9c13c22fb156	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:44:33.202488+00	2026-04-10 16:44:33.202488+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
086f5fd8-416c-45ae-83c2-a07eb0c86cf4	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:46:27.723301+00	2026-04-10 16:46:27.723301+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
632aa82e-758e-44af-b046-9bde3d450fde	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:47:41.788384+00	2026-04-10 16:47:41.788384+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
78acba6b-1edd-4f27-a220-da300b9a2d91	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:51:12.123201+00	2026-04-10 16:51:12.123201+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
99e1f7bd-6e55-4561-85d4-81884ba7c836	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:51:15.401331+00	2026-04-10 16:51:15.401331+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
2057b8ca-1005-459e-9ca5-b8ed27ee66ed	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:51:34.553962+00	2026-04-10 16:51:34.553962+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
12f5ccb1-d502-4b0a-a7de-3e4be0c927a5	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:53:47.928365+00	2026-04-10 16:53:47.928365+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
7f3a7968-eb00-4302-850e-ac777a3be059	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:53:51.610158+00	2026-04-10 16:53:51.610158+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
283ce205-363d-49c6-ae76-1a9cbd877afa	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:53:53.386021+00	2026-04-10 16:53:53.386021+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
7a1f0588-42c9-4ed7-b0cc-dda4d61c1ac9	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:57:31.829704+00	2026-04-10 16:57:31.829704+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
b0a04083-52c0-4b16-ac5f-5137c6f35435	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 16:58:39.928393+00	2026-04-10 16:58:39.928393+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
8adb3c8c-c1df-46d9-9fba-6a702ba63673	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 17:00:12.523904+00	2026-04-10 17:00:12.523904+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
3c59e60d-0e4e-434a-8d0a-c67568aaa9a2	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 17:02:12.793753+00	2026-04-10 17:02:12.793753+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
e0e538cc-501f-4f38-a4df-9ac0934133cd	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 17:03:09.246095+00	2026-04-10 17:03:09.246095+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
7eb67265-79da-431d-80ed-b72cdfa306ce	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 17:03:24.181093+00	2026-04-10 17:03:24.181093+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
2d2eb69b-0c14-456e-af5c-99e14821b375	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 17:05:43.199983+00	2026-04-10 17:05:43.199983+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
3696f9e7-75a6-4c4b-97d0-1e3bd5ac8efb	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 17:06:18.041866+00	2026-04-10 17:06:18.041866+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
934b3b8f-095f-4735-962e-519807375bbb	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 17:06:20.494268+00	2026-04-10 17:06:20.494268+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
0956f384-ebca-4f45-adee-3638724d8068	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-10 17:07:23.745152+00	2026-04-10 17:07:23.745152+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
9508a15a-2a02-4fcc-b1e3-d759774a66b2	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 07:09:34.359245+00	2026-04-11 07:09:34.359245+00	\N	aal1	\N	\N	node	203.205.33.15	\N	\N	\N	\N	\N
f64f8e7b-1e2d-4e27-9616-501eff3d829f	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-10 17:10:26.451825+00	2026-04-11 09:03:52.427839+00	\N	aal1	\N	2026-04-11 09:03:52.427737	Dart/3.10 (dart:io)	171.224.113.33	\N	\N	\N	\N	\N
3db53a0e-f2c4-4617-bbc4-873fbf4b7aa4	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-11 09:06:31.38417+00	2026-04-11 09:06:31.38417+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	171.224.113.33	\N	\N	\N	\N	\N
6692f176-23b7-40d4-8dda-ea5102a0920b	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-11 09:09:06.660285+00	2026-04-11 09:09:06.660285+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	171.224.113.33	\N	\N	\N	\N	\N
292fd353-81a9-4968-8bda-f3b5f3524d0a	ecebd763-797d-4b9f-beff-63f5044776fc	2026-04-11 09:12:12.337336+00	2026-04-11 09:12:12.337336+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
2694f434-2df6-4043-97bf-a1a023e92ce9	ecebd763-797d-4b9f-beff-63f5044776fc	2026-04-11 09:16:14.684389+00	2026-04-11 09:16:14.684389+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
07e8acc3-cc9f-4757-8c4f-cac1a466718e	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 09:30:06.56254+00	2026-04-11 09:30:06.56254+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
10312692-65ed-46a9-9dc2-f813263e3ef7	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 09:30:06.562446+00	2026-04-11 09:30:06.562446+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
e60f3551-c451-46e9-aa93-d0f832eca2da	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 09:30:06.772123+00	2026-04-11 09:30:06.772123+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
1c28a564-15eb-4e6b-a8e8-c60ebf05bd78	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 09:34:34.68456+00	2026-04-11 09:34:34.68456+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
59ba7115-3cea-42ad-83a0-5846056f418a	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 10:17:53.748173+00	2026-04-11 10:17:53.748173+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
003b3965-9930-46ff-8f8c-ab568e15448b	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-11 09:09:54.936056+00	2026-04-14 12:20:54.466099+00	\N	aal1	\N	2026-04-14 12:20:54.465985	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
ef245e24-09ef-423b-bf83-385d36e80a52	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 10:53:52.693864+00	2026-04-11 10:53:52.693864+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
ad859007-f70b-478c-be93-452ed49c300e	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 11:55:49.227549+00	2026-04-11 11:55:49.227549+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
55b9ff8f-6aca-40c1-8e7e-3957bb09be0c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-11 12:51:38.688592+00	2026-04-11 12:51:38.688592+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
06b2ceac-a05a-4017-ac6d-ec15345efb19	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 13:03:49.758383+00	2026-04-11 13:03:49.758383+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
3f14eb88-e31a-4fb2-ae11-3fed723df711	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-11 13:31:08.621856+00	2026-04-11 13:31:08.621856+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
f8d90d41-2fb4-43bd-a606-bd1d33a1c7b4	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-11 13:40:01.457385+00	2026-04-11 13:40:01.457385+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
ae92d4d9-9950-4674-a655-106d46666883	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-11 13:45:14.300227+00	2026-04-11 13:45:14.300227+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
474689b1-275b-49b1-912c-f8e282c019e4	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-11 13:51:22.106809+00	2026-04-11 13:51:22.106809+00	\N	aal1	\N	\N	node	171.232.68.33	\N	\N	\N	\N	\N
520684cd-cd01-47e3-b0cc-c09cfee2d2e8	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-11 13:56:34.593022+00	2026-04-11 13:56:34.593022+00	\N	aal1	\N	\N	node	42.116.172.137	\N	\N	\N	\N	\N
e032c352-7dad-4a60-9757-6da3b36f87aa	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-13 03:48:39.980182+00	2026-04-13 03:48:39.980182+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
bac8d93a-d73f-4e62-a520-346f3e3ffea5	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-13 11:20:00.930791+00	2026-04-13 11:20:00.930791+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
fda68434-192d-4b25-bbc6-aec0a0b8d19d	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-13 13:54:01.833992+00	2026-04-13 13:54:01.833992+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
19004738-5909-4cde-8365-ac413d966b6c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-13 14:05:30.267921+00	2026-04-13 14:05:30.267921+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
9ef6999a-c45f-4bf8-98e6-eb97688030c2	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-13 14:06:17.908365+00	2026-04-13 14:06:17.908365+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
a2ba4e36-3153-481f-a290-515205ea36bd	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-13 14:08:22.385262+00	2026-04-13 14:08:22.385262+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
ad494a33-0e49-4e91-839c-d99239a4edf4	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-14 05:57:59.989091+00	2026-04-14 05:57:59.989091+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
512cc0a7-aa75-4029-a2e7-60c8439acd1b	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-14 06:07:16.567994+00	2026-04-14 06:07:16.567994+00	\N	aal1	\N	\N	node	14.186.236.232	\N	\N	\N	\N	\N
301021e1-45b8-4126-80db-0a80c542f57b	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-14 12:36:46.067864+00	2026-04-14 12:36:46.067864+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
60f0333f-7c0d-49f5-abc4-d79ef8ccd579	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-14 12:38:55.726298+00	2026-04-14 12:38:55.726298+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
2257693b-1afe-4371-8279-b418139efb66	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-14 12:39:15.168949+00	2026-04-14 12:39:15.168949+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
64c80928-9861-4d0b-8cb7-5840abab701c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-14 12:59:51.854091+00	2026-04-14 12:59:51.854091+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
ec07e553-53f0-46a4-8be7-2000403f6880	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-25 08:05:52.892723+00	2026-04-25 08:05:52.892723+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
6603ed2f-67dc-4878-9a39-14611d383f0a	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-14 15:21:58.471688+00	2026-04-14 15:21:58.471688+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
04077440-648c-46ff-8d3e-91db2d139df6	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-14 15:36:23.428924+00	2026-04-14 15:36:23.428924+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
6d6f187d-0a97-4b20-b42f-db786b8806a0	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-25 08:51:17.124846+00	2026-04-25 08:51:17.124846+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
20ee1434-65ec-4218-b286-57cd2deba9ff	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-26 07:51:19.215253+00	2026-04-26 07:51:19.215253+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
400a2425-c85d-4496-86f2-c5f3a8c5e173	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-26 09:04:45.851135+00	2026-04-26 09:04:45.851135+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
9ee7992c-859a-454e-b3b7-ae938f59897f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-26 09:54:59.195699+00	2026-04-26 09:54:59.195699+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
7f2c308f-dec8-439f-aad0-3398795292a5	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-14 12:43:09.358824+00	2026-04-17 10:11:36.396831+00	\N	aal1	\N	2026-04-17 10:11:36.396724	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
134767f5-c810-439c-a555-fab0dd2b6c8f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-17 10:13:19.135244+00	2026-04-17 10:13:19.135244+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
bbf42b3c-9c63-4b78-9c4c-2329e8fd1c6e	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-04-17 10:12:59.057757+00	2026-04-17 11:26:55.253099+00	\N	aal1	\N	2026-04-17 11:26:55.252988	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
c71f1c13-f6ea-4b1f-a4cf-16bc7fa0fd85	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-17 11:27:35.170783+00	2026-04-17 11:27:35.170783+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
bbccc945-19f6-4ffd-8607-3bf905e083e3	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-17 12:06:03.985468+00	2026-04-17 12:06:03.985468+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
aa203841-80bd-43cc-9173-5746b29433b8	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-26 15:50:14.909943+00	2026-04-26 15:50:14.909943+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
f20e91a2-ab5a-44ae-9f2f-8224659364a6	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-26 16:09:28.834811+00	2026-04-26 16:09:28.834811+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
15a87b72-219f-4a9f-baac-230af6e36039	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-22 09:06:12.682489+00	2026-04-22 09:06:12.682489+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
de953c7b-1d6c-4ce7-9781-f9095836ec07	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:08:58.744136+00	2026-04-23 04:08:58.744136+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
43c74528-18ca-4519-9aeb-f06147467b38	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:08:59.07245+00	2026-04-23 04:08:59.07245+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
1cad9c4a-87dc-4a5e-ab8e-4c2dec41487b	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:18:30.753532+00	2026-04-23 04:18:30.753532+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
866d904d-d838-43b8-9947-350497ff3b98	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:32:48.725787+00	2026-04-23 04:32:48.725787+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
522c813d-8c54-4b54-9809-b13cf8be9826	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:34:21.887948+00	2026-04-23 04:34:21.887948+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
ed7b6210-1e89-4b93-9987-c8524f8c2a95	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:36:34.73161+00	2026-04-23 04:36:34.73161+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
142fed24-3fd1-436a-9d89-d0822e88f5a8	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:47:21.114105+00	2026-04-23 04:47:21.114105+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
e3708d9a-b8a4-46ab-8f43-ed369693b9a2	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:47:21.229905+00	2026-04-23 04:47:21.229905+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
ae64e15d-6d2a-4623-8c09-8c4727b19112	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:54:58.104789+00	2026-04-23 04:54:58.104789+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
0d3666d1-4386-464d-b736-6009559e0328	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:58:58.94592+00	2026-04-23 04:58:58.94592+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
82ddf6b8-e582-4e63-892d-5c18edcfacce	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:59:58.327103+00	2026-04-23 04:59:58.327103+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
f499267d-7e1d-4916-9edf-9066996bdc27	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 04:59:58.708087+00	2026-04-23 04:59:58.708087+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
ec960bb7-ead4-42af-ae91-33c3e05ff0aa	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 05:06:07.914972+00	2026-04-23 05:06:07.914972+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
708f8bf8-89ab-448d-95c6-caa12a894a3a	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 05:07:54.476535+00	2026-04-23 05:07:54.476535+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
f36230c8-dc1a-4882-962d-10b3d099045a	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 05:07:55.066928+00	2026-04-23 05:07:55.066928+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
e29606d5-f536-4d2f-9fae-39dbe5ba2d67	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 05:16:16.480633+00	2026-04-23 05:16:16.480633+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
450c3154-d86b-458c-8de6-cec1c3c4c72d	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 05:19:33.296118+00	2026-04-23 05:19:33.296118+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
789a758a-becd-4e6b-bae3-91a90ed35d74	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 05:20:29.203157+00	2026-04-23 05:20:29.203157+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
1cdc98b7-6bca-4b85-8577-0fedfcd5479d	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 06:20:33.134387+00	2026-04-23 06:20:33.134387+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
3e636757-f459-4475-81ec-a9acc46912fe	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 06:30:14.122635+00	2026-04-23 06:30:14.122635+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
6e129402-ff18-45de-8c4b-d4db15e4d9f2	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 06:32:03.688702+00	2026-04-23 06:32:03.688702+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
7f600af5-fd5e-46d7-a357-0d2aacc833b5	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-23 07:41:23.293481+00	2026-04-23 07:41:23.293481+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
837f156c-e13e-4c6b-a65c-b9521fc036b6	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-25 07:11:22.075779+00	2026-04-25 07:11:22.075779+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
30afd630-1eb3-4d12-bab5-72efc3aa6fc5	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-25 07:20:18.082226+00	2026-04-25 07:20:18.082226+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
1e7c37a9-acd1-4514-b246-9bccbd131e9c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-25 07:21:57.995157+00	2026-04-25 07:21:57.995157+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
93183258-df1a-4289-ac1e-3a93cc3cee38	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-25 07:22:13.486593+00	2026-04-25 07:22:13.486593+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
61b300dc-c5fd-480d-be95-bd3c34e65722	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-25 07:26:07.808373+00	2026-04-25 07:26:07.808373+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
2497a9b2-5060-4936-aa07-3e3a875a4df1	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-25 07:26:52.512332+00	2026-04-25 07:26:52.512332+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
59547bab-e551-45b8-b459-dee61fe3180c	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-25 07:28:19.209111+00	2026-04-25 07:28:19.209111+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
2e917f3f-e275-4a33-87ef-80fa832b198a	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-25 07:44:09.362932+00	2026-04-25 07:44:09.362932+00	\N	aal1	\N	\N	node	118.69.12.160	\N	\N	\N	\N	\N
cf005b5b-240c-4817-a1dd-e1a94262e0cc	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-25 07:45:34.800396+00	2026-04-25 07:45:34.800396+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
199e2056-5d90-4ce5-9aa7-11d5f59b5668	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-26 16:10:08.853294+00	2026-04-26 16:10:08.853294+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
cf3f4c69-64a9-471b-8f22-39f79acccb6f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-26 16:38:36.222692+00	2026-04-26 16:38:36.222692+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
40a3fd43-4ae9-44bb-92bc-60ee9c38c0f9	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-27 07:32:16.097704+00	2026-04-27 07:32:16.097704+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
8af31811-1f63-482e-bafb-347aca143299	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-27 07:33:46.579724+00	2026-04-27 07:33:46.579724+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
62d42694-f59f-4410-a26a-7c8ede8dc3ed	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-27 07:49:20.652572+00	2026-04-27 07:49:20.652572+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
ff711ff8-0c2f-47c7-91f8-a87609860615	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-27 08:22:50.719377+00	2026-04-27 08:22:50.719377+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
e9618869-24d6-4a54-a65d-f79d05bf86c4	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-27 08:34:12.472257+00	2026-04-27 08:34:12.472257+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
1cbf971e-ee8e-4b64-bc57-bd0179738cc0	c6ad1e17-f6f1-4229-8580-b00e595c3050	2026-04-27 16:26:39.22639+00	2026-04-27 16:26:39.22639+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
05fdcbb8-7bd1-4b03-a9d0-9209fbff7043	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-27 16:28:05.002053+00	2026-04-27 16:28:05.002053+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
1cdd067d-162b-43af-ad75-9816962f9949	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-27 17:47:19.036142+00	2026-04-27 17:47:19.036142+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
2b072cf8-3998-4c14-83e8-4284faffc351	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-27 18:11:05.281867+00	2026-04-27 18:11:05.281867+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
e2319ddd-38f2-4be8-ae50-0314cd6056ec	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-27 19:16:29.136901+00	2026-04-27 19:16:29.136901+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
9f7d3b81-fae5-45ea-994e-5f05bc01521a	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-28 14:00:38.726547+00	2026-04-28 14:00:38.726547+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
7641547c-c648-402f-a9a9-43025fd40763	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-28 14:36:38.135805+00	2026-04-28 14:36:38.135805+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
5191d1f1-cb05-4eaf-833a-0edf35c35f8d	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-04-28 14:38:36.570841+00	2026-04-28 14:38:36.570841+00	\N	aal1	\N	\N	node	42.116.178.126	\N	\N	\N	\N	\N
ae7f4174-8a0f-44bc-b540-88e7f86e4ea7	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-30 15:26:22.398255+00	2026-04-30 15:26:22.398255+00	\N	aal1	\N	\N	node	14.191.63.79	\N	\N	\N	\N	\N
8bcc60ba-6d73-41f1-98d3-2733814e470e	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-04-30 17:44:16.538081+00	2026-04-30 17:44:16.538081+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
742e7725-6094-4cf8-9a5b-cd5d942d1e04	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 01:20:21.582146+00	2026-05-01 01:20:21.582146+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
f42ca4bb-08d5-411d-96f2-7391c3afbd46	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 02:02:42.910355+00	2026-05-01 02:02:42.910355+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
8fffaf74-714c-414b-a594-74ddf9741101	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 06:20:34.720548+00	2026-05-01 06:20:34.720548+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
bfb580a2-9591-4653-ab7a-2e4c5fa6afe3	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 06:48:27.083871+00	2026-05-01 06:48:27.083871+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
782335c8-92d6-4b46-ba89-8b81eb4be51c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 07:01:52.820476+00	2026-05-01 07:01:52.820476+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
81ea8cdf-d813-4dc3-8a59-05cacdb7d098	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 07:07:18.341163+00	2026-05-01 07:07:18.341163+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
6d5696e0-1092-4d21-bb85-5084d80704e4	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 08:19:58.209658+00	2026-05-01 08:19:58.209658+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
6d4dfaec-07d8-4ce8-8f02-b29366a4b1da	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 09:06:19.719351+00	2026-05-01 09:06:19.719351+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
962c4531-eb5a-42b0-b95d-b9c1365d8c8f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 09:10:46.094433+00	2026-05-01 09:10:46.094433+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
e6a3f828-1bde-44ab-b5fe-24bb16c98be0	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-05-01 13:06:45.381517+00	2026-05-01 13:06:45.381517+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
1997b91d-e471-4d0d-a2bb-df5fe442c36c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 14:19:55.856155+00	2026-05-01 14:19:55.856155+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
3b9d0ec0-36d0-4a25-b018-c235f9a93629	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-01 14:27:08.735337+00	2026-05-01 14:27:08.735337+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
8a8da4c8-0118-4a9f-bb1f-a0cad1ce1daf	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-02 09:56:07.435435+00	2026-05-02 09:56:07.435435+00	\N	aal1	\N	\N	node	14.191.63.79	\N	\N	\N	\N	\N
383bed75-5c57-4a04-9303-3a8b0567ab3c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-02 10:10:14.531903+00	2026-05-02 10:10:14.531903+00	\N	aal1	\N	\N	node	14.191.63.79	\N	\N	\N	\N	\N
39a139b2-624e-456c-874f-5c711b37838e	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-05-02 11:40:59.141117+00	2026-05-02 11:40:59.141117+00	\N	aal1	\N	\N	node	14.191.63.79	\N	\N	\N	\N	\N
fb85bd44-f69b-4a13-98dc-6321840f5007	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-05-02 12:01:20.612313+00	2026-05-02 12:01:20.612313+00	\N	aal1	\N	\N	node	14.191.63.79	\N	\N	\N	\N	\N
d3d07b39-f66f-4443-a112-5a4f1c8e56fc	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-05-02 16:07:12.386635+00	2026-05-02 16:07:12.386635+00	\N	aal1	\N	\N	node	14.191.63.79	\N	\N	\N	\N	\N
cddf1de4-bbaa-4abd-bcc8-af2d17435e06	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-05-02 16:10:29.179375+00	2026-05-02 16:10:29.179375+00	\N	aal1	\N	\N	node	14.191.63.79	\N	\N	\N	\N	\N
0acc2bf0-119b-4927-a968-f2b7ce0c52f7	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-05-04 10:26:54.661336+00	2026-05-04 10:26:54.661336+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
3b46e5a8-cbc9-43a4-a63c-89698fdd0fb4	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 10:29:01.841975+00	2026-05-04 10:29:01.841975+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
22b18105-79b2-4147-9b54-2c96a5fbc748	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 11:06:17.633151+00	2026-05-04 11:06:17.633151+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
4f08a901-8d1e-4112-9c15-808ebedfb9c2	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 11:09:55.469651+00	2026-05-04 11:09:55.469651+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
26d1ef9f-4ac7-4d4e-baf0-0321d422a933	b326f22a-02fc-4d99-bce9-6c933113a7a0	2026-05-04 11:17:38.768073+00	2026-05-04 11:17:38.768073+00	\N	aal1	\N	\N	Dart/3.10 (dart:io)	123.21.36.243	\N	\N	\N	\N	\N
18955def-8aef-4bff-bacc-42e47501b39d	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 11:22:20.471393+00	2026-05-04 11:22:20.471393+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
9aa95227-cb72-4ac8-ae6b-1ce60dbf0cbc	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 12:50:29.673552+00	2026-05-04 12:50:29.673552+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
271ee288-b483-4e81-b696-f7ba1a92d95f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:12:47.660124+00	2026-05-04 13:12:47.660124+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
bf0fd37f-0fa9-4edd-bf7d-9765348598ce	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:16:37.490135+00	2026-05-04 13:16:37.490135+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
0a561128-767e-486e-8ad4-708497c76b3f	ca38c166-41e5-4f9d-b14a-caa71d08be01	2026-05-04 13:19:29.409902+00	2026-05-04 13:19:29.409902+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
784695ac-1358-445f-92b1-ff40b95305b1	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:22:52.274435+00	2026-05-04 13:22:52.274435+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
9e5ff786-e71b-4194-a2cd-84a597343d8a	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:28:19.599846+00	2026-05-04 13:28:19.599846+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
a5faaf51-7136-4bd4-93e6-1976a525a986	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:31:23.349853+00	2026-05-04 13:31:23.349853+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
b508f14d-e413-4a16-a855-f83c2848fcef	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:36:10.074389+00	2026-05-04 13:36:10.074389+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
9aa136a9-8f95-4cff-b636-ef5833db697c	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:37:34.735849+00	2026-05-04 13:37:34.735849+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
6eccbdc1-253f-4634-a0ff-fe3a0d05985a	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:39:14.819346+00	2026-05-04 13:39:14.819346+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
3db5d471-14d4-4740-b317-36e5310b6127	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:39:34.778126+00	2026-05-04 13:39:34.778126+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
9fd983ef-6082-4532-ac21-aeff8cf8529b	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:42:21.571059+00	2026-05-04 13:42:21.571059+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
55ea2531-9642-4600-a2c2-ac42cf20fd29	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:44:06.444623+00	2026-05-04 13:44:06.444623+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
d66310fb-a991-47a0-9b56-92182d261438	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:49:56.862063+00	2026-05-04 13:49:56.862063+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
406eee40-0460-4967-835b-3a0c698de3c0	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:56:19.010455+00	2026-05-04 13:56:19.010455+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
91a2d06e-b4fc-4758-99c5-7ff4044c354f	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:57:42.538295+00	2026-05-04 13:57:42.538295+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
9534a5a0-4a59-4509-8219-b7b423e78f45	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 13:58:33.843274+00	2026-05-04 13:58:33.843274+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
6efa0733-afd7-4fd9-a1b6-1a81b2a950b1	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:01:31.839816+00	2026-05-04 14:01:31.839816+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
156740f7-41a1-49b7-8720-5fd84ced4089	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:06:18.652466+00	2026-05-04 14:06:18.652466+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
ea062a4b-fc3e-4deb-a2c3-f7b9d616d25a	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:07:07.273861+00	2026-05-04 14:07:07.273861+00	\N	aal1	\N	\N	node	14.186.240.244	\N	\N	\N	\N	\N
5f184909-fe5c-4fc1-ad7a-486d3b3e9c89	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:13:25.534294+00	2026-05-04 14:13:25.534294+00	\N	aal1	\N	\N	node	42.116.73.204	\N	\N	\N	\N	\N
85566771-04bc-4947-ad48-3bb5192e30a5	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:25:28.727163+00	2026-05-04 14:25:28.727163+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
2735619f-7862-47d2-a1f3-73386e4cdb61	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:27:32.84882+00	2026-05-04 14:27:32.84882+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
cb2aed6f-5bec-4cb8-a18b-6fe17900bd18	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:34:06.99668+00	2026-05-04 14:34:06.99668+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
16c8d526-de6c-4e64-a752-5bd21fac4d64	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:39:04.287149+00	2026-05-04 14:39:04.287149+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
f2d9cadb-4971-4305-a788-14b15222ab44	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:41:19.57767+00	2026-05-04 14:41:19.57767+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
0da322a3-9ddd-4d84-9976-c7d5cb5aea74	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 14:09:04.466019+00	2026-05-04 15:07:07.249363+00	\N	aal1	\N	2026-05-04 15:07:07.247009	node	14.186.240.244	\N	\N	\N	\N	\N
f473ec2e-6b3e-47be-9991-1876f4663cf8	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 15:09:23.597807+00	2026-05-04 15:09:23.597807+00	\N	aal1	\N	\N	node	42.116.73.204	\N	\N	\N	\N	\N
273540f7-359b-498f-a51d-6cd362c9c412	5f56692b-8daa-4852-bfe7-1032a07635ff	2026-05-04 15:21:31.5087+00	2026-05-04 15:21:31.5087+00	\N	aal1	\N	\N	node	123.21.36.243	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
00000000-0000-0000-0000-000000000000	c6ad1e17-f6f1-4229-8580-b00e595c3050	authenticated	authenticated	khanhhanpham88+a1@gmail.com	$2a$10$gsJPygsfm2zK16vEt.UFk.WC2s/fZFCZ/zpLcrsy52B.Ce3VFLKnS	2026-03-28 08:47:30.156902+00	\N		\N		\N			\N	2026-04-27 16:26:39.226292+00	{"provider": "email", "providers": ["email"]}	{"sub": "c6ad1e17-f6f1-4229-8580-b00e595c3050", "role": "BUSINESS", "email": "khanhhanpham88+a1@gmail.com", "full_name": "Kim Seok Jin", "phone_number": "0123123123", "email_verified": true, "phone_verified": false}	\N	2026-03-28 08:47:30.09217+00	2026-04-27 16:26:39.287371+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c48465fb-520d-445f-b8cc-e8f08c1b8a38	authenticated	authenticated	nve@gmail.com	$2a$10$XpOs5aM6Tj7vp/aDW.XVhuCsYD89MSQ3I3jGGstewgpGDERgA8jAC	2026-04-01 14:23:32.982613+00	\N		\N		\N			\N	2026-04-08 02:21:18.917075+00	{"provider": "email", "providers": ["email"]}	{"role": "TOURIST", "status": "ACTIVE", "full_name": "Nguyễn Văn E", "phone_number": "1231231231", "email_verified": true}	\N	2026-04-01 14:23:32.973376+00	2026-04-08 02:21:18.948556+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	10f4c984-9b5d-46dd-8d98-00573752f50a	authenticated	authenticated	nvc@gmail.com	$2a$10$HQy9HAM938M1DQfiIIfhYeAoEL6now8qN.SQHYAY2og.mKhlG5KGK	2026-03-27 16:58:06.886722+00	\N		\N		\N			\N	2026-04-09 21:42:01.385418+00	{"provider": "email", "providers": ["email"]}	{"sub": "10f4c984-9b5d-46dd-8d98-00573752f50a", "role": "BUSINESS", "email": "nvc@gmail.com", "full_name": "Nguyễn Văn C", "phone_number": "0912345670", "email_verified": true, "phone_verified": false}	\N	2026-03-27 16:58:06.751264+00	2026-04-09 21:42:01.452653+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b7ea8833-6fff-4302-8d1b-4424676cb299	authenticated	authenticated	nva@gmail.com	$2a$10$CO4s3sBBedj4OZ0dNLkqOuThd5GJZMOu1yLd3QpH9tJiafe9uOENa	2026-03-28 08:31:55.109359+00	\N		\N		\N			\N	2026-04-05 09:08:17.914347+00	{"provider": "email", "providers": ["email"]}	{"sub": "b7ea8833-6fff-4302-8d1b-4424676cb299", "role": "BUSINESS", "email": "nva@gmail.com", "full_name": "Nguyễn Văn A", "phone_number": "0912345678", "email_verified": true, "phone_verified": false}	\N	2026-03-28 08:31:55.067676+00	2026-04-05 09:08:17.963261+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5f56692b-8daa-4852-bfe7-1032a07635ff	authenticated	authenticated	h@gmail.com	$2a$10$GuQcWpnQvCvQn0vHTMZOwuUxA9qOUq19xSUGRYF4xwyfY7zrHCgRO	2026-03-28 08:05:30.674091+00	\N		\N		\N			\N	2026-05-04 15:21:31.508099+00	{"provider": "email", "providers": ["email"]}	{"sub": "5f56692b-8daa-4852-bfe7-1032a07635ff", "role": "TOURIST", "email": "h@gmail.com", "gender": "MALE", "full_name": "Nguyễn Văn B", "phone_number": "0987654321", "email_verified": true, "phone_verified": false}	\N	2026-03-28 08:05:30.563233+00	2026-05-04 15:21:31.557893+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	353b8afb-61a8-4233-96dd-480e99a0ff83	authenticated	authenticated	knjoon@gmail.com	$2a$10$bHujR8IBqVnEstoJ03fVA.dHvCSiEhRGLc9A.kXPV5sshDxISY2Xa	2026-03-30 17:34:26.049425+00	\N		\N		\N			\N	2026-04-10 14:41:21.81081+00	{"provider": "email", "providers": ["email"]}	{"role": "TOURIST", "status": "ACTIVE", "full_name": "Kim Nam Joon", "phone_number": "0123456789", "email_verified": true}	\N	2026-03-30 17:34:26.010551+00	2026-04-10 14:41:21.844344+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ca38c166-41e5-4f9d-b14a-caa71d08be01	authenticated	authenticated	admin@gmail.com	$2a$10$NcqbDwWL9WepwOUoDuIh7uloqxGU1356zSJZRhgaROCiH7mvjACeS	2026-03-28 09:21:47.261888+00	\N		\N		\N			\N	2026-05-04 13:19:29.409799+00	{"provider": "email", "providers": ["email"]}	{"sub": "ca38c166-41e5-4f9d-b14a-caa71d08be01", "role": "ADMIN", "email": "admin@gmail.com", "full_name": "Trần Quản Trị", "avatar_url": "https://api.dicebear.com/7.x/avataaars/svg?seed=Admin", "phone_number": "0901234567", "email_verified": true, "phone_verified": false}	\N	2026-03-28 09:21:47.221631+00	2026-05-04 13:19:29.456066+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c7910199-028e-4d56-b029-aeb553d977d0	authenticated	authenticated	acd@gmail.com	$2a$10$pZENc0MyZNavwnrddzaToetxKWZZ8ypssX4a3dFdcDs.DUVatG7DO	2026-04-01 14:23:11.217633+00	\N		\N		\N			\N	2026-04-09 14:52:35.273754+00	{"provider": "email", "providers": ["email"]}	{"role": "TOURIST", "status": "ACTIVE", "full_name": "Nguyễn Văn D", "phone_number": "1231231231", "email_verified": true}	\N	2026-04-01 14:23:11.17486+00	2026-04-09 14:52:35.29727+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	authenticated	authenticated	tourist@gmail.com	$2a$10$3x1cQ/.18BDFsOo2F2s1h.ThENJHuorV9zal8XCmUNroDGEqIUHF6	2026-03-28 16:48:02.229446+00	\N		\N		\N			\N	2026-04-09 16:00:15.615156+00	{"provider": "email", "providers": ["email"]}	{"sub": "20172a2f-f0a1-4449-be0a-75b7cd50f5a3", "role": "TOURIST", "email": "tourist@gmail.com", "gender": "MALE", "full_name": "Nguyễn Văn B", "phone_number": "0987654321", "email_verified": true, "phone_verified": false}	\N	2026-03-28 16:48:02.19085+00	2026-04-09 16:00:15.652958+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9a54cb41-ee7d-417e-9563-9fb95a35c29c	authenticated	authenticated	delete@gmail.com	$2a$10$PIscHgAmJhqhKLLM0Sz7CevYjxBmTSnlf8uFbIuR//HFPJz2uLxDe	2026-03-30 14:21:19.798656+00	\N		\N		\N			\N	2026-03-30 14:21:19.826635+00	{"provider": "email", "providers": ["email"]}	{"sub": "9a54cb41-ee7d-417e-9563-9fb95a35c29c", "role": "TOURIST", "email": "delete@gmail.com", "gender": "MALE", "full_name": "Nguyễn Văn B", "phone_number": "0987654321", "email_verified": true, "phone_verified": false}	\N	2026-03-30 14:21:19.671281+00	2026-03-30 15:19:41.783092+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f1723551-793e-40ee-9996-853d1cfc04cc	authenticated	authenticated	abbcc@gmail.com	$2a$10$eBmzTu3tRzSbhLQEOS2l0ObjXTP4whAtmqs2F0L7fsXzNS5VO8Mk.	2026-04-01 14:21:35.018462+00	\N		\N		\N			\N	2026-04-03 17:12:04.685513+00	{"provider": "email", "providers": ["email"]}	{"role": "BUSINESS", "status": "ACTIVE", "full_name": "Nguyễn Văn C", "phone_number": "1231231231", "email_verified": true}	\N	2026-04-01 14:21:34.938557+00	2026-04-03 17:12:04.723627+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	93c230f3-cef1-46eb-8289-4bc66ec565ea	authenticated	authenticated	myoongi@gmail.com	$2a$10$a6ozWYwH/Smo69Yax2Hpu.DAzlxPbd0M7WUma3oSw7KL6Y6yW6Gw6	2026-04-01 16:33:00.231867+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "BUSINESS", "status": "ACTIVE", "full_name": "Min Yoongi", "phone_number": "1234567891", "email_verified": true}	\N	2026-04-01 16:33:00.199454+00	2026-04-01 16:33:00.233207+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	0f32ae0f-8c18-4b34-8f38-47e40a4bf11a	authenticated	authenticated	tvh@gmail.com	$2a$10$PgNPB11Ds.567x/O33kmS.6bEHH/KR2FVbhLTq0dv0.oQ69ieIcCG	2026-04-05 09:28:15.863348+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "TOURIST", "status": "ACTIVE", "full_name": "Trần Văn H", "avatar_url": "", "phone_number": "0987123125", "email_verified": true}	\N	2026-04-05 09:28:15.794977+00	2026-04-05 09:28:15.864869+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	da3d14e6-04c0-49a0-b029-901ace58b562	authenticated	authenticated	tva@gmail.com	$2a$10$qHAiB.Y4QDxGTYjfbFRE6eCzvTLCEcv/1MyKZzVIaNo7nh2MrfXrK	2026-04-05 09:01:37.810226+00	\N		\N		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{"role": "TOURIST", "status": "ACTIVE", "full_name": "Trần Văn A", "phone_number": "0986723724", "email_verified": true}	\N	2026-04-05 09:01:37.721148+00	2026-04-05 09:01:37.821531+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	d2b3704a-f14e-47ad-a8e4-8a7fa617f32a	authenticated	authenticated	tvd@gmail.com	$2a$10$3mMcm4B67YnhcCbj5ln4GOxBmYu7L/Gbnsva0w7.IfayfKq1UHJay	2026-04-05 09:20:54.428521+00	\N		\N		\N			\N	2026-04-08 15:11:23.174706+00	{"provider": "email", "providers": ["email"]}	{"role": "BUSINESS", "status": "ACTIVE", "full_name": "Trần Văn D ", "avatar_url": "blob:http://localhost:5173/174f206e-d559-433b-ba1d-6275930648cd", "phone_number": "0987123124", "email_verified": true}	\N	2026-04-05 09:20:54.352338+00	2026-04-08 15:11:23.222344+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	18640b2a-bb98-428b-b4a7-6a3ec8301794	authenticated	authenticated	phamkhanhhan6@gmail.com	$2a$10$Uvn/GnVPRlcJql96SbgJFe/hjbr4rdfbIiKPg3KzT5ZIkVNeJuJ9e	2026-04-09 14:37:26.738706+00	\N		\N		\N			\N	2026-04-09 14:40:15.049225+00	{"provider": "google", "providers": ["google"]}	{"iss": "https://accounts.google.com", "sub": "102365804487603265827", "name": "Khánh Hân Phạm", "role": "TOURIST", "email": "phamkhanhhan6@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIgq9DDJgtxSbjeSXhxFlsgjMIj4YKfPQyvsHtmaPH1rRtq9A=s96-c", "full_name": "Khánh Hân Phạm", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIgq9DDJgtxSbjeSXhxFlsgjMIj4YKfPQyvsHtmaPH1rRtq9A=s96-c", "provider_id": "102365804487603265827", "email_verified": true, "phone_verified": false}	\N	2026-04-09 14:37:26.62689+00	2026-04-09 14:40:15.311232+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ecebd763-797d-4b9f-beff-63f5044776fc	authenticated	authenticated	hanhspring007@gmail.com	$2a$10$VF0RyQbcVaPXCQgLGcs1FecU.dLbLvEwi9DZCdRoungg3/ukB88bu	2026-04-11 09:12:12.327388+00	\N		\N		\N			\N	2026-04-11 09:16:14.681593+00	{"provider": "email", "providers": ["email"]}	{"sub": "ecebd763-797d-4b9f-beff-63f5044776fc", "role": "TOURIST", "email": "hanhspring007@gmail.com", "gender": "MALE", "full_name": "Nguyễn Xuân Kiểm", "phone_number": "0973973266", "email_verified": true, "phone_verified": false}	\N	2026-04-11 09:12:12.228814+00	2026-04-11 09:16:14.711049+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b326f22a-02fc-4d99-bce9-6c933113a7a0	authenticated	authenticated	hanhtyr@gmail.com	\N	2026-04-10 16:12:41.827378+00	\N		\N		\N			\N	2026-05-04 11:17:38.767894+00	{"provider": "google", "providers": ["google"]}	{"iss": "https://accounts.google.com", "sub": "101386552149340484598", "name": "Nguyễn Xuân Hạnh", "email": "hanhtyr@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIzzuu4QEflTYLsQlBhwXoJlaX2lQa1PR9_kX5LVlb7DP7tek0e=s96-c", "full_name": "Nguyễn Xuân Hạnh", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIzzuu4QEflTYLsQlBhwXoJlaX2lQa1PR9_kX5LVlb7DP7tek0e=s96-c", "provider_id": "101386552149340484598", "email_verified": true, "phone_verified": false}	\N	2026-04-10 16:12:41.789678+00	2026-05-04 11:17:38.832065+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_challenges (id, user_id, challenge_type, session_data, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, attestation_type, aaguid, sign_count, transports, backup_eligible, backed_up, friendly_name, created_at, updated_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.notifications (id, title, content, notification_type, status, created_at) FROM stdin;
64785e4d-34c8-4b61-8a2a-dfdce29bb1d3	Thông báo hệ thống	Chúng tôi vừa cập nhật thêm tính năng mới, hãy trải nghiệm nhé!	hệ thống	unread	2026-03-24 11:07:39.200466
\.


--
-- Data for Name: user_notifications; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.user_notifications (notification_id, user_id, sent_at) FROM stdin;
64785e4d-34c8-4b61-8a2a-dfdce29bb1d3	c5e3b943-1faf-4501-bc75-37cf8fa371cf	2026-03-24 11:08:31.522941
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.users (id, full_name, email, password_hash, gender, role, phone, is_active, created_at, preferences) FROM stdin;
4c0fca2b-66f9-47b7-9a3a-3ca407637833	Tran Thi B	tourist2@gmail.com	hash	\N	tourist	0900000002	t	2026-03-11 18:05:53.832055	\N
8812a3ee-5591-4831-9a7e-02a805d563b2	Vendor	vendor@mail.com	hash	\N	vendor	\N	t	2026-03-14 03:47:44.444636	\N
9d211bfb-1b83-4171-b547-830e83f4af8d	Nguyễn Văn A	a@gmail.com	hash	\N	tourist	\N	t	2026-03-14 05:43:47.394523	\N
4c9e8ec9-c00b-4a2c-8789-65fae4ca9374	Trần Thị B	b@gmail.com	hash	\N	tourist	\N	t	2026-03-14 05:43:47.394523	\N
1c255df5-51f2-4373-844e-7874647db729	Lê Minh C	c@gmail.com	hash	\N	tourist	\N	t	2026-03-14 05:43:47.394523	\N
8ae6c7b6-32d7-468b-a494-821af47d7a37	Phạm Thị D	d@gmail.com	hash	\N	tourist	0904444444	t	2026-03-14 06:05:20.404396	\N
c5e3b943-1faf-4501-bc75-37cf8fa371cf	Hoàng Văn E	e@gmail.com	hash	\N	tourist	0905555555	t	2026-03-14 06:05:20.404396	\N
8ce69380-20e6-43de-bf3c-7e765f761c0a	Nguyễn Văn A	vendora@gmail.com	hash	\N	vendor	0909999999	t	2026-03-14 06:24:21.219268	\N
2e5e77a8-a019-413b-8071-56ec0e3e67dc	Nguyễn Văn A	tourist@test.com	hash	\N	tourist	0908888888	t	2026-03-14 06:43:32.107047	\N
2c2caf9e-1fc9-4065-a280-45d8508458c7	Nguyen Van A	tourist1@gmail.com	hash	\N	tourist	0900000001	t	2026-03-11 18:05:53.832055	\N
81aae2ce-be40-42e7-b8ae-1ee9b6b37eb6	Coffee Vendor	vendor@gmail.com	123456	\N	vendor	0900000003	t	2026-03-11 18:05:53.832055	\N
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: extensions; Owner: -
--

COPY extensions.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: food_items; Type: TABLE DATA; Schema: order_sys; Owner: -
--

COPY order_sys.food_items (id, name, description, price, place_id, image_url, category, is_active, foody_dish_id, foody_dish_type_id) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: order_sys; Owner: -
--

COPY order_sys.order_items (id, quantity, unit_price, total_price, order_id, food_item_id) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: order_sys; Owner: -
--

COPY order_sys.orders (id, ordered_at, total_amount, status, notes, tourist_id, itinerary_detail_id) FROM stdin;
\.


--
-- Data for Name: businesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.businesses (id, identity_card, address, is_approved) FROM stdin;
b7ea8833-6fff-4302-8d1b-4424676cb299	012345678911	HCM	f
93c230f3-cef1-46eb-8289-4bc66ec565ea	\N	\N	f
f1723551-793e-40ee-9996-853d1cfc04cc	123123123123	\N	f
c6ad1e17-f6f1-4229-8580-b00e595c3050	012345678911	Quận 12, HCM	f
d2b3704a-f14e-47ad-a8e4-8a7fa617f32a	\N	\N	f
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, title, content, type, is_global, created_at) FROM stdin;
09a9206a-e36a-4ed4-97ad-a0efd666b668	Thông báo hệ thống	Chúng tôi vừa cập nhật thêm tính năng mới, hãy trải nghiệm nhé!	hệ thống	t	2026-04-07 15:20:46.630629+00
313d5794-8008-46d9-8c32-eeff6b1fda69	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu, chửi thề viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 11:22:44.397148+00
f1638251-7e1f-4fd9-9168-027e9fa4e074	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Sử dụng từ ngữ tục tĩu, xúc phạm (viết tắt cc)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 12:51:25.628303+00
1747eb82-689e-4a11-bbab-f58f31812ac8	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu, viết tắt phản cảm (cc)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 13:13:16.21313+00
a266d3a8-0926-4ede-b366-60fe91a9537d	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu, viết tắt nhạy cảm (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 13:24:14.559396+00
8ef57508-d209-4c1e-9729-fe798f3af235	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 13:28:56.258503+00
72127377-5bb8-47e3-bae4-6bc7250364f8	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 13:40:12.419105+00
97d755b3-634e-4a6b-853c-e2460786403a	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 13:59:58.698056+00
2a2ed56b-6c6b-425c-a94b-f84ab029fab4	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu, chửi thề (viết tắt cc)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 14:01:17.349046+00
2230886e-ede2-4f99-85de-168af6536f5a	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 14:01:53.943527+00
6398b25d-9892-4f3c-873c-b8a89bf368cd	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Sử dụng từ ngữ tục tĩu, viết tắt nhạy cảm (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 14:04:15.646205+00
03ae2d3e-1685-4ccd-b8db-3b8beeaaee38	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Sử dụng từ ngữ tục tĩu, chửi thề viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 14:28:10.041492+00
9d516206-b0c9-4d5e-a065-1808c077d844	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Sử dụng từ ngữ tục tĩu, viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 14:39:36.405289+00
d1300d67-ce7c-4f6b-8ec4-7f5724530db8	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu, chửi thề viết tắt (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 14:41:46.372027+00
fd0094c2-2402-4a50-8cc3-cd54d50fb55a	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Chứa từ ngữ tục tĩu, chửi thề (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 15:23:20.050607+00
10dd489a-d8cd-4d7b-87c6-34184dbc2d25	Đánh giá bị từ chối	Bình luận chuyến đi của bạn vi phạm tiêu chuẩn cộng đồng (Lý do: Sử dụng từ ngữ tục tĩu, viết tắt nhạy cảm (vcl)). Đánh giá sẽ không được hiển thị công khai.	review_rejected	f	2026-05-04 15:27:23.42884+00
\.


--
-- Data for Name: tourists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourists (id, gender, travel_preferences) FROM stdin;
5f56692b-8daa-4852-bfe7-1032a07635ff	FEMALE	{}
20172a2f-f0a1-4449-be0a-75b7cd50f5a3	MALE	{}
9a54cb41-ee7d-417e-9563-9fb95a35c29c	MALE	{}
c7910199-028e-4d56-b029-aeb553d977d0	\N	{}
c48465fb-520d-445f-b8cc-e8f08c1b8a38	\N	{}
353b8afb-61a8-4233-96dd-480e99a0ff83	MALE	{CITY,CULTURE}
18640b2a-bb98-428b-b4a7-6a3ec8301794	FEMALE	{BEACH,CULTURE,FOOD,RELAX}
b326f22a-02fc-4d99-bce9-6c933113a7a0	\N	{}
ecebd763-797d-4b9f-beff-63f5044776fc	MALE	{}
da3d14e6-04c0-49a0-b029-901ace58b562	\N	{}
0f32ae0f-8c18-4b34-8f38-47e40a4bf11a	\N	{}
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, role, email, full_name, phone_number, date_of_birth, avatar_url, created_at, is_active, is_deleted) FROM stdin;
ecebd763-797d-4b9f-beff-63f5044776fc	TOURIST	hanhspring007@gmail.com	Nguyễn Xuân Kiểm	0973973266	\N	\N	2026-04-11 09:12:12.226153+00	1	1
c7910199-028e-4d56-b029-aeb553d977d0	TOURIST	acd@gmail.com	Nguyễn Văn D	1231231231	\N	\N	2026-04-01 14:23:11.173885+00	1	0
93c230f3-cef1-46eb-8289-4bc66ec565ea	BUSINESS	myoongi@gmail.com	Min Yoongi	1234567891	\N	\N	2026-04-01 16:33:00.199112+00	1	0
ca38c166-41e5-4f9d-b14a-caa71d08be01	ADMIN	admin@gmail.com	Trần Quản Trị	0901234567	\N	https://api.dicebear.com/7.x/avataaars/svg?seed=Admin	2026-03-28 09:21:47.22069+00	1	0
f1723551-793e-40ee-9996-853d1cfc04cc	BUSINESS	abbcc@gmail.com	Nguyễn Văn C	1231231233	2006-03-10	https://pub-f9f45b34dfc64157a5258277d0c0838a.r2.dev/avatars/f1723551-793e-40ee-9996-853d1cfc04cc-1775104281445.webp	2026-04-01 14:21:34.937444+00	1	0
c48465fb-520d-445f-b8cc-e8f08c1b8a38	TOURIST	nve@gmail.com	Nguyễn Văn E	1231231230	\N	\N	2026-04-01 14:23:32.972596+00	1	0
9a54cb41-ee7d-417e-9563-9fb95a35c29c	TOURIST	delete@gmail.com	Nguyễn Văn B	0987654320	\N	\N	2026-03-30 14:21:19.66544+00	0	1
c6ad1e17-f6f1-4229-8580-b00e595c3050	BUSINESS	khanhhanpham88+a1@gmail.com	Kim Seok Jin	0123123122	1990-10-03	https://i.pinimg.com/736x/90/7e/7c/907e7c150d4b655517b81841296b40ae.jpg	2026-03-28 08:47:30.091812+00	1	0
da3d14e6-04c0-49a0-b029-901ace58b562	TOURIST	tva@gmail.com	Trần Văn A	0986723724	\N	\N	2026-04-05 09:01:37.718027+00	0	0
b7ea8833-6fff-4302-8d1b-4424676cb299	BUSINESS	nva@gmail.com	Nguyễn Văn A	0912345678	1970-01-01	https://pub-f9f45b34dfc64157a5258277d0c0838a.r2.dev/avatars/b7ea8833-6fff-4302-8d1b-4424676cb299-1775380124371.webp	2026-03-28 08:31:55.066107+00	1	0
d2b3704a-f14e-47ad-a8e4-8a7fa617f32a	BUSINESS	tvd@gmail.com	Trần Văn D 	0987123124	\N	blob:http://localhost:5173/174f206e-d559-433b-ba1d-6275930648cd	2026-04-05 09:20:54.351302+00	1	0
0f32ae0f-8c18-4b34-8f38-47e40a4bf11a	TOURIST	tvh@gmail.com	Trần Văn H	0987123125	\N		2026-04-05 09:28:15.792995+00	1	0
5f56692b-8daa-4852-bfe7-1032a07635ff	TOURIST	h@gmail.com	Nguyễn Ngọc Hà	0987654321	\N	\N	2026-03-28 08:05:30.561027+00	1	0
353b8afb-61a8-4233-96dd-480e99a0ff83	TOURIST	knjoon@gmail.com	Kim Nam Joon	0123456789	\N	https://pub-f9f45b34dfc64157a5258277d0c0838a.r2.dev/avatars/353b8afb-61a8-4233-96dd-480e99a0ff83-1775745278808.webp	2026-03-30 17:34:26.009393+00	1	0
18640b2a-bb98-428b-b4a7-6a3ec8301794	TOURIST	phamkhanhhan6@gmail.com	Khánh Hân Phạm	\N	\N	https://lh3.googleusercontent.com/a/ACg8ocIgq9DDJgtxSbjeSXhxFlsgjMIj4YKfPQyvsHtmaPH1rRtq9A=s96-c	2026-04-09 14:37:26.483102+00	1	0
20172a2f-f0a1-4449-be0a-75b7cd50f5a3	TOURIST	tourist@gmail.com	Nguyễn Thế Anh	0987654322	1999-06-23	\N	2026-03-28 16:48:02.189806+00	1	0
b326f22a-02fc-4d99-bce9-6c933113a7a0	TOURIST	hanhtyr@gmail.com	Nguyễn Xuân Hạnh	\N	\N	https://lh3.googleusercontent.com/a/ACg8ocIzzuu4QEflTYLsQlBhwXoJlaX2lQa1PR9_kX5LVlb7DP7tek0e=s96-c	2026-04-10 16:12:41.761878+00	1	0
\.


--
-- Data for Name: users_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users_notifications (id, user_id, notification_id, is_read, read_at, sent_at) FROM stdin;
48fe002d-43f3-41e7-9be5-5573400f0673	5f56692b-8daa-4852-bfe7-1032a07635ff	09a9206a-e36a-4ed4-97ad-a0efd666b668	f	\N	2026-04-07 15:21:43.010583+00
e7657cf9-24e2-4b13-92a3-958e57fb5aae	5f56692b-8daa-4852-bfe7-1032a07635ff	313d5794-8008-46d9-8c32-eeff6b1fda69	f	\N	2026-05-04 11:22:44.677616+00
6aef98f5-d3ac-4c8d-b18c-1b4ef9edc13d	5f56692b-8daa-4852-bfe7-1032a07635ff	f1638251-7e1f-4fd9-9168-027e9fa4e074	f	\N	2026-05-04 12:51:25.789103+00
80d5e597-d6a6-40c1-a0ff-fc7da5a4048e	5f56692b-8daa-4852-bfe7-1032a07635ff	1747eb82-689e-4a11-bbab-f58f31812ac8	f	\N	2026-05-04 13:13:16.451653+00
68670b7e-7d9f-4476-ab5b-44efe34de365	5f56692b-8daa-4852-bfe7-1032a07635ff	a266d3a8-0926-4ede-b366-60fe91a9537d	f	\N	2026-05-04 13:24:14.90708+00
112bbcee-0b5c-406f-923e-48b3dc10bbbe	5f56692b-8daa-4852-bfe7-1032a07635ff	8ef57508-d209-4c1e-9729-fe798f3af235	f	\N	2026-05-04 13:28:56.436757+00
f302b61a-0939-480d-ac59-3203dd4cea3d	5f56692b-8daa-4852-bfe7-1032a07635ff	72127377-5bb8-47e3-bae4-6bc7250364f8	f	\N	2026-05-04 13:40:12.600019+00
189db6b9-2c51-4387-a6b2-699acb0ad2d0	5f56692b-8daa-4852-bfe7-1032a07635ff	97d755b3-634e-4a6b-853c-e2460786403a	f	\N	2026-05-04 13:59:58.95673+00
7375f273-b9c6-4f68-aa0d-7a5bd5a3fbae	5f56692b-8daa-4852-bfe7-1032a07635ff	2a2ed56b-6c6b-425c-a94b-f84ab029fab4	f	\N	2026-05-04 14:01:17.565873+00
d5ab7237-3db5-496b-bb43-c6e1c928393c	5f56692b-8daa-4852-bfe7-1032a07635ff	2230886e-ede2-4f99-85de-168af6536f5a	f	\N	2026-05-04 14:01:54.158041+00
15d8c47e-f884-4685-9f2c-de78c3e56ec8	5f56692b-8daa-4852-bfe7-1032a07635ff	6398b25d-9892-4f3c-873c-b8a89bf368cd	f	\N	2026-05-04 14:04:15.846027+00
44d53a6a-eb29-436e-b57d-4a7a26ce6a58	5f56692b-8daa-4852-bfe7-1032a07635ff	03ae2d3e-1685-4ccd-b8db-3b8beeaaee38	f	\N	2026-05-04 14:28:10.246494+00
7bd744bb-faa6-4f74-a33f-ddd99cb47313	5f56692b-8daa-4852-bfe7-1032a07635ff	9d516206-b0c9-4d5e-a065-1808c077d844	f	\N	2026-05-04 14:39:36.657791+00
5725a87e-5403-4b39-b203-6034c9700674	5f56692b-8daa-4852-bfe7-1032a07635ff	d1300d67-ce7c-4f6b-8ec4-7f5724530db8	f	\N	2026-05-04 14:41:46.549608+00
38178bf8-4f69-48a0-8ffe-ea621b835802	5f56692b-8daa-4852-bfe7-1032a07635ff	fd0094c2-2402-4a50-8cc3-cd54d50fb55a	f	\N	2026-05-04 15:23:20.2789+00
40507daa-2fef-4adf-914f-203dc1f7ad8f	5f56692b-8daa-4852-bfe7-1032a07635ff	10dd489a-d8cd-4d7b-87c6-34184dbc2d25	f	\N	2026-05-04 15:27:23.668088+00
\.


--
-- Data for Name: v_cat_id; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.v_cat_id (id) FROM stdin;
88401358-bc5a-465c-b4d1-d8b58d34329b
\.


--
-- Data for Name: messages_2026_05_03; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_05_03 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2026_05_04; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_05_04 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2026_05_05; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_05_05 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2026_05_06; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_05_06 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: messages_2026_05_07; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.messages_2026_05_07 (topic, extension, payload, event, private, updated_at, inserted_at, id) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2026-03-03 12:01:51
20211116045059	2026-03-03 12:01:51
20211116050929	2026-03-03 12:01:51
20211116051442	2026-03-03 12:01:51
20211116212300	2026-03-03 12:01:51
20211116213355	2026-03-03 12:01:51
20211116213934	2026-03-03 12:01:51
20211116214523	2026-03-03 12:01:51
20211122062447	2026-03-03 12:01:51
20211124070109	2026-03-03 12:01:51
20211202204204	2026-03-03 12:01:51
20211202204605	2026-03-03 12:01:51
20211210212804	2026-03-03 12:01:51
20211228014915	2026-03-03 12:01:51
20220107221237	2026-03-03 12:01:51
20220228202821	2026-03-03 12:01:51
20220312004840	2026-03-03 12:01:51
20220603231003	2026-03-03 12:01:51
20220603232444	2026-03-03 12:01:51
20220615214548	2026-03-03 12:01:51
20220712093339	2026-03-03 12:01:51
20220908172859	2026-03-03 12:01:51
20220916233421	2026-03-03 12:01:51
20230119133233	2026-03-03 12:01:51
20230128025114	2026-03-03 12:01:51
20230128025212	2026-03-03 12:01:51
20230227211149	2026-03-03 12:01:51
20230228184745	2026-03-03 12:01:51
20230308225145	2026-03-03 12:01:51
20230328144023	2026-03-03 12:01:51
20231018144023	2026-03-03 12:01:51
20231204144023	2026-03-03 12:01:51
20231204144024	2026-03-03 12:01:51
20231204144025	2026-03-03 12:01:51
20240108234812	2026-03-03 12:01:51
20240109165339	2026-03-03 12:01:51
20240227174441	2026-03-03 12:01:51
20240311171622	2026-03-03 12:01:51
20240321100241	2026-03-03 12:01:51
20240401105812	2026-03-03 12:01:51
20240418121054	2026-03-03 12:01:51
20240523004032	2026-03-03 12:01:52
20240618124746	2026-03-03 12:01:52
20240801235015	2026-03-03 12:01:52
20240805133720	2026-03-03 12:01:52
20240827160934	2026-03-03 12:01:52
20240919163303	2026-03-03 12:01:52
20240919163305	2026-03-03 12:01:52
20241019105805	2026-03-03 12:01:52
20241030150047	2026-03-03 12:01:52
20241108114728	2026-03-03 12:01:52
20241121104152	2026-03-03 12:01:52
20241130184212	2026-03-03 12:01:52
20241220035512	2026-03-03 12:01:52
20241220123912	2026-03-03 12:01:52
20241224161212	2026-03-03 12:01:52
20250107150512	2026-03-03 12:01:52
20250110162412	2026-03-03 12:01:52
20250123174212	2026-03-03 12:01:52
20250128220012	2026-03-03 12:01:52
20250506224012	2026-03-03 12:01:52
20250523164012	2026-03-03 12:01:52
20250714121412	2026-03-03 12:01:52
20250905041441	2026-03-03 12:01:52
20251103001201	2026-03-03 12:01:52
20251120212548	2026-03-03 12:01:52
20251120215549	2026-03-03 12:01:52
20260218120000	2026-03-03 12:01:52
20260326120000	2026-04-10 08:29:23
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at, action_filter) FROM stdin;
\.


--
-- Data for Name: itinerary_reviews; Type: TABLE DATA; Schema: review_ai; Owner: -
--

COPY review_ai.itinerary_reviews (id, itinerary_id, tourist_id, rating, content, url_image, tags, created_at, status) FROM stdin;
8fdb3d70-69c4-452f-a4f5-cf0af5195b04	be1785ad-5847-43b0-a6bf-e51b34bf89ff	5f56692b-8daa-4852-bfe7-1032a07635ff	1	trải nghiệm tệ vcl	{}	\N	2026-04-08 00:59:04.44326	approved
054c9701-2569-49b9-aae2-e2dd106a20ea	f8ca0ab5-b5d8-4847-be15-3e681816d3ea	5f56692b-8daa-4852-bfe7-1032a07635ff	5	\N	{}	\N	2026-04-08 02:08:09.640364	pending
\.


--
-- Data for Name: review_conflicts; Type: TABLE DATA; Schema: review_ai; Owner: -
--

COPY review_ai.review_conflicts (id, new_content_id, old_content_id, conflict_score, conflict_topic, created_at) FROM stdin;
\.


--
-- Data for Name: review_contents; Type: TABLE DATA; Schema: review_ai; Owner: -
--

COPY review_ai.review_contents (id, review_id, content, processing_status, time_label, expiration_date, main_topic, topic_scores, sentiment_scores, embedding, error_info, has_conflict, is_temporary) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: review_ai; Owner: -
--

COPY review_ai.reviews (id, tourist_id, place_id, rating, created_at, review_type, status, itinerary_id, provider, url_image, tags) FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (name, type, format, created_at, updated_at, id, deleted_at) FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_vectors (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-03-03 12:01:25.524489
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-03-03 12:01:25.658947
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-03-03 12:01:25.680411
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-03-03 12:01:25.710432
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-03-03 12:01:25.725218
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-03-03 12:01:25.730499
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-03-03 12:01:25.743198
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-03-03 12:01:25.754132
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-03-03 12:01:25.758968
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-03-03 12:01:25.76525
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-03-03 12:01:25.77737
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-03-03 12:01:25.782964
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-03-03 12:01:25.788608
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-03-03 12:01:25.793503
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-03-03 12:01:25.79862
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-03-03 12:01:25.833057
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-03-03 12:01:25.838203
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-03-03 12:01:25.84915
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-03-03 12:01:25.854247
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-03-03 12:01:25.862782
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-03-03 12:01:25.867484
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-03-03 12:01:25.874518
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-03-03 12:01:25.922891
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-03-03 12:01:25.939796
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-03-03 12:01:25.945142
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-03-03 12:01:25.951901
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-03-03 12:01:25.957366
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-03-03 12:01:25.962746
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-03-03 12:01:25.973363
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-03-03 12:01:25.978471
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-03-03 12:01:25.983718
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-03-03 12:01:25.988652
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-03-03 12:01:25.992957
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-03-03 12:01:25.999364
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-03-03 12:01:26.004369
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-03-03 12:01:26.009372
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-03-03 12:01:26.014299
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-03-03 12:01:26.019427
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-03-03 12:01:26.032396
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-03-03 12:01:26.044989
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-03-03 12:01:26.049462
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-03-03 12:01:26.054358
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-03-03 12:01:26.058871
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-03-03 12:01:26.063691
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-03-03 12:01:26.068112
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-03-03 12:01:26.074868
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-03-03 12:01:26.091156
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-03-03 12:01:26.09639
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-03-03 12:01:26.101014
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-03-03 12:01:26.188735
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-03-03 12:01:26.195548
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-03-03 12:01:26.331615
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-03-03 12:01:26.333724
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-03-03 12:01:26.395275
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-03-03 12:01:26.398338
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-03-03 12:01:26.401051
56	fix-optimized-search-function	cb58526ebc23048049fd5bf2fd148d18b04a2073	2026-03-03 12:01:26.406848
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-04-07 13:40:20.696823
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-04-07 13:40:20.72607
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata, metadata) FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.vector_indexes (id, name, bucket_id, data_type, dimension, distance_metric, metadata_configuration, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: geofence_visits; Type: TABLE DATA; Schema: tracking; Owner: -
--

COPY tracking.geofence_visits (geofence_id, itinerary_detail_id, status, recorded_at) FROM stdin;
\.


--
-- Data for Name: geofences; Type: TABLE DATA; Schema: tracking; Owner: -
--

COPY tracking.geofences (id, name, polygon, created_at, is_active) FROM stdin;
\.


--
-- Data for Name: transport_modes; Type: TABLE DATA; Schema: tracking; Owner: -
--

COPY tracking.transport_modes (id, name, transport_type) FROM stdin;
\.


--
-- Data for Name: transport_pricing_rules; Type: TABLE DATA; Schema: tracking; Owner: -
--

COPY tracking.transport_pricing_rules (id, transport_mode_id, distance_range, price) FROM stdin;
\.


--
-- Data for Name: transport_to_destination; Type: TABLE DATA; Schema: tracking; Owner: -
--

COPY tracking.transport_to_destination (transport_mode_id, total_cost, itinerary_id) FROM stdin;
\.


--
-- Data for Name: transport_within_city; Type: TABLE DATA; Schema: tracking; Owner: -
--

COPY tracking.transport_within_city (transport_mode_id, itinerary_detail_id, total_cost) FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.activity_logs (id, tourist_id, action_type, created_at, place_id) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.categories (id, name) FROM stdin;
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.cities (id, name) FROM stdin;
ea176f8a-471f-55f3-8c03-ecce16c99cba	An Giang
5d0e957c-cae5-594a-bcdc-81a9e5215b39	Bắc Giang
2c9c086c-cde4-574c-844c-9242f52d7193	Bắc Kạn
ed372d7f-a471-5992-85fe-07d4f34c25f9	Bạc Liêu
8d9d2772-ae9d-5833-8a1f-a79233dd2c5b	Bắc Ninh
dd107567-7d65-577a-9011-06cb84e97233	Bến Tre
9ff5279d-422e-5192-af82-12b7d154a736	Bình Dương
c4fae04d-9ecc-57ec-ba96-0ff05303da5c	Bình Phước
9d697eb4-3bf0-58a8-9f31-e086d59d7c7d	Bình Thuận
addaf5cb-de49-5d0a-bbf5-cab217cbbcbd	Cà Mau
3cf95641-de1c-5baf-97a7-6f23cd4e72c6	Cần Thơ
650b3acc-b82a-5618-84c2-52f7930baa44	Cao Bằng
8a10b8b8-6875-58e0-9bee-27f67e54376e	Đà Nẵng
f9302244-d94b-51e6-92aa-3b2b7681e019	Đắk Lắk
bffba9aa-ecd1-57b3-a1f5-cf3a31f7ada2	Đắk Nông
5bff9c69-79c3-588f-bc48-d9f8fc188703	Điện Biên
c4626942-6b84-5d47-bf7f-239bc3ece44c	Đồng Nai
a1323f7f-2009-5d4d-ab50-aea4c1a1f16e	Đồng Tháp
acbe4caa-b2ca-5519-95fa-78ea18513ea1	Gia Lai
4e83e326-3a79-5b13-b045-9ada0e5666be	Hà Giang
69045ab7-e309-5782-8af2-12bf933b9d5b	Hà Nam
a821f185-9826-568f-a3d2-967f0efd1c9d	Hà Nội
89700b27-3bdb-5962-a97c-93776e42a29a	Hà Tĩnh
63c434e6-019a-59d8-8816-27f12458efa5	Hải Dương
87685562-e744-53cc-a324-2a65540348a6	Hải Phòng
ad4852ab-7820-5b3b-8a88-e4382a3f86c8	Hậu Giang
3b9a22b3-293b-5313-97c5-d9b71c30756f	Hồ Chí Minh
b021aaba-f627-5375-8d3e-7c048d5dc37d	Hòa Bình
477a099d-8dd4-5899-877c-b911a1c7fb8b	Huế
1b77e551-04f9-52c1-ad83-231e7f44ad91	Hưng Yên
1aa5ed1b-16c1-51f4-a3ba-c25e0ed91ce5	Khánh Hòa
8dfd58c0-e0a9-5169-8c71-fdbc2633c971	Kiên Giang
7d6993f3-48c6-51a6-98db-b1cc31e6b240	Kon Tum
fa1c17d6-9832-5fca-9d57-051817b9c122	Lai Châu
340af4ff-0cda-5e1a-8e02-a999acc906f6	Lâm Đồng
eced678a-5dad-5df7-b453-3a7f8d4e8d2a	Lạng Sơn
72785a4f-069f-52b1-ac69-e46d648d4fd4	Lào Cai
9e1d252f-25d7-5734-b26d-8259d18f165b	Long An
13f9f0dc-4519-5219-bd2b-be1ee572e8ca	Nam Định
49dd4ebd-8d34-5130-a01c-bdc8ea17101e	Nghệ An
fea5f034-8761-5385-97be-d3ddd4321f28	Ninh Bình
ec0111f7-3597-51da-b2b7-b5f93f91df53	Ninh Thuận
2cae585f-0b4d-570c-b649-ee25b6aa1f43	Phú Quốc
f0676fe4-52cc-5b81-95ea-748e0dde1f1b	Phú Thọ
5874b9ef-ea1e-556b-917f-2b2b0f89d98d	Phú Yên
156c9dab-f18a-5fc5-b6d8-d1af14850e7f	Quảng Bình
9483f023-1f40-56e4-824e-9ac85dd39793	Bình Định
477756f3-d73f-55b7-8698-21d64befaf2d	Quảng Nam
376d4659-9c9c-5cfb-8006-9505e7ad03cc	Quảng Ngãi
7eedad92-8762-57fd-9584-566b0653b957	Quảng Ninh
32155f1f-7ac5-5b2a-8f0a-ac4636aed10d	Quảng Trị
3e33c7e5-c285-5b88-8ea6-c6a9e9758367	Sóc Trăng
bd212be0-5738-532f-bc87-59725ca8799c	Sơn La
197f6b60-c40b-585e-a7ce-fcfba4020ea3	Tây Ninh
7451de42-2d03-5b18-8d76-53a2d3d7ed7c	Thái Bình
3f644fd1-ea72-5a62-ab0a-96606bab78ac	Thái Nguyên
07a84302-79a3-5d79-9076-0c56365ecc0f	Thanh Hóa
d5b73a1a-822e-5ede-b4c6-23130c942c60	Tiền Giang
fbb5cc87-582e-57ce-aa47-91461820694e	Trà Vinh
09b675bb-f1dd-5a86-9cdd-eea80b0dbe60	Tuyên Quang
35648a8a-312a-5640-a490-e0cffe0b5214	Vĩnh Long
3accd508-f6ae-5be5-a6e2-64ac01fe4947	Vĩnh Phúc
fc51a18f-b4bb-5183-9d81-6a7e03a0ca4a	Vũng Tàu
04d66a53-3234-57aa-a614-a2789b12e6c7	Yên Bái
\.


--
-- Data for Name: favorite_itineraries; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.favorite_itineraries (tourist_id, itinerary_id, added_at) FROM stdin;
5f56692b-8daa-4852-bfe7-1032a07635ff	810bdef4-c048-4e3e-b35b-18a3500f349e	2026-04-07 15:08:07.438442
\.


--
-- Data for Name: favorite_places; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.favorite_places (tourist_id, place_id, added_at) FROM stdin;
\.


--
-- Data for Name: itineraries; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.itineraries (id, creator_id, description, start_date, end_date, estimated_cost, status, departure_point, destination, created_at, actual_cost, is_public, adult_count, children_count) FROM stdin;
6c2f9142-3f1a-4947-a434-665049050cd3	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	Du lịch Nha Trang	2026-03-14	2026-03-16	\N	ongoing	\N	\N	2026-03-14 06:24:21.219268	\N	f	1	0
6f56bfc2-ce60-4217-9dc8-8a39904b5f8b	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	Du lịch cuối tuần	2026-03-14	2026-03-15	\N	ongoing	\N	\N	2026-03-14 06:05:20.404396	\N	f	1	0
75ac7570-6eea-4fc7-988c-e2074d4ed25e	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	Phú Quốc - Nghỉ dưỡng hè	2026-04-13	2026-04-18	7000000.00	ongoing	Hà Nội	Phú Quốc	2026-03-14 06:43:32.107047	\N	f	1	0
967aaf48-a111-40f7-b88d-b9ad3272d7b9	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	Sài Gòn 3N2Đ	2026-03-04	2026-03-07	3000000.00	completed	Hà Nội	TP Hồ Chí Minh	2026-03-14 06:43:32.107047	\N	f	1	0
add7f5ec-b8ed-4481-b22e-0dfdb0273c93	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	Đà Nẵng 4N3Đ	2026-03-24	2026-03-28	4000000.00	\N	Hà Nội	Đà Nẵng	2026-03-14 06:43:32.107047	\N	f	1	0
b0e85562-8126-4cb1-80c5-38c9cf7a0631	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	Hạ Long: Vịnh Di Sản	2026-02-12	2026-02-15	2500000.00	completed	Hà Nội	Quảng Ninh	2026-03-14 06:43:32.107047	\N	f	1	0
810bdef4-c048-4e3e-b35b-18a3500f349e	20172a2f-f0a1-4449-be0a-75b7cd50f5a3	Trip around Ho Chi Minh city	2026-03-20	2026-03-21	\N	ongoing	District 1	Ho Chi Minh City	2026-03-11 18:05:53.832055	\N	t	1	0
be1785ad-5847-43b0-a6bf-e51b34bf89ff	5f56692b-8daa-4852-bfe7-1032a07635ff	Du lịch Đà Nẵng	2026-04-17	2026-04-18	3000000.00	completed	Thành phố Hồ Chí Minh	Đà Nẵng	2026-04-07 15:11:00.646031	\N	t	1	0
a0cbec63-3a28-4797-88f4-4ce1b482b53a	5f56692b-8daa-4852-bfe7-1032a07635ff	5 ngày du lịch Sài Gòn	2026-04-12	2026-04-16	20000000.00	pending	Hà Nội	Hồ Chí Minh	2026-04-10 09:11:57.635937	\N	f	2	1
f8ca0ab5-b5d8-4847-be15-3e681816d3ea	0f32ae0f-8c18-4b34-8f38-47e40a4bf11a	Du lịch Hà Nội	2026-04-21	2026-04-23	5000000.00	ongoing	Thành phố Hồ Chí Minh	Hà Nội	2026-04-07 14:34:30.335019	\N	t	1	0
\.


--
-- Data for Name: itinerary_details; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.itinerary_details (id, itinerary_id, place_id, visit_date, arrival_time, departure_time, notes, estimated_cost, transport_cost, actual_cost, cost_updated_at, is_locked, duration_minutes, sequence_order, user_notes, locked_arrive_time) FROM stdin;
\.


--
-- Data for Name: itinerary_members; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.itinerary_members (tourist_id, itinerary_id, added_at) FROM stdin;
\.


--
-- Data for Name: place_services; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.place_services (place_id, service_id) FROM stdin;
\.


--
-- Data for Name: place_tags; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.place_tags (place_id, tag_id) FROM stdin;
\.


--
-- Data for Name: places; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.places (id, name, longitude, latitude, address, is_approved, average_rating, review_count, open_time, close_time, description, is_active, registered_date, vendor_id, image_url, updated_at, city_id, source_id, source, type_id, vibes) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.services (id, name, price) FROM stdin;
17f593c1-65c2-49a3-a40e-e022360abec3	Wifi	\N
05207545-1e7e-4424-a927-ee52d7d2b8ca	Giữ xe miễn phí	\N
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.tags (id, name) FROM stdin;
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: travel; Owner: -
--

COPY travel.types (id, name, category_id) FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 686, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 8, true);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: user_notifications user_notifications_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_notifications
    ADD CONSTRAINT user_notifications_pkey PRIMARY KEY (notification_id, user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: food_items food_items_pkey; Type: CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.food_items
    ADD CONSTRAINT food_items_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: food_items uq_foody_dish_id; Type: CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.food_items
    ADD CONSTRAINT uq_foody_dish_id UNIQUE (foody_dish_id);


--
-- Name: businesses businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: tourists tourists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourists
    ADD CONSTRAINT tourists_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users_notifications users_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_notifications
    ADD CONSTRAINT users_notifications_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_05_03 messages_2026_05_03_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_05_03
    ADD CONSTRAINT messages_2026_05_03_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_05_04 messages_2026_05_04_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_05_04
    ADD CONSTRAINT messages_2026_05_04_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_05_05 messages_2026_05_05_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_05_05
    ADD CONSTRAINT messages_2026_05_05_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_05_06 messages_2026_05_06_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_05_06
    ADD CONSTRAINT messages_2026_05_06_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: messages_2026_05_07 messages_2026_05_07_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages_2026_05_07
    ADD CONSTRAINT messages_2026_05_07_pkey PRIMARY KEY (id, inserted_at);


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: itinerary_reviews itinerary_reviews_pkey; Type: CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.itinerary_reviews
    ADD CONSTRAINT itinerary_reviews_pkey PRIMARY KEY (id);


--
-- Name: review_conflicts review_conflicts_pkey; Type: CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.review_conflicts
    ADD CONSTRAINT review_conflicts_pkey PRIMARY KEY (id);


--
-- Name: review_contents review_contents_pkey; Type: CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.review_contents
    ADD CONSTRAINT review_contents_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_vectors
    ADD CONSTRAINT buckets_vectors_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_pkey PRIMARY KEY (id);


--
-- Name: geofence_visits geofence_visits_pkey; Type: CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.geofence_visits
    ADD CONSTRAINT geofence_visits_pkey PRIMARY KEY (geofence_id, itinerary_detail_id);


--
-- Name: geofences geofences_pkey; Type: CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.geofences
    ADD CONSTRAINT geofences_pkey PRIMARY KEY (id);


--
-- Name: transport_modes transport_modes_pkey; Type: CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_modes
    ADD CONSTRAINT transport_modes_pkey PRIMARY KEY (id);


--
-- Name: transport_pricing_rules transport_pricing_rules_pkey; Type: CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_pricing_rules
    ADD CONSTRAINT transport_pricing_rules_pkey PRIMARY KEY (id);


--
-- Name: transport_to_destination transport_to_destination_pkey; Type: CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_to_destination
    ADD CONSTRAINT transport_to_destination_pkey PRIMARY KEY (transport_mode_id, itinerary_id);


--
-- Name: transport_within_city transport_within_city_pkey; Type: CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_within_city
    ADD CONSTRAINT transport_within_city_pkey PRIMARY KEY (transport_mode_id, itinerary_detail_id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (id);


--
-- Name: favorite_itineraries favorite_itineraries_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.favorite_itineraries
    ADD CONSTRAINT favorite_itineraries_pkey PRIMARY KEY (tourist_id, itinerary_id);


--
-- Name: favorite_places favorite_places_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.favorite_places
    ADD CONSTRAINT favorite_places_pkey PRIMARY KEY (tourist_id, place_id);


--
-- Name: itineraries itineraries_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itineraries
    ADD CONSTRAINT itineraries_pkey PRIMARY KEY (id);


--
-- Name: itinerary_details itinerary_details_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itinerary_details
    ADD CONSTRAINT itinerary_details_pkey PRIMARY KEY (id);


--
-- Name: itinerary_members itinerary_members_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itinerary_members
    ADD CONSTRAINT itinerary_members_pkey PRIMARY KEY (tourist_id, itinerary_id);


--
-- Name: place_services place_services_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.place_services
    ADD CONSTRAINT place_services_pkey PRIMARY KEY (place_id, service_id);


--
-- Name: place_tags place_tags_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.place_tags
    ADD CONSTRAINT place_tags_pkey PRIMARY KEY (place_id, tag_id);


--
-- Name: places places_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.places
    ADD CONSTRAINT places_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: places uq_places_source; Type: CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.places
    ADD CONSTRAINT uq_places_source UNIQUE (source, source_id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: unique_active_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_active_phone ON public.users USING btree (phone_number) WHERE (phone_number IS NOT NULL);


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_inserted_at_topic_index ON ONLY realtime.messages USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_05_03_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_05_03_inserted_at_topic_idx ON realtime.messages_2026_05_03 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_05_04_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_05_04_inserted_at_topic_idx ON realtime.messages_2026_05_04 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_05_05_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_05_05_inserted_at_topic_idx ON realtime.messages_2026_05_05 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_05_06_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_05_06_inserted_at_topic_idx ON realtime.messages_2026_05_06 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: messages_2026_05_07_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX messages_2026_05_07_inserted_at_topic_idx ON realtime.messages_2026_05_07 USING btree (inserted_at DESC, topic) WHERE ((extension = 'broadcast'::text) AND (private IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_key; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_action_filter_key ON realtime.subscription USING btree (subscription_id, entity, filters, action_filter);


--
-- Name: idx_reviews_created_at; Type: INDEX; Schema: review_ai; Owner: -
--

CREATE INDEX idx_reviews_created_at ON review_ai.reviews USING btree (created_at DESC);


--
-- Name: idx_reviews_status; Type: INDEX; Schema: review_ai; Owner: -
--

CREATE INDEX idx_reviews_status ON review_ai.reviews USING btree (status);


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX buckets_analytics_unique_name_idx ON storage.buckets_analytics USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name_lower ON storage.objects USING btree (bucket_id, lower(name) COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX vector_indexes_name_bucket_id_idx ON storage.vector_indexes USING btree (name, bucket_id);


--
-- Name: messages_2026_05_03_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_05_03_inserted_at_topic_idx;


--
-- Name: messages_2026_05_03_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_05_03_pkey;


--
-- Name: messages_2026_05_04_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_05_04_inserted_at_topic_idx;


--
-- Name: messages_2026_05_04_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_05_04_pkey;


--
-- Name: messages_2026_05_05_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_05_05_inserted_at_topic_idx;


--
-- Name: messages_2026_05_05_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_05_05_pkey;


--
-- Name: messages_2026_05_06_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_05_06_inserted_at_topic_idx;


--
-- Name: messages_2026_05_06_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_05_06_pkey;


--
-- Name: messages_2026_05_07_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_inserted_at_topic_index ATTACH PARTITION realtime.messages_2026_05_07_inserted_at_topic_idx;


--
-- Name: messages_2026_05_07_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: -
--

ALTER INDEX realtime.messages_pkey ATTACH PARTITION realtime.messages_2026_05_07_pkey;


--
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_registration();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_buckets_delete BEFORE DELETE ON storage.buckets FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER protect_objects_delete BEFORE DELETE ON storage.objects FOR EACH STATEMENT EXECUTE FUNCTION storage.protect_delete();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_notifications user_notifications_notification_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_notifications
    ADD CONSTRAINT user_notifications_notification_id_fkey FOREIGN KEY (notification_id) REFERENCES core.notifications(id) ON DELETE CASCADE;


--
-- Name: user_notifications user_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_notifications
    ADD CONSTRAINT user_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: orders fk_order_tourist; Type: FK CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.orders
    ADD CONSTRAINT fk_order_tourist FOREIGN KEY (tourist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: food_items food_items_place_id_fkey; Type: FK CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.food_items
    ADD CONSTRAINT food_items_place_id_fkey FOREIGN KEY (place_id) REFERENCES travel.places(id);


--
-- Name: order_items order_items_food_item_id_fkey; Type: FK CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.order_items
    ADD CONSTRAINT order_items_food_item_id_fkey FOREIGN KEY (food_item_id) REFERENCES order_sys.food_items(id);


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES order_sys.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_itinerary_detail_id_fkey; Type: FK CONSTRAINT; Schema: order_sys; Owner: -
--

ALTER TABLE ONLY order_sys.orders
    ADD CONSTRAINT orders_itinerary_detail_id_fkey FOREIGN KEY (itinerary_detail_id) REFERENCES travel.itinerary_details(id);


--
-- Name: businesses businesses_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_id_fkey FOREIGN KEY (id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users_notifications fk_users_notifications_notification; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_notifications
    ADD CONSTRAINT fk_users_notifications_notification FOREIGN KEY (notification_id) REFERENCES public.notifications(id) ON DELETE CASCADE;


--
-- Name: users_notifications fk_users_notifications_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users_notifications
    ADD CONSTRAINT fk_users_notifications_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tourists tourists_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourists
    ADD CONSTRAINT tourists_id_fkey FOREIGN KEY (id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: itinerary_reviews fk_itinerary_review_tourist; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.itinerary_reviews
    ADD CONSTRAINT fk_itinerary_review_tourist FOREIGN KEY (tourist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reviews fk_review_tourist; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.reviews
    ADD CONSTRAINT fk_review_tourist FOREIGN KEY (tourist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: itinerary_reviews itinerary_reviews_itinerary_id_fkey; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.itinerary_reviews
    ADD CONSTRAINT itinerary_reviews_itinerary_id_fkey FOREIGN KEY (itinerary_id) REFERENCES travel.itineraries(id) ON DELETE CASCADE;


--
-- Name: review_conflicts review_conflicts_new_content_id_fkey; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.review_conflicts
    ADD CONSTRAINT review_conflicts_new_content_id_fkey FOREIGN KEY (new_content_id) REFERENCES review_ai.review_contents(id);


--
-- Name: review_conflicts review_conflicts_old_content_id_fkey; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.review_conflicts
    ADD CONSTRAINT review_conflicts_old_content_id_fkey FOREIGN KEY (old_content_id) REFERENCES review_ai.review_contents(id);


--
-- Name: review_contents review_contents_review_id_fkey; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.review_contents
    ADD CONSTRAINT review_contents_review_id_fkey FOREIGN KEY (review_id) REFERENCES review_ai.reviews(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_itinerary_id_fkey; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.reviews
    ADD CONSTRAINT reviews_itinerary_id_fkey FOREIGN KEY (itinerary_id) REFERENCES travel.itineraries(id);


--
-- Name: reviews reviews_place_id_fkey; Type: FK CONSTRAINT; Schema: review_ai; Owner: -
--

ALTER TABLE ONLY review_ai.reviews
    ADD CONSTRAINT reviews_place_id_fkey FOREIGN KEY (place_id) REFERENCES travel.places(id);


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.vector_indexes
    ADD CONSTRAINT vector_indexes_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets_vectors(id);


--
-- Name: transport_to_destination fk_transport_itinerary; Type: FK CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_to_destination
    ADD CONSTRAINT fk_transport_itinerary FOREIGN KEY (itinerary_id) REFERENCES travel.itineraries(id);


--
-- Name: geofence_visits geofence_visits_geofence_id_fkey; Type: FK CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.geofence_visits
    ADD CONSTRAINT geofence_visits_geofence_id_fkey FOREIGN KEY (geofence_id) REFERENCES tracking.geofences(id);


--
-- Name: geofence_visits geofence_visits_itinerary_detail_id_fkey; Type: FK CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.geofence_visits
    ADD CONSTRAINT geofence_visits_itinerary_detail_id_fkey FOREIGN KEY (itinerary_detail_id) REFERENCES travel.itinerary_details(id);


--
-- Name: transport_pricing_rules transport_pricing_rules_transport_mode_id_fkey; Type: FK CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_pricing_rules
    ADD CONSTRAINT transport_pricing_rules_transport_mode_id_fkey FOREIGN KEY (transport_mode_id) REFERENCES tracking.transport_modes(id);


--
-- Name: transport_to_destination transport_to_destination_transport_mode_id_fkey; Type: FK CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_to_destination
    ADD CONSTRAINT transport_to_destination_transport_mode_id_fkey FOREIGN KEY (transport_mode_id) REFERENCES tracking.transport_modes(id);


--
-- Name: transport_within_city transport_within_city_itinerary_detail_id_fkey; Type: FK CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_within_city
    ADD CONSTRAINT transport_within_city_itinerary_detail_id_fkey FOREIGN KEY (itinerary_detail_id) REFERENCES travel.itinerary_details(id);


--
-- Name: transport_within_city transport_within_city_transport_mode_id_fkey; Type: FK CONSTRAINT; Schema: tracking; Owner: -
--

ALTER TABLE ONLY tracking.transport_within_city
    ADD CONSTRAINT transport_within_city_transport_mode_id_fkey FOREIGN KEY (transport_mode_id) REFERENCES tracking.transport_modes(id);


--
-- Name: activity_logs activity_logs_place_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.activity_logs
    ADD CONSTRAINT activity_logs_place_id_fkey FOREIGN KEY (place_id) REFERENCES travel.places(id);


--
-- Name: favorite_itineraries favorite_itineraries_itinerary_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.favorite_itineraries
    ADD CONSTRAINT favorite_itineraries_itinerary_id_fkey FOREIGN KEY (itinerary_id) REFERENCES travel.itineraries(id);


--
-- Name: favorite_places favorite_places_place_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.favorite_places
    ADD CONSTRAINT favorite_places_place_id_fkey FOREIGN KEY (place_id) REFERENCES travel.places(id);


--
-- Name: activity_logs fk_activity_tourist; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.activity_logs
    ADD CONSTRAINT fk_activity_tourist FOREIGN KEY (tourist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorite_itineraries fk_fav_itinerary_tourist; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.favorite_itineraries
    ADD CONSTRAINT fk_fav_itinerary_tourist FOREIGN KEY (tourist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: favorite_places fk_favorite_tourist; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.favorite_places
    ADD CONSTRAINT fk_favorite_tourist FOREIGN KEY (tourist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: itineraries fk_itinerary_creator; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itineraries
    ADD CONSTRAINT fk_itinerary_creator FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: itinerary_members fk_member_tourist; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itinerary_members
    ADD CONSTRAINT fk_member_tourist FOREIGN KEY (tourist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: places fk_places_city; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.places
    ADD CONSTRAINT fk_places_city FOREIGN KEY (city_id) REFERENCES travel.cities(id);


--
-- Name: places fk_places_type; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.places
    ADD CONSTRAINT fk_places_type FOREIGN KEY (type_id) REFERENCES travel.types(id) ON DELETE RESTRICT;


--
-- Name: places fk_places_vendor; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.places
    ADD CONSTRAINT fk_places_vendor FOREIGN KEY (vendor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: types fk_types_category; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.types
    ADD CONSTRAINT fk_types_category FOREIGN KEY (category_id) REFERENCES travel.categories(id) ON DELETE RESTRICT;


--
-- Name: itinerary_details itinerary_details_itinerary_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itinerary_details
    ADD CONSTRAINT itinerary_details_itinerary_id_fkey FOREIGN KEY (itinerary_id) REFERENCES travel.itineraries(id) ON DELETE CASCADE;


--
-- Name: itinerary_details itinerary_details_place_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itinerary_details
    ADD CONSTRAINT itinerary_details_place_id_fkey FOREIGN KEY (place_id) REFERENCES travel.places(id);


--
-- Name: itinerary_members itinerary_members_itinerary_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.itinerary_members
    ADD CONSTRAINT itinerary_members_itinerary_id_fkey FOREIGN KEY (itinerary_id) REFERENCES travel.itineraries(id);


--
-- Name: place_services place_services_place_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.place_services
    ADD CONSTRAINT place_services_place_id_fkey FOREIGN KEY (place_id) REFERENCES travel.places(id);


--
-- Name: place_services place_services_service_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.place_services
    ADD CONSTRAINT place_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES travel.services(id);


--
-- Name: place_tags place_tags_place_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.place_tags
    ADD CONSTRAINT place_tags_place_id_fkey FOREIGN KEY (place_id) REFERENCES travel.places(id) ON DELETE CASCADE;


--
-- Name: place_tags place_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: travel; Owner: -
--

ALTER TABLE ONLY travel.place_tags
    ADD CONSTRAINT place_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES travel.tags(id) ON DELETE CASCADE;


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: businesses Business can update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Business can update own profile" ON public.businesses FOR UPDATE USING ((auth.uid() = id));


--
-- Name: businesses Business can view own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Business can view own profile" ON public.businesses FOR SELECT USING ((auth.uid() = id));


--
-- Name: tourists Tourists can update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Tourists can update own profile" ON public.tourists FOR UPDATE USING ((auth.uid() = id));


--
-- Name: tourists Tourists can view own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Tourists can view own profile" ON public.tourists FOR SELECT USING ((auth.uid() = id));


--
-- Name: tourists Users can update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own profile" ON public.tourists FOR UPDATE USING ((auth.uid() = id));


--
-- Name: users Users can update own user record; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own user record" ON public.users FOR UPDATE USING ((auth.uid() = id));


--
-- Name: users Users can view own user record; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own user record" ON public.users FOR SELECT USING ((auth.uid() = id));


--
-- Name: businesses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.businesses ENABLE ROW LEVEL SECURITY;

--
-- Name: tourists; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tourists ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: review_contents; Type: ROW SECURITY; Schema: review_ai; Owner: -
--

ALTER TABLE review_ai.review_contents ENABLE ROW LEVEL SECURITY;

--
-- Name: reviews; Type: ROW SECURITY; Schema: review_ai; Owner: -
--

ALTER TABLE review_ai.reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: review_contents service_role_insert_contents; Type: POLICY; Schema: review_ai; Owner: -
--

CREATE POLICY service_role_insert_contents ON review_ai.review_contents FOR INSERT TO authenticated, service_role WITH CHECK (true);


--
-- Name: reviews service_role_insert_reviews; Type: POLICY; Schema: review_ai; Owner: -
--

CREATE POLICY service_role_insert_reviews ON review_ai.reviews FOR INSERT TO authenticated, service_role WITH CHECK (true);


--
-- Name: review_contents service_role_select_contents; Type: POLICY; Schema: review_ai; Owner: -
--

CREATE POLICY service_role_select_contents ON review_ai.review_contents FOR SELECT TO authenticated, service_role USING (true);


--
-- Name: reviews service_role_select_reviews; Type: POLICY; Schema: review_ai; Owner: -
--

CREATE POLICY service_role_select_reviews ON review_ai.reviews FOR SELECT TO authenticated, service_role USING (true);


--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_vectors ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.vector_indexes ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime_messages_publication WITH (publish = 'insert, update, delete, truncate');


--
-- Name: supabase_realtime users_notifications; Type: PUBLICATION TABLE; Schema: public; Owner: -
--

ALTER PUBLICATION supabase_realtime ADD TABLE ONLY public.users_notifications;


--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: -
--

ALTER PUBLICATION supabase_realtime_messages_publication ADD TABLE ONLY realtime.messages;


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict 5UyW2BWlmAzWQ7R0dRj2sAcZnjdn2w0eolwTeP3RIpnQsofVh0MgKiA6W6oitNf

